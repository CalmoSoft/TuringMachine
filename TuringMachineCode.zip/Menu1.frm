VERSION 5.00
Begin VB.Form frm_Menu1 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00808000&
   Caption         =   "                                                  Men�rendszer fel�p�t�se - 1."
   ClientHeight    =   8595
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   11880
   ControlBox      =   0   'False
   ForeColor       =   &H80000001&
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8595
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_End 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   9195
      TabIndex        =   25
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   240
      Width           =   1725
   End
   Begin VB.CommandButton cmd_Next 
      BackColor       =   &H00C0C0C0&
      Caption         =   "K�vetkez�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   7200
      TabIndex        =   24
      ToolTipText     =   "A k�vetkez� oldal megjelen�t�se"
      Top             =   240
      Width           =   1725
   End
   Begin VB.Line Line35 
      X1              =   2175
      X2              =   2430
      Y1              =   2700
      Y2              =   2700
   End
   Begin VB.Label Label26 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kil�p"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2445
      TabIndex        =   27
      Top             =   2520
      Width           =   3735
   End
   Begin VB.Line Line34 
      X1              =   6665
      X2              =   7215
      Y1              =   6465
      Y2              =   6465
   End
   Begin VB.Line Line33 
      X1              =   6665
      X2              =   6665
      Y1              =   6465
      Y2              =   6900
   End
   Begin VB.Label Label23 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd�sz� v�g�n"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   26
      Top             =   6750
      Width           =   3705
   End
   Begin VB.Label Label25 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Param�terek bet�lt�s�hez"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   23
      Top             =   7695
      Width           =   3705
   End
   Begin VB.Label Label24 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Teljes feladat bet�lt�s�hez"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   22
      Top             =   8175
      Width           =   3705
   End
   Begin VB.Line Line32 
      X1              =   6120
      X2              =   6665
      Y1              =   7890
      Y2              =   7890
   End
   Begin VB.Line Line31 
      X1              =   6665
      X2              =   7200
      Y1              =   7890
      Y2              =   7890
   End
   Begin VB.Line Line30 
      X1              =   6665
      X2              =   7200
      Y1              =   8370
      Y2              =   8370
   End
   Begin VB.Line Line29 
      X1              =   6665
      X2              =   6665
      Y1              =   7890
      Y2              =   8370
   End
   Begin VB.Label Label22 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd�sz� elej�n"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   21
      Top             =   6255
      Width           =   3705
   End
   Begin VB.Label Label21 
      BackColor       =   &H00C0C0C0&
      Caption         =   "M�shol"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   20
      Top             =   7230
      Width           =   3705
   End
   Begin VB.Line Line28 
      X1              =   6665
      X2              =   6665
      Y1              =   6915
      Y2              =   7410
   End
   Begin VB.Line Line27 
      X1              =   6665
      X2              =   7200
      Y1              =   7410
      Y2              =   7410
   End
   Begin VB.Line Line26 
      X1              =   6665
      X2              =   7200
      Y1              =   6900
      Y2              =   6900
   End
   Begin VB.Line Line25 
      X1              =   6135
      X2              =   6665
      Y1              =   7410
      Y2              =   7410
   End
   Begin VB.Line Line24 
      X1              =   2130
      X2              =   2400
      Y1              =   7395
      Y2              =   7395
   End
   Begin VB.Line Line23 
      X1              =   2130
      X2              =   2400
      Y1              =   7875
      Y2              =   7875
   End
   Begin VB.Line Line22 
      X1              =   2115
      X2              =   2385
      Y1              =   8340
      Y2              =   8340
   End
   Begin VB.Line Line21 
      X1              =   2115
      X2              =   2385
      Y1              =   6915
      Y2              =   6915
   End
   Begin VB.Line Line20 
      X1              =   2130
      X2              =   2400
      Y1              =   6435
      Y2              =   6435
   End
   Begin VB.Line Line17 
      X1              =   1770
      X2              =   2115
      Y1              =   7395
      Y2              =   7395
   End
   Begin VB.Line Line15 
      X1              =   2115
      X2              =   2115
      Y1              =   6435
      Y2              =   8355
   End
   Begin VB.Label Label20 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Iter�ci� alkalmaz�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2400
      TabIndex        =   19
      Top             =   8175
      Width           =   3735
   End
   Begin VB.Label Label19 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kimenet �tad�sa bemnetk�nt"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2400
      TabIndex        =   18
      Top             =   7695
      Width           =   3735
   End
   Begin VB.Label Label18 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej�ll�s"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   17
      Top             =   7230
      Width           =   3735
   End
   Begin VB.Label Label12 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd� pozici� megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2400
      TabIndex        =   16
      Top             =   6735
      Width           =   3735
   End
   Begin VB.Label Label11 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd�sz� megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2400
      TabIndex        =   15
      Top             =   6255
      Width           =   3735
   End
   Begin VB.Label Label10 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd�sz�"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   195
      TabIndex        =   14
      Top             =   7215
      Width           =   1575
   End
   Begin VB.Line Line19 
      X1              =   2160
      X2              =   2160
      Y1              =   3330
      Y2              =   3795
   End
   Begin VB.Line Line18 
      X1              =   2160
      X2              =   2430
      Y1              =   3795
      Y2              =   3795
   End
   Begin VB.Line Line16 
      X1              =   2160
      X2              =   2430
      Y1              =   3315
      Y2              =   3315
   End
   Begin VB.Line Line8 
      X1              =   1815
      X2              =   2160
      Y1              =   3570
      Y2              =   3570
   End
   Begin VB.Line Line14 
      X1              =   2130
      X2              =   2130
      Y1              =   4395
      Y2              =   5835
   End
   Begin VB.Line Line9 
      X1              =   2145
      X2              =   2415
      Y1              =   5355
      Y2              =   5355
   End
   Begin VB.Line Line7 
      X1              =   2145
      X2              =   2415
      Y1              =   5820
      Y2              =   5820
   End
   Begin VB.Line Line6 
      X1              =   2145
      X2              =   2415
      Y1              =   4875
      Y2              =   4875
   End
   Begin VB.Line Line5 
      X1              =   2145
      X2              =   2415
      Y1              =   4395
      Y2              =   4395
   End
   Begin VB.Line Line4 
      X1              =   1800
      X2              =   2145
      Y1              =   5130
      Y2              =   5130
   End
   Begin VB.Line Line13 
      X1              =   2175
      X2              =   2445
      Y1              =   1335
      Y2              =   1335
   End
   Begin VB.Line Line12 
      X1              =   2175
      X2              =   2445
      Y1              =   1800
      Y2              =   1800
   End
   Begin VB.Line Line11 
      X1              =   2175
      X2              =   2430
      Y1              =   2250
      Y2              =   2250
   End
   Begin VB.Line Line10 
      X1              =   2175
      X2              =   2430
      Y1              =   870
      Y2              =   870
   End
   Begin VB.Line Line3 
      X1              =   2175
      X2              =   2460
      Y1              =   420
      Y2              =   420
   End
   Begin VB.Line Line2 
      X1              =   1815
      X2              =   2160
      Y1              =   1335
      Y2              =   1335
   End
   Begin VB.Line Line1 
      X1              =   2175
      X2              =   2175
      Y1              =   420
      Y2              =   2700
   End
   Begin VB.Label Label17 
      BackColor       =   &H00C0C0C0&
      Caption         =   "V�g�llapot megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   13
      Top             =   5655
      Width           =   3735
   End
   Begin VB.Label Label16 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd��llapot megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   12
      Top             =   5175
      Width           =   3735
   End
   Begin VB.Label Label15 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�tmeneti �llapotok list�ja"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   11
      Top             =   4695
      Width           =   3735
   End
   Begin VB.Label Label14 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�tmeneti �llapotok megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   10
      Top             =   4215
      Width           =   3735
   End
   Begin VB.Label Label13 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�llapotok"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   9
      Top             =   4935
      Width           =   1575
   End
   Begin VB.Label Label9 
      BackColor       =   &H00C0C0C0&
      Caption         =   "ABC lista"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   8
      Top             =   3630
      Width           =   3735
   End
   Begin VB.Label Label8 
      BackColor       =   &H00C0C0C0&
      Caption         =   "ABC megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   7
      Top             =   3135
      Width           =   3735
   End
   Begin VB.Label Label7 
      BackColor       =   &H00C0C0C0&
      Caption         =   "ABC"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   6
      Top             =   3390
      Width           =   1575
   End
   Begin VB.Label Label6 
      BackColor       =   &H00C0C0C0&
      Caption         =   "V�geredm�ny ment�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2445
      TabIndex        =   5
      Top             =   2070
      Width           =   3735
   End
   Begin VB.Label Label5 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Teljes feladat ment�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2460
      TabIndex        =   4
      Top             =   1620
      Width           =   3735
   End
   Begin VB.Label Label4 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Teljes feladat beolvas�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2445
      TabIndex        =   3
      Top             =   1170
      Width           =   3735
   End
   Begin VB.Label Label3 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Param�terek ment�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2445
      TabIndex        =   2
      Top             =   705
      Width           =   3735
   End
   Begin VB.Label Label2 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Param�terek beolvas�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   345
      Left            =   2445
      TabIndex        =   1
      Top             =   240
      Width           =   3735
   End
   Begin VB.Label Label1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   255
      TabIndex        =   0
      Top             =   1155
      Width           =   1575
   End
End
Attribute VB_Name = "frm_Menu1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Menu1         :  Megjelen�ti a men�rendszer 1. r�sz�t
'
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_End_Click()
        Unload frm_Menu1
        Unload frm_Menu2
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         K�vetkez� men�-ablak megjelen�t�se '
Private Sub cmd_Next_Click()
        frm_Menu2.Show
End Sub
' ------------------------------------------------------------------------------------------ '

