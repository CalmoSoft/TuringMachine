

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Matek_097 Turing-g�p m�k�d�s�nek list�ja.
                      =========================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : 0, 1

 Kezd� �llapot      : 0

 Kezd� sz�          : 111

 V�gs� �llapot      : 1

 Output             : 1111


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , * -> 1 , 1 , M
                      0 , 0 -> 0 , 0 , M
                      0 , 1 -> 0 , 1 , J
                      1 , 1 -> 1 , 1 , M


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

 001. -> **************111*************   0 , 1 -> 0 , 1   J  15
 002. -> **************111*************   0 , 1 -> 0 , 1   J  16
 003. -> **************111*************   0 , 1 -> 0 , 1   J  17
 004. -> **************111*************   0 , * -> 1 , 1   M  18
 005. -> **************1111************   