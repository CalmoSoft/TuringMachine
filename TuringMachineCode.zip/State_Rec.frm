VERSION 5.00
Begin VB.Form frm_State_Rec 
   BackColor       =   &H00808000&
   Caption         =   "�tmeneti �llapotok"
   ClientHeight    =   5010
   ClientLeft      =   660
   ClientTop       =   2850
   ClientWidth     =   3720
   ControlBox      =   0   'False
   HelpContextID   =   16
   LinkTopic       =   "Form4"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3720
   Begin VB.ListBox lst_State 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2880
      ItemData        =   "State_Rec.frx":0000
      Left            =   720
      List            =   "State_Rec.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   8
      ToolTipText     =   "Megadott �llapotok"
      Top             =   1800
      Width           =   855
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   4
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   3735
      Width           =   1230
   End
   Begin VB.CommandButton cmd_Clear 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�res"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   3
      ToolTipText     =   "T�rli az �sszes �llapotot"
      Top             =   2760
      Width           =   1230
   End
   Begin VB.CommandButton cmd_Remove 
      BackColor       =   &H00C0C0C0&
      Caption         =   "T�r�l"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   2
      ToolTipText     =   "T�rli a kijel�lt �llapotot"
      Top             =   1800
      Width           =   1230
   End
   Begin VB.CommandButton cmd_Add 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "R�gz�t"
      Default         =   -1  'True
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   1
      ToolTipText     =   "Felveszi a megadott �llapotot a list�ra"
      Top             =   1200
      Width           =   1230
   End
   Begin VB.TextBox txt_State 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   0
      ToolTipText     =   "Az automata �llapotainak megad�sa ; sorozat pl. : 0-9 vagy a-z"
      Top             =   1200
      Width           =   855
   End
   Begin VB.Label lbl_State_Msg 
      Alignment       =   2  'Center
      BackColor       =   &H000000FF&
      Caption         =   "Kezd� �llapot !"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   480
      TabIndex        =   9
      Top             =   120
      Visible         =   0   'False
      Width           =   2805
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   4455
      Left            =   495
      Shape           =   4  'Rounded Rectangle
      Top             =   495
      Width           =   2805
   End
   Begin VB.Label lbl_Display 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   2625
      TabIndex        =   7
      ToolTipText     =   "Az �llapotok sz�ma"
      Top             =   4440
      Width           =   375
   End
   Begin VB.Label lbl_Nr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Nr:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   1800
      TabIndex        =   6
      Top             =   4440
      Width           =   375
   End
   Begin VB.Label lbl_State1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "�tmeneti �llapotok"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   720
      TabIndex        =   5
      Top             =   720
      Width           =   2295
   End
End
Attribute VB_Name = "frm_State_Rec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_State_Rec     :  Az automata �llapotainak megad�sa
'
' ------------------------------------------------------------------------------------------ '
       Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                Egy elem hozz�ad�sa az �llapotok list�j�hoz '
Private Sub cmd_Add_Click()
        Dim i          As Integer           ' index-v�ltoz�
        Dim j          As Integer           ' index-v�ltoz�
        Dim int_Unique As Integer           ' Egyedi-e az elem ?
        Dim bln_Cond   As Boolean           ' Felt�tel vizsg�lathoz
        Dim bln_Series As Boolean           ' Sorozat megad�s�r�l van-e sz� ?
        Dim int_Left   As Integer           ' Sorozat els� eleme
        Dim int_Right  As Integer           ' Sorozat utols� eleme
        
        int_Unique = 0
        txt_State.SetFocus
        If Len(txt_State.Text) = 1 Then
           For i = 0 To lst_State.ListCount - 1
               If lst_State.List(i) = txt_State.Text Then
                  int_Unique = 1
                  Beep
               End If
           Next i
           If int_Unique = 0 Then
              lst_State.AddItem txt_State.Text
              txt_State.Text = ""
              txt_State.SetFocus
              lbl_Display.Caption = lst_State.ListCount
              lbl_State_Msg.Visible = False
           Else
              txt_State.Text = ""
              txt_State.SetFocus
           End If
        Else
           int_Left = Asc(Left(txt_State.Text, 1))
           int_Right = Asc(Right(txt_State.Text, 1))
           bln_Series = Len(txt_State.Text) = 3 And Mid(txt_State.Text, 2, 1) = "-" And _
                        int_Left < int_Right
           If bln_Series Then
              For i = int_Left To int_Right
                  int_Unique = 0
                  For j = 0 To lst_State.ListCount - 1
                      If lst_State.List(j) = Chr(i) Then
                         int_Unique = 1
                      End If
                  Next j
                  If int_Unique = 0 Then
                     lst_State.AddItem Chr(i)
                  End If
              Next i
              txt_State.Text = ""
              txt_State.SetFocus
              lbl_Display.Caption = lst_State.ListCount
              lbl_State_Msg.Visible = False
           End If
        End If
        If g_str_Mode = "T" Then
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0)
        Else
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0) And _
                          (frm_Turing_Start.chk_End.Value = 0)
        End If
        cmd_Clear.Enabled = bln_Cond
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Az �llapotok list�j�nak teljes t�rl�se '
Private Sub cmd_Clear_Click()
        Dim bln_Cond As Boolean             ' Felt�tel vizsg�lathoz
        
        If g_str_Mode = "T" Then
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0)
        Else
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0) And _
                          (frm_Turing_Start.chk_End.Value = 0)
        End If
        If bln_Cond Then
           lst_State.Clear
           lbl_Display.Caption = lst_State.ListCount
           txt_State.SetFocus
           lbl_State_Msg.Visible = False
           cmd_Remove.Enabled = (lst_State.ListCount > 0)
        End If
        If g_str_Mode = "T" Then
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0)
        Else
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0) And _
                          (frm_Turing_Start.chk_End.Value = 0)
        End If
        cmd_Clear.Enabled = bln_Cond
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        Dim i        As Integer             ' index-v�ltoz�
        Dim bln_Cond As Boolean             ' Felt�tel vizsg�lathoz
        
        frm_State_Rec.Hide
        bln_Cond = (lst_State.ListCount > 0)
        If bln_Cond Then
           frm_Turing_Start.chk_State.Value = 1
        Else
           frm_Turing_Start.chk_State.Value = 0
        End If
        frm_Turing_Start.mnu_State_List.Enabled = bln_Cond
        frm_Turing_Start.mnu_State_List2.Enabled = bln_Cond
        frm_Turing_Start.mnu_State_Begin.Enabled = bln_Cond
        frm_Turing_Start.mnu_State_Begin2.Enabled = bln_Cond
        If frm_Turing_Start.chk_ABC.Value = 1 Then
           frm_Turing_Start.mnu_Reg_Rec.Enabled = bln_Cond
           frm_Turing_Start.mnu_Reg_Rec2.Enabled = bln_Cond
           frm_Turing_Start.chk_Reg.Visible = bln_Cond
           frm_Turing_Start.lbl_Reg.Enabled = bln_Cond
        End If
        frm_Turing_Start.lbl_Begin.Enabled = bln_Cond
        frm_Turing_Start.chk_Begin.Visible = bln_Cond
        If g_str_Mode = "F" Then
           frm_Turing_Start.lbl_End.Enabled = bln_Cond
           frm_Turing_Start.chk_End.Visible = bln_Cond
           frm_Turing_Start.mnu_State_End.Enabled = bln_Cond
           frm_Turing_Start.mnu_State_End2.Enabled = bln_Cond
        End If
        If frm_Turing_Start.param() = 1 Then
           frm_Turing_Start.mnu_Param_Save.Enabled = bln_Cond
           frm_Turing_Start.mnu_Param_Save2.Enabled = bln_Cond
           frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = bln_Cond
        End If
        lbl_State_Msg.Visible = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   Egy elem t�rl�se az �llapotok list�j�b�l '
Private Sub cmd_Remove_Click()
        Dim int_State_Ind As Integer        ' Lista hanyadik elem�r�l van-sz� ?
        Dim str_State_Del As String         ' Lista melyik elem�r�l van-sz� ?
        
        int_State_Ind = lst_State.ListIndex
        str_State_Del = lst_State.List(int_State_Ind)
        If int_State_Ind >= 0 And str_State_Del <> g_vnt_Input And str_State_Del <> g_vnt_State_End Then
           lst_State.RemoveItem int_State_Ind
           lbl_Display.Caption = lst_State.ListCount
           lbl_State_Msg.Visible = False
        Else
           If frm_Turing_Start.chk_Begin = 1 And frm_Turing_Start.chk_End = 1 And str_State_Del = g_vnt_Input And str_State_Del = g_vnt_State_End Then ' CASE
              lbl_State_Msg.Caption = "Kezd�- �s v�g�llapot!"
              lbl_State_Msg.Visible = True
              Beep
           Else
              If frm_Turing_Start.chk_Begin = 1 And str_State_Del = g_vnt_Input Then
                 lbl_State_Msg.Caption = "Kezd��llapot!"
                 lbl_State_Msg.Visible = True
                 Beep
              End If
              If frm_Turing_Start.chk_End = 1 And str_State_Del = g_vnt_State_End Then
                 lbl_State_Msg.Caption = "V�g�llapot!"
                 lbl_State_Msg.Visible = True
                 Beep
              End If
           End If
        End If
        cmd_Remove.Enabled = False
        txt_State.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap aktiv�lsa '
Private Sub Form_Activate()
        Dim bln_Cond As Boolean             ' Felt�tel vizsg�lat�hoz
        
        txt_State.SetFocus
        lbl_State_Msg.Visible = False
        lbl_Display.Caption = lst_State.ListCount
        If g_str_Mode = "T" Then
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0)
        Else
           bln_Cond = (lst_State.ListCount > 0) And _
                          (frm_Turing_Start.chk_Begin.Value = 0) And _
                          (frm_Turing_Start.chk_End.Value = 0)
        End If
        cmd_Clear.Enabled = bln_Cond
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                          Lehet-e t�r�lni ? '
Private Sub lst_State_Click()
        Dim ind    As Integer
        Dim melyik As String
        
        ind = lst_State.ListIndex
        melyik = lst_State.List(ind)
        If ind >= 0 And melyik <> g_vnt_Input And melyik <> g_vnt_State_End Then
           lbl_State_Msg.Visible = False
           cmd_Remove.Enabled = True
        Else
           cmd_Remove.Enabled = False
           If frm_Turing_Start.chk_Begin = 1 And frm_Turing_Start.chk_End = 1 And _
              melyik = g_vnt_Input And melyik = g_vnt_State_End Then
              lbl_State_Msg.Caption = "Kezd�- �s v�g�llapot!"
              lbl_State_Msg.Visible = True
           Else
              If frm_Turing_Start.chk_Begin = 1 And melyik = g_vnt_Input Then
                 lbl_State_Msg.Caption = "Kezd��llapot!"
                 lbl_State_Msg.Visible = True
              End If
              If frm_Turing_Start.chk_End = 1 And melyik = g_vnt_State_End Then
                 lbl_State_Msg.Caption = "V�g�llapot!"
                 lbl_State_Msg.Visible = True
              End If
           End If
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        Lehet-e hozz�adni ? '
Private Sub txt_State_Change()
        Dim i          As Integer           ' index-v�ltoz�
        Dim j          As Integer           ' index-v�ltoz�
        Dim int_Unique As Integer           ' Egyedi-e az elem ?
        Dim bln_Series As Boolean           ' Sorozat megad�s�r�l van-e sz� ?
        Dim int_Left   As Integer           ' Sorozat els� eleme
        Dim int_Right  As Integer           ' Sorozat utols� eleme
        
        int_Unique = 0
        If Len(txt_State.Text) = 1 Then     ' Csak egy karakter szerepelhet
           For i = 0 To lst_State.ListCount - 1
               If lst_State.List(i) = txt_State.Text Then
                  int_Unique = 1
                  Beep
               End If
           Next i
        Else
           If Len(txt_State.Text) = 3 Then
              int_Left = Asc(Left(txt_State.Text, 1))
              int_Right = Asc(Right(txt_State.Text, 1))
              bln_Series = Mid(txt_State.Text, 2, 1) = "-" And int_Left < int_Right
              If bln_Series Then
                 int_Unique = 0
              Else
                 int_Unique = 1
              End If
           Else
              int_Unique = 1
           End If
        End If
        cmd_Add.Enabled = (int_Unique = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
