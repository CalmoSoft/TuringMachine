

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Gzs_Cube2 Turing-g�p m�k�d�s�nek list�ja.
                      =========================================



 A megadott ABC     : *, 0, A, B, C, D, E, f, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, v, V, W, X

 �tmeneti �llapotok : 0, 1, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X

 Kezd� �llapot      : 0

 Kezd� sz�          : B

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , A -> 1 , A , J
                      0 , B -> C , v , J
                      0 , C -> D , v , J
                      0 , D -> A , v , J
                      0 , E -> A , f , J
                      0 , F -> B , f , J
                      0 , G -> C , f , J
                      0 , H -> D , f , J
                      0 , I -> E , f , J
                      0 , J -> F , f , J
                      0 , K -> G , f , J
                      0 , L -> H , f , J
                      0 , M -> I , f , J
                      0 , N -> J , f , J
                      0 , O -> K , f , J
                      0 , P -> L , f , J
                      0 , Q -> M , v , J
                      0 , R -> N , v , J
                      0 , S -> O , v , J
                      0 , T -> P , v , J
                      0 , U -> G , v , J
                      0 , V -> H , v , J
                      0 , W -> E , v , J
                      0 , X -> F , v , J
                      1 , * -> 0 , 0 , J
                      A , * -> 1 , A , J
                      B , * -> C , v , J
                      C , * -> D , v , J
                      D , * -> A , v , J
                      E , * -> A , f , J
                      F , * -> B , f , J
                      G , * -> C , f , J
                      H , * -> D , f , J
                      I , * -> E , f , J
                      J , * -> F , f , J
                      K , * -> G , f , J
                      L , * -> H , f , J
                      M , * -> I , f , J
                      N , * -> J , f , J
                      O , * -> K , f , J
                      P , * -> L , f , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************B***************   