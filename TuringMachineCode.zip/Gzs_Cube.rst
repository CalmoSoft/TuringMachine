

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Gzs_Cube Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : *, 0, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X

 �tmeneti �llapotok : 0, 1, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X

 Kezd� �llapot      : 0

 Kezd� sz�          : H

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , A -> 1 , A , J
                      0 , B -> C , B , J
                      0 , C -> D , C , J
                      0 , D -> A , D , J
                      0 , E -> A , E , J
                      0 , F -> B , F , J
                      0 , G -> C , G , J
                      0 , H -> D , H , J
                      0 , I -> E , I , J
                      0 , J -> F , J , J
                      0 , K -> G , K , J
                      0 , L -> H , L , J
                      0 , M -> I , M , J
                      0 , N -> J , N , J
                      0 , O -> K , O , J
                      0 , P -> L , P , J
                      0 , Q -> M , Q , J
                      0 , R -> N , R , J
                      0 , S -> O , S , J
                      0 , T -> P , T , J
                      0 , U -> G , U , J
                      0 , V -> H , V , J
                      0 , W -> E , W , J
                      0 , X -> F , X , J
                      1 , * -> 0 , 0 , J
                      A , * -> 1 , A , J
                      B , * -> C , B , J
                      C , * -> D , C , J
                      D , * -> A , D , J
                      E , * -> A , E , J
                      F , * -> B , F , J
                      G , * -> C , G , J
                      H , * -> D , H , J
                      I , * -> E , I , J
                      J , * -> F , J , J
                      K , * -> G , K , J
                      L , * -> H , L , J
                      M , * -> I , M , J
                      N , * -> J , N , J
                      O , * -> K , O , J
                      P , * -> L , P , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************H***************   