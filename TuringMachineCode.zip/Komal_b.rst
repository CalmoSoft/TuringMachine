

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                          sz�m�t�g�pes szimul�ci�ja
                            Visual Basic 6.0-ban


 D�tum, id�         : 2002.08.05. 9:04:00


 Mott�              : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


 Funkci�            : 'Komal_02' Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : -, !, *, <, >, A, B, C, D

 �tmeneti �llapotok : 1, 2, A, B, C, D

 Kezd� �llapot      : B

 Kezd� sz�          : DABCD

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      1 , - -> 1 , - , J
                      1 , * -> 2 , * , B
                      1 , A -> A , - , B
                      1 , B -> B , - , B
                      1 , C -> C , - , B
                      1 , D -> D , - , B
                      2 , - -> 2 , * , B
                      2 , A -> A , A , J
                      2 , B -> B , B , J
                      2 , C -> C , C , J
                      2 , D -> D , D , J
                      A , - -> A , - , B
                      A , * -> A , < , M
                      A , A -> 1 , A , J
                      A , B -> 1 , B , J
                      A , C -> 1 , C , J
                      A , D -> 1 , D , J
                      B , - -> B , - , B
                      B , * -> B , < , M
                      B , A -> 1 , B , J
                      B , B -> 1 , A , J
                      B , C -> 1 , D , J
                      B , D -> 1 , C , J
                      C , - -> C , - , B
                      C , * -> C , < , M
                      C , A -> 1 , C , J
                      C , B -> 1 , D , J
                      C , C -> 1 , A , J
                      C , D -> 1 , B , J
                      D , - -> D , - , B
                      D , * -> D , < , M
                      D , A -> 1 , D , J
                      D , B -> 1 , C , J
                      D , C -> 1 , B , J
                      D , D -> 1 , A , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************DABCD***********   