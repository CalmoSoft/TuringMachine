VERSION 5.00
Begin VB.Form frm_Full_Save 
   BackColor       =   &H00808000&
   Caption         =   "Teljes feladat ment�se"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   3855
   ControlBox      =   0   'False
   HelpContextID   =   12
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3855
   Begin VB.TextBox txt_Full_Save 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   840
      TabIndex        =   2
      ToolTipText     =   "Az �llom�ny nev�nek megad�sa"
      Top             =   1680
      Width           =   2175
   End
   Begin VB.CommandButton cmd_File_Save 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File ment�se"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1020
      TabIndex        =   1
      ToolTipText     =   "A teljes feladat ment�se a megadott �llom�nyba"
      Top             =   2805
      Width           =   1815
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1020
      TabIndex        =   0
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   3510
      Width           =   1815
   End
   Begin VB.Shape fra_File_Save 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4095
      Left            =   480
      Shape           =   4  'Rounded Rectangle
      Top             =   345
      Width           =   2895
   End
   Begin VB.Label lbl_Param1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "File megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   840
      TabIndex        =   3
      Top             =   720
      Width           =   2175
   End
End
Attribute VB_Name = "frm_Full_Save"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Full_Save     :  Az automata be�ll�t�sainak ment�se egy l�p�sben
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                   Kil�p�s '
Private Sub cmd_Close_Click()
        frm_Full_Save.Hide
        frm_Turing_Start.msg ("")
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        Az �llom�ny ment�se '
Private Sub cmd_File_Save_Click()
            cmd_Full_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          Elmentett be�ll�t�sok bet�lt�se : '
'                                                              ABC lista, �llapotok list�ja, '
'                                                       kezd� �llapot, kezd� sz�, v�g�llapot '
Public Sub cmd_Full_Save_Click()
        Dim i             As Integer        ' index-v�ltoz�
        Dim j             As Integer        ' index-v�ltoz�
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz
            
        frm_Full_Save.Hide
        str_File_Name = txt_Full_Save.Text
        frm_Param_Save.txt_Param.Text = str_File_Name
        frm_Param_Save.cmd_File_Save_Click
        frm_Full_Save.Hide
        frm_Reg_Rec.txt_File_Save.Text = str_File_Name
        frm_Turing_Start.File_Save_Reg
        frm_Result_Save.txt_Param = str_File_Name
        frm_Result_Save.cmd_File_Save_Click
        frm_Turing_Start.lbl_File = str_File_Name
        frm_Full_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()

        If frm_Turing_Start.lbl_File <> "" Then
           txt_Full_Save = frm_Turing_Start.lbl_File
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
