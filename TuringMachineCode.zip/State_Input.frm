VERSION 5.00
Begin VB.Form frm_State_Input 
   BackColor       =   &H00808000&
   Caption         =   "Kezd� �llapot"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   2280
   ControlBox      =   0   'False
   HelpContextID   =   18
   LinkTopic       =   "Form6"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   2280
   Begin VB.ListBox lst_Begin 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2310
      ItemData        =   "State_Input.frx":0000
      Left            =   720
      List            =   "State_Input.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   0
      ToolTipText     =   "Az automata �llapotai"
      Top             =   1680
      Width           =   855
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   1
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4200
      Width           =   855
   End
   Begin VB.Shape fra_Kezdo 
      BorderWidth     =   2
      Height          =   4575
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   1575
   End
   Begin VB.Label lbl_Kezdo 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   720
      TabIndex        =   3
      ToolTipText     =   "Az automata kezd��llapot�nak megad�sa"
      Top             =   1320
      Width           =   855
   End
   Begin VB.Label lbl_ABC 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Kezd� �llapot"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   720
      TabIndex        =   2
      Top             =   480
      Width           =   855
   End
End
Attribute VB_Name = "frm_State_Input"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_State_Input   :  Az automata kezd� �llapota
'
' ------------------------------------------------------------------------------------------ '
       Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Public Sub cmd_Close_Click()
        If g_vnt_Input <> "" Then
           frm_State_Input.Hide
           frm_Turing_Start.chk_Begin.Value = 1
           If frm_Turing_Start.param() = 1 Then
              frm_Turing_Start.mnu_Param_Save.Enabled = True
              frm_Turing_Start.mnu_Param_Save2.Enabled = True
              frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
           End If
           If frm_Turing_Start.begin() = 1 Then
              frm_Turing_Start.mnu_Full_Save.Enabled = True
              frm_Turing_Start.mnu_Full_Save2.Enabled = True
              frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = True
           End If
        Else
           lst_Begin.SetFocus
           Beep
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             Kezd� �llapot megad�sa men�b�l '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
                
        lst_Begin.Clear
        For i = 1 To frm_State_Rec.lst_State.ListCount
            lst_Begin.AddItem _
            frm_State_Rec.lst_State.List(i - 1)
        Next i
        If g_vnt_Input <> "" Then
           For i = 1 To lst_Begin.ListCount
               If lst_Begin.List(i - 1) = g_vnt_Input Then
                  Exit For
               End If
           Next i
           lst_Begin.ListIndex = i - 1
        End If
        lbl_Kezdo.Caption = g_vnt_Input
        frm_Turing_Start.chk_Begin.Value = 0
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                     Kezd� �llapot megad�sa '
Public Sub lst_Begin_Click()
        If frm_State_Rec.lst_State.ListCount > 0 Then
           g_vnt_Input = lst_Begin.Text
           lbl_Kezdo.Caption = g_vnt_Input
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
