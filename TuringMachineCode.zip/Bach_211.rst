

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Bach_211 Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : a, b

 �tmeneti �llapotok : 1, 2

 Kezd� �llapot      : 1

 Kezd� sz�          : abba

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      1 , a -> 1 , a , J
                      1 , b -> 2 , b , J
                      2 , a -> 1 , a , J
                      2 , b -> 2 , b , B


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************abba************   1 , a -> 1 , a   J  15
 002. -> **************abba************   1 , b -> 2 , b   J  16
 003. -> **************abba************   2 , b -> 2 , b   B  17
 004. -> **************abba************   2 , b -> 2 , b   B  16
 005. -> **************abba************   2 , a -> 1 , a   J  15
 END. -> **************abba************         V�GE !