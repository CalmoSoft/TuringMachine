VERSION 5.00
Begin VB.Form frm_Result_Save 
   BackColor       =   &H00808000&
   Caption         =   "V�geredm�ny ment�se"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   3615
   ControlBox      =   0   'False
   HelpContextID   =   13
   LinkTopic       =   "Form15"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3615
   Begin VB.CommandButton cmd_Comment 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Megjegyz�s"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   967
      TabIndex        =   5
      ToolTipText     =   "Megjegyz�s hozz�f�z�se az �llom�nyhoz"
      Top             =   2738
      Width           =   1680
   End
   Begin VB.TextBox txt_Comment 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   405
      Left            =   720
      TabIndex        =   4
      ToolTipText     =   "Megjegyz�s be�r�sa"
      Top             =   2018
      Visible         =   0   'False
      Width           =   8535
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   967
      TabIndex        =   3
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   3938
      Width           =   1680
   End
   Begin VB.CommandButton cmd_File_Save 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File �r�sa"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   967
      TabIndex        =   1
      ToolTipText     =   "A megadott �llom�ny ment�se"
      Top             =   3338
      Width           =   1680
   End
   Begin VB.TextBox txt_Param 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   405
      Left            =   720
      TabIndex        =   0
      ToolTipText     =   "Az �llom�ny nev�nek megad�sa"
      Top             =   1418
      Width           =   2175
   End
   Begin VB.Label lbl_Param1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "File megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   728
      TabIndex        =   2
      Top             =   818
      Width           =   2175
   End
   Begin VB.Shape fra_File_Save 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4095
      Left            =   375
      Shape           =   4  'Rounded Rectangle
      Top             =   458
      Width           =   2895
   End
End
Attribute VB_Name = "frm_Result_Save"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Result_Save   :  Az automata szimul�ci�j�nak v�geredm�ny�nek ment�se
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
        Dim str_Comment    As String        ' Megjegyz�s az eredm�nyek ment�s�n�l
        Dim txtFile                         ' V�geredm�ny ment�s�n�l
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        frm_Turing_Start.msg ("")
        Unload frm_Result_Save
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                               Megjegyz�s �r�sa a ment�shez '
Private Sub cmd_Comment_Click()
        fra_File_Save.Width = 9255
        frm_Result_Save.Width = 10110
        txt_Comment.Visible = True
        txt_Comment.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        V�geredm�ny ment�se '
Public Sub cmd_File_Save_Click()
       Dim i         As Integer             ' index-v�ltoz�
       Dim j         As Integer             ' index-v�ltoz�
       Dim k         As Integer             ' index-v�ltoz�
       Dim str_Decor As String              ' D�sz�t�s
       Dim str_Count As String              ' Sz�ml�l�-sor fej�ll�shoz
       Dim str_Type  As String              ' �zemm�d ki�r�s�hoz
       Dim fso                              ' File ment�s�hez
                
       cmd_Close.Enabled = False
       str_Comment = txt_Comment
       Set fso = CreateObject("Scripting.FileSystemObject")
       If g_str_Mode = "T" Then
          Set txtFile = fso.CreateTextFile("C:\turing\" & txt_Param & ".rst", True)
       Else
          Set txtFile = fso.CreateTextFile("C:\turing\" & txt_Param & ".rsf", True)
       End If
       frm_Turing_Start.lbl_File = txt_Param '''
       line_feed (2)
       txtFile.WriteLine (" SimTuring 1.0      - Turing-g�p �s felismer� automat�k")
       txtFile.WriteLine ("                          sz�m�t�g�pes szimul�ci�ja")
       txtFile.WriteLine ("                            Visual Basic 6.0-ban")
       line_feed (2)
       txtFile.WriteLine (" D�tum, id�         : " & Now())
       line_feed (2)
       txtFile.WriteLine (" Mott�              : ") & _
                         ("'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'")
       txtFile.WriteLine ("                                      (David Gelernter)")
       line_feed (2)
       If g_str_Mode = "T" Then
          str_Type = "Turing-g�p"
       Else
          str_Type = "Felismer�-automata"
       End If
       txtFile.WriteLine (" Funkci�            : " & "'" & _
                         frm_Turing_Start.lbl_File.Caption & "' " & _
                          str_Type & " m�k�d�s�nek list�ja.")
       str_Decor = ""
       k = Len(str_Type) + Len(frm_Turing_Start.lbl_File.Caption) + 22
       For i = 1 To k
           str_Decor = str_Decor & "="
       Next i
       txtFile.WriteLine ("                      " & str_Decor)
       line_feed (2)
       
       If Len(str_Comment) > 0 Then
          txtFile.WriteLine (" Megjegyz�s         : " & str_Comment)
          line_feed (1)
       End If
       line_feed (1)
       txtFile.Write (" A megadott ABC     : ")
       j = frm_Abc_Rec.lst_ABC.ListCount
       For i = 1 To j - 1
           txtFile.Write (frm_Abc_Rec.lst_ABC.List(i - 1) & ", ")
       Next i
       txtFile.Write (frm_Abc_Rec.lst_ABC.List(i - 1))
       line_feed (2)
       txtFile.Write (" �tmeneti �llapotok : ")
       j = frm_State_Rec.lst_State.ListCount
       For i = 1 To j - 1
           txtFile.Write (frm_State_Rec.lst_State.List(i - 1) & ", ")
       Next i
       txtFile.Write (frm_State_Rec.lst_State.List(i - 1))
       line_feed (2)
       txtFile.Write (" Kezd� �llapot      : ")
       txtFile.Write (g_vnt_Input)
       line_feed (2)
       If g_str_Mode = "F" Then
          txtFile.Write (" V�g�llapot         : ")
          txtFile.Write (g_vnt_State_End)
          line_feed (2)
       End If
       txtFile.Write (" Kezd� sz�          : ")
       txtFile.Write (frm_Turing_Input.txt_Input)
       line_feed (2)
       txtFile.Write (" V�gs� �llapot      : ")
       txtFile.Write (frm_Result.lbl_Veg)
       line_feed (2)
       txtFile.Write (" Output             : ")
       txtFile.Write (frm_Result.lbl_Output)
       line_feed (2)
       txtFile.Write (" Fej kezd�poz�ci�ja : ")
       txtFile.Write (frm_Turing_Start.sld_Head.Value)
       line_feed (3)
       If g_str_Mode = "T" Then
          txtFile.Write (" Szab�lyok          : A1  BE   A2  KI  M")
       Else
          txtFile.Write (" Szab�lyok          : A1  BE   A2")
       End If
       line_feed (2)
       j = frm_Reg_Rec.lst_Reg.ListCount
       For i = 1 To j
           txtFile.WriteLine (Space(22) & _
                              Left(frm_Reg_Rec.lst_Reg.List(i - 1), 18))
       Next i
       line_feed (2)
       txtFile.Write ("         Az automata konfigur�ci�i  : ")
       If g_str_Mode = "T" Then
          txtFile.Write ("    A1  BE   A2  KI  M   F")
       Else
          txtFile.Write ("    A1  BE   A2  F")
       End If
       line_feed (2)
       str_Count = Space(9) & "123456789012345678901234567890"
       txtFile.WriteLine (str_Count)
       j = frm_Turing_Start.lst_Result_Window.ListCount
       For i = 1 To j - 1
           txtFile.WriteLine (frm_Turing_Start.lst_Result_Window.List(i - 1))
           If i Mod 10 = 0 Then
              txtFile.WriteLine (str_Count)
           End If
       Next i
       txtFile.Write (frm_Turing_Start.lst_Result_Window.List(j - 1))
       txtFile.Close
       
       frm_Result_Save.Width = 3750
       fra_File_Save.Width = 2895
       txt_Comment.Visible = False
       frm_Turing_Start.msg ("File ment�se befejez�d�tt")
       cmd_Close.Enabled = True
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                       File-n�v felk�n�l�sa '
Private Sub Form_Activate()
        txt_Param = frm_Turing_Start.lbl_File
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        txt_Param = frm_Turing_Start.lbl_File
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                  Soremel�s '
Public Function line_feed(n As Integer)
       Dim i As Integer                     ' index-v�ltoz�
       
       For i = 1 To n
           txtFile.WriteLine
       Next i
End Function
' ------------------------------------------------------------------------------------------ '

