

 SimTuring 1.0 - Turing-g�p �s felismer� automat�k
                 sz�m�t�g�pes szimul�ci�ja
                 Visual Basic 6.0-ban


 Traht_072 Turing-automata m�k�d�s�nek nyomtat�sa.



 A megadott ABC     : *, a, b, I

 �tmeneti �llapotok : !, 1, 2, 3, 4, 5

 Kezd� �llapot      : 1

 Kezd� sz�          : IIIIIIIIII

 Szab�lyok          : 1 , * -> 4 , * , J
                      1 , a -> 1 , a , B, 
                      1 , b -> 1 , b , B, 
                      1 , I -> 2 , a , M, 
                      2 , * -> 3 , * , B, 
                      2 , a -> 2 , a , J, 
                      2 , b -> 2 , b , J, 
                      2 , I -> 1 , b , M, 
                      3 , * -> 1 , * , J, 
                      3 , a -> 3 , I , B, 
                      3 , b -> 3 , * , B, 
                      3 , I -> 1 , I , J, 
                      4 , * -> ! , * , B, 
                      4 , a -> 4 , * , J, 
                      4 , b -> 4 , I , J, 
                      4 , I -> 1 , I , B, 


         Az automata konfigur�ci�i  : 

 00. -> **************IIIIIIIIII******   