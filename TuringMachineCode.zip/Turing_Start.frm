VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frm_Turing_Start 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00C0C0C0&
   Caption         =   "                                                                               SimTuring 1.0"
   ClientHeight    =   8310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   11880
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   8.25
      Charset         =   238
      Weight          =   700
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   LinkTopic       =   "Form1"
   Moveable        =   0   'False
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_Result 
      BackColor       =   &H00C0C0C0&
      Caption         =   "V�geredm�ny"
      Enabled         =   0   'False
      Height          =   375
      Left            =   9900
      TabIndex        =   136
      ToolTipText     =   "�j szimul�ci� kezdem�nyez�se"
      Top             =   60
      Width           =   1905
   End
   Begin MSComctlLib.Slider sld_Fej 
      Height          =   510
      Left            =   1650
      TabIndex        =   128
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   6480
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   900
      _Version        =   393216
      BorderStyle     =   1
      Min             =   1
      Max             =   30
      SelStart        =   1
      TickStyle       =   1
      Value           =   1
      TextPosition    =   1
   End
   Begin MSComctlLib.Slider sld_Head 
      Height          =   495
      Left            =   960
      TabIndex        =   124
      ToolTipText     =   "Fej pozici�j�nak be�ll�t�sa"
      Top             =   1920
      Visible         =   0   'False
      Width           =   375
      _ExtentX        =   661
      _ExtentY        =   873
      _Version        =   393216
      BorderStyle     =   1
      Min             =   2
      Max             =   29
      SelStart        =   15
      Value           =   15
   End
   Begin MSComctlLib.ImageList pic_Turing 
      Left            =   75
      Top             =   600
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   4
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Turing_Start.frx":0000
            Key             =   "Open"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Turing_Start.frx":0454
            Key             =   "Save"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Turing_Start.frx":08A8
            Key             =   "Menuk"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Turing_Start.frx":0CFC
            Key             =   "Kilep"
         EndProperty
      EndProperty
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   150
      Top             =   1305
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin MSComctlLib.ProgressBar prg_Turing 
      Height          =   255
      Left            =   600
      TabIndex        =   117
      ToolTipText     =   "A szimul�ci� id�beli lefut�s�t mutatja"
      Top             =   7440
      Width           =   10815
      _ExtentX        =   19076
      _ExtentY        =   450
      _Version        =   393216
      BorderStyle     =   1
      Appearance      =   1
   End
   Begin MSComctlLib.Slider sld_Turing 
      Height          =   495
      Left            =   960
      TabIndex        =   116
      ToolTipText     =   "A kezd�pozici� be�ll�t�sa"
      Top             =   1920
      Visible         =   0   'False
      Width           =   10095
      _ExtentX        =   17806
      _ExtentY        =   873
      _Version        =   393216
      BorderStyle     =   1
      Min             =   2
      Max             =   29
      SelStart        =   15
      Value           =   15
   End
   Begin VB.CheckBox chk_ABC 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   85
      ToolTipText     =   "ABC megad�sa megt�rt�nt-e ?"
      Top             =   4290
      Width           =   255
   End
   Begin VB.CheckBox chk_Reg 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   84
      ToolTipText     =   "Szab�lyok  megad�sa megt�rt�nt-e ?"
      Top             =   6690
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CheckBox chk_Input 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   83
      ToolTipText     =   "Input (kezd�sz�)  megad�sa megt�rt�nt-e ?"
      Top             =   6210
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CheckBox chk_End 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   82
      ToolTipText     =   "V�g�llapot megad�sa megt�rt�nt-e ?"
      Top             =   5730
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CheckBox chk_Begin 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   81
      ToolTipText     =   "Kezd��llapot megad�sa megt�rt�nt-e ?"
      Top             =   5250
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CheckBox chk_State 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   9510
      TabIndex        =   80
      ToolTipText     =   "�llapotok megad�sa megt�rt�nt-e ?"
      Top             =   4770
      Width           =   255
   End
   Begin VB.CommandButton cmd_Tur_Exec 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Lej�tsz�s"
      Enabled         =   0   'False
      Height          =   375
      Left            =   8400
      TabIndex        =   77
      ToolTipText     =   "Szimul�ci� teljes v�grehajt�sa egy l�p�sben"
      Top             =   5160
      Width           =   975
   End
   Begin VB.CommandButton cmd_New_Sim 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�j szimul�ci�"
      Height          =   375
      Left            =   8205
      TabIndex        =   75
      ToolTipText     =   "�j szimul�ci� kezdem�nyez�se"
      Top             =   60
      Width           =   1590
   End
   Begin VB.CommandButton cmd_Tur_New 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�j sz�"
      Enabled         =   0   'False
      Height          =   375
      HelpContextID   =   20
      Left            =   8385
      TabIndex        =   72
      ToolTipText     =   "�j input (kezd�sz�) megad�sa"
      Top             =   5640
      Width           =   975
   End
   Begin VB.CommandButton cmd_Tur_Iter 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Iter�ci�"
      Enabled         =   0   'False
      Height          =   375
      HelpContextID   =   24
      Left            =   8385
      TabIndex        =   71
      ToolTipText     =   "Az output (v�geredm�ny)  lesz az �j input (kezd�sz�)"
      Top             =   6120
      Width           =   975
   End
   Begin VB.CommandButton cmd_Tur_End 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kil�p"
      Height          =   375
      Left            =   8385
      TabIndex        =   70
      ToolTipText     =   "Program befejez�se"
      Top             =   6600
      Width           =   975
   End
   Begin VB.CommandButton cmd_Tur_Step 
      BackColor       =   &H00C0C0C0&
      Caption         =   "L�p�s"
      Enabled         =   0   'False
      Height          =   375
      Left            =   8385
      TabIndex        =   69
      ToolTipText     =   "L�p�senk�nti szimul�ci�"
      Top             =   4680
      Width           =   975
   End
   Begin VB.CommandButton cmd_Tur_Start 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kezd�s"
      Enabled         =   0   'False
      Height          =   375
      Left            =   8400
      TabIndex        =   68
      ToolTipText     =   "Szimul�ci� indul"
      Top             =   4200
      Width           =   975
   End
   Begin VB.Timer tmr_Turing 
      Interval        =   500
      Left            =   11400
      Top             =   600
   End
   Begin VB.ListBox lst_Result_Window 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      CausesValidation=   0   'False
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   2055
      ItemData        =   "Turing_Start.frx":1150
      Left            =   825
      List            =   "Turing_Start.frx":1152
      TabIndex        =   59
      TabStop         =   0   'False
      ToolTipText     =   "Egyszeres kattint�sra : a fej�ll�st mutatja. K�tszeres kattint�sra : visszal�p�s addig a konfigur�ci�ig."
      Top             =   4440
      Width           =   7215
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   30
      Left            =   11040
      TabIndex        =   58
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   29
      Left            =   10680
      TabIndex        =   57
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   28
      Left            =   10320
      TabIndex        =   56
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   27
      Left            =   9960
      TabIndex        =   55
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   26
      Left            =   9600
      TabIndex        =   54
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   25
      Left            =   9240
      TabIndex        =   53
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   24
      Left            =   8880
      TabIndex        =   52
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   23
      Left            =   8520
      TabIndex        =   51
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   22
      Left            =   8160
      TabIndex        =   50
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   21
      Left            =   7800
      TabIndex        =   49
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   20
      Left            =   7440
      TabIndex        =   48
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   19
      Left            =   7080
      TabIndex        =   47
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   18
      Left            =   6720
      TabIndex        =   46
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   17
      Left            =   6360
      TabIndex        =   45
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   16
      Left            =   6000
      TabIndex        =   44
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   15
      Left            =   5640
      TabIndex        =   43
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   14
      Left            =   5280
      TabIndex        =   42
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   13
      Left            =   4920
      TabIndex        =   41
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   12
      Left            =   4560
      TabIndex        =   40
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   11
      Left            =   4200
      TabIndex        =   39
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   10
      Left            =   3840
      TabIndex        =   38
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   9
      Left            =   3480
      TabIndex        =   37
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   8
      Left            =   3120
      TabIndex        =   36
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   35
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   6
      Left            =   2400
      TabIndex        =   34
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   5
      Left            =   2040
      TabIndex        =   33
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   4
      Left            =   1680
      TabIndex        =   32
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   1320
      TabIndex        =   31
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   960
      TabIndex        =   30
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.CommandButton cmd_Turing 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fej"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   600
      TabIndex        =   29
      ToolTipText     =   "Az automata vez�rl�je. Az automata aktu�lis �llapota. Kattint�sra v�grehajtja a k�vetkez� l�p�st."
      Top             =   3600
      Visible         =   0   'False
      Width           =   375
   End
   Begin MSComctlLib.Slider sld_Sim 
      Height          =   630
      Left            =   600
      TabIndex        =   134
      Top             =   3375
      Visible         =   0   'False
      Width           =   10830
      _ExtentX        =   19103
      _ExtentY        =   1111
      _Version        =   393216
      Enabled         =   0   'False
      Min             =   1
      Max             =   30
      SelStart        =   1
      TickStyle       =   1
      Value           =   1
   End
   Begin MSComctlLib.Toolbar tlb_Turing 
      Height          =   390
      Left            =   45
      TabIndex        =   135
      ToolTipText     =   $"Turing_Start.frx":1154
      Top             =   60
      Width           =   4965
      _ExtentX        =   8758
      _ExtentY        =   688
      ButtonWidth     =   1588
      ButtonHeight    =   582
      Appearance      =   1
      TextAlignment   =   1
      ImageList       =   "pic_Turing"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   5
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Nyit"
            Key             =   "Open"
            ImageIndex      =   1
            Style           =   5
            BeginProperty ButtonMenus {66833FEC-8583-11D1-B16A-00C0F0283628} 
               NumButtonMenus  =   3
               BeginProperty ButtonMenu1 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "mnu_Param_Open"
                  Text            =   "Param�terek beolvas�sa..."
               EndProperty
               BeginProperty ButtonMenu2 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "mnu_Reg_Open"
                  Text            =   "Szab�lyok beolvas�sa..."
               EndProperty
               BeginProperty ButtonMenu3 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "mnu_Full_Open"
                  Text            =   "Teljes feladat beolvas�sa..."
               EndProperty
            EndProperty
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Ment"
            Key             =   "Save"
            ImageIndex      =   2
            Style           =   5
            BeginProperty ButtonMenus {66833FEC-8583-11D1-B16A-00C0F0283628} 
               NumButtonMenus  =   3
               BeginProperty ButtonMenu1 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Enabled         =   0   'False
                  Key             =   "mnu_Param_Save"
                  Text            =   "Param�terek ment�se..."
               EndProperty
               BeginProperty ButtonMenu2 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Enabled         =   0   'False
                  Key             =   "mnu_Full_Save"
                  Text            =   "Teljes feladat ment�se..."
               EndProperty
               BeginProperty ButtonMenu3 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Enabled         =   0   'False
                  Key             =   "mnu_Result_Save"
                  Text            =   "V�geredm�ny ment�se..."
               EndProperty
            EndProperty
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "P�ld�k"
            Key             =   "Peldak"
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Men�"
            Key             =   "Menuk"
            ImageIndex      =   3
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Kil�p"
            Key             =   "Kilep"
            ImageIndex      =   4
         EndProperty
      EndProperty
      MouseIcon       =   "Turing_Start.frx":1208
   End
   Begin VB.Line Line3 
      BorderWidth     =   2
      X1              =   9840
      X2              =   9840
      Y1              =   0
      Y2              =   480
   End
   Begin VB.Line Line2 
      BorderWidth     =   2
      X1              =   8145
      X2              =   8145
      Y1              =   0
      Y2              =   480
   End
   Begin VB.Line Line1 
      BorderWidth     =   2
      X1              =   15
      X2              =   15
      Y1              =   0
      Y2              =   480
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   0
      X1              =   795
      X2              =   11235
      Y1              =   2760
      Y2              =   2760
   End
   Begin VB.Line lin_Inter 
      BorderWidth     =   2
      X1              =   795
      X2              =   11235
      Y1              =   3600
      Y2              =   3600
   End
   Begin VB.Line Line15 
      X1              =   630
      X2              =   11435
      Y1              =   3000
      Y2              =   3000
   End
   Begin VB.Line Line12 
      BorderWidth     =   2
      X1              =   0
      X2              =   11865
      Y1              =   15
      Y2              =   15
   End
   Begin VB.Line Line14 
      X1              =   11415
      X2              =   11415
      Y1              =   3000
      Y2              =   3375
   End
   Begin VB.Line Line13 
      BorderWidth     =   2
      X1              =   630
      X2              =   11435
      Y1              =   3360
      Y2              =   3360
   End
   Begin VB.Line Line11 
      BorderWidth     =   3
      X1              =   0
      X2              =   12000
      Y1              =   0
      Y2              =   0
   End
   Begin VB.Line Line10 
      X1              =   840
      X2              =   8040
      Y1              =   6975
      Y2              =   6975
   End
   Begin VB.Line Line9 
      BorderColor     =   &H00808080&
      X1              =   8040
      X2              =   8040
      Y1              =   4200
      Y2              =   4440
   End
   Begin VB.Line Line8 
      BorderColor     =   &H00808080&
      X1              =   840
      X2              =   840
      Y1              =   4200
      Y2              =   4440
   End
   Begin VB.Shape Shape3 
      BackColor       =   &H00808080&
      BackStyle       =   1  'Opaque
      Height          =   2790
      Left            =   8040
      Top             =   4200
      Width           =   255
   End
   Begin VB.Shape Shape2 
      BackColor       =   &H00808080&
      BackStyle       =   1  'Opaque
      Height          =   2790
      Left            =   600
      Top             =   4200
      Width           =   255
   End
   Begin VB.Label lbl_Result_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   285
      Left            =   7905
      TabIndex        =   132
      ToolTipText     =   "�llapotok sz�ma"
      Top             =   6990
      Width           =   375
   End
   Begin VB.Label lbl_Window 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Nr :"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   210
      Left            =   630
      TabIndex        =   131
      Top             =   6990
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Big 
      Alignment       =   2  'Center
      BackColor       =   &H00808080&
      Caption         =   "Nagy�t�s"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   18.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   5145
      TabIndex        =   130
      ToolTipText     =   "Az eredm�nyablak nagy�t�sa"
      Top             =   6495
      Width           =   2895
   End
   Begin VB.Label lbl_Head 
      Alignment       =   2  'Center
      BackColor       =   &H00808080&
      Caption         =   "FEJ"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   20.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   510
      Left            =   840
      TabIndex        =   129
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   6480
      Width           =   810
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   5415
      Left            =   150
      Shape           =   4  'Rounded Rectangle
      Top             =   1935
      Width           =   11535
   End
   Begin VB.Label lbl_Konf_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "  Nr.          Konfigur�ci�k :            A1  BE   A2  F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   840
      TabIndex        =   127
      ToolTipText     =   " A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, F = Fej pozici�ja "
      Top             =   4200
      Visible         =   0   'False
      Width           =   7215
   End
   Begin VB.Label lbl_Konf_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "  Nr.          Konfigur�ci�k :            A1  BE   A2  KI  M   F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   840
      TabIndex        =   126
      ToolTipText     =   $"Turing_Start.frx":165A
      Top             =   4200
      Width           =   7215
   End
   Begin VB.Label lbl_Percent 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7320
      TabIndex        =   125
      ToolTipText     =   "A szimul�ci� lefoly�s�nak �llapota %-ban"
      Top             =   7800
      Width           =   975
   End
   Begin VB.Line Line7 
      BorderWidth     =   2
      X1              =   5055
      X2              =   5055
      Y1              =   0
      Y2              =   480
   End
   Begin VB.Line Line5 
      BorderWidth     =   2
      X1              =   0
      X2              =   11865
      Y1              =   480
      Y2              =   480
   End
   Begin VB.Line Line6 
      BorderWidth     =   2
      X1              =   11865
      X2              =   11865
      Y1              =   0
      Y2              =   450
   End
   Begin VB.Line Line16 
      BorderWidth     =   3
      X1              =   0
      X2              =   12000
      Y1              =   0
      Y2              =   0
   End
   Begin VB.Line lin_2 
      BorderWidth     =   3
      X1              =   6000
      X2              =   6000
      Y1              =   7340
      Y2              =   7800
   End
   Begin VB.Line lin_3 
      X1              =   8640
      X2              =   8640
      Y1              =   7320
      Y2              =   7800
   End
   Begin VB.Line lin_1 
      X1              =   3255
      X2              =   3255
      Y1              =   7320
      Y2              =   7800
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H0000FF00&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   6
      Left            =   11400
      TabIndex        =   123
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7920
      Width           =   615
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   5
      Left            =   11400
      TabIndex        =   122
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7680
      Width           =   615
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H000000FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   4
      Left            =   11400
      TabIndex        =   121
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7440
      Width           =   615
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H0000FF00&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   3
      Left            =   0
      TabIndex        =   120
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7920
      Width           =   615
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H00FFFFFF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   2
      Left            =   0
      TabIndex        =   119
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7680
      Width           =   615
   End
   Begin VB.Label lbl_hu 
      BackColor       =   &H000000FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   0
      TabIndex        =   118
      ToolTipText     =   """Be�ll�t�sok"" men�pontban letilthat�"
      Top             =   7440
      Width           =   615
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "30"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   30
      Left            =   11040
      TabIndex        =   115
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "29"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   29
      Left            =   10680
      TabIndex        =   114
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "28"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   28
      Left            =   10320
      TabIndex        =   113
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "27"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   27
      Left            =   9960
      TabIndex        =   112
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "26"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   26
      Left            =   9600
      TabIndex        =   111
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "25"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   25
      Left            =   9240
      TabIndex        =   110
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "24"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   24
      Left            =   8880
      TabIndex        =   109
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "23"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   23
      Left            =   8520
      TabIndex        =   108
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "22"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   22
      Left            =   8160
      TabIndex        =   107
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "21"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   21
      Left            =   7800
      TabIndex        =   106
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "20"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   20
      Left            =   7440
      TabIndex        =   105
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "19"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   19
      Left            =   7080
      TabIndex        =   104
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "18"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   18
      Left            =   6720
      TabIndex        =   103
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "17"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   17
      Left            =   6360
      TabIndex        =   102
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "16"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   16
      Left            =   6000
      TabIndex        =   101
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "15"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   15
      Left            =   5640
      TabIndex        =   100
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "14"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   14
      Left            =   5295
      TabIndex        =   99
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "13"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   13
      Left            =   4935
      TabIndex        =   98
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "12"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   12
      Left            =   4575
      TabIndex        =   97
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "11"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   11
      Left            =   4215
      TabIndex        =   96
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "10"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   10
      Left            =   3825
      TabIndex        =   95
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   405
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "9"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   9
      Left            =   3480
      TabIndex        =   94
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   8
      Left            =   3120
      TabIndex        =   93
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   92
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   6
      Left            =   2400
      TabIndex        =   91
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   5
      Left            =   2040
      TabIndex        =   90
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   4
      Left            =   1680
      TabIndex        =   89
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   3
      Left            =   1320
      TabIndex        =   88
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   2
      Left            =   960
      TabIndex        =   87
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Label lbl_Prev 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Index           =   1
      Left            =   600
      TabIndex        =   86
      ToolTipText     =   "El�z� �llapot, el�z� bemenet az el�z� pozici� felett"
      Top             =   2400
      Visible         =   0   'False
      Width           =   375
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   1
      Visible         =   0   'False
      X1              =   780
      X2              =   780
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   2
      Visible         =   0   'False
      X1              =   1140
      X2              =   1140
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   3
      Visible         =   0   'False
      X1              =   1500
      X2              =   1500
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   4
      Visible         =   0   'False
      X1              =   1860
      X2              =   1860
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   5
      Visible         =   0   'False
      X1              =   2220
      X2              =   2220
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   6
      Visible         =   0   'False
      X1              =   2580
      X2              =   2580
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   7
      Visible         =   0   'False
      X1              =   2940
      X2              =   2940
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   8
      Visible         =   0   'False
      X1              =   3300
      X2              =   3300
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   9
      Visible         =   0   'False
      X1              =   3660
      X2              =   3660
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   10
      Visible         =   0   'False
      X1              =   4020
      X2              =   4020
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   11
      Visible         =   0   'False
      X1              =   4380
      X2              =   4380
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   12
      Visible         =   0   'False
      X1              =   4740
      X2              =   4740
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   13
      Visible         =   0   'False
      X1              =   5100
      X2              =   5100
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   14
      Visible         =   0   'False
      X1              =   5460
      X2              =   5460
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   15
      Visible         =   0   'False
      X1              =   5820
      X2              =   5820
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   16
      Visible         =   0   'False
      X1              =   6180
      X2              =   6180
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   17
      Visible         =   0   'False
      X1              =   6540
      X2              =   6540
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   18
      Visible         =   0   'False
      X1              =   6900
      X2              =   6900
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   19
      Visible         =   0   'False
      X1              =   7260
      X2              =   7260
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   20
      Visible         =   0   'False
      X1              =   7620
      X2              =   7620
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   21
      Visible         =   0   'False
      X1              =   7980
      X2              =   7980
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   22
      Visible         =   0   'False
      X1              =   8340
      X2              =   8340
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   23
      Visible         =   0   'False
      X1              =   8700
      X2              =   8700
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   24
      Visible         =   0   'False
      X1              =   9060
      X2              =   9060
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   25
      Visible         =   0   'False
      X1              =   9420
      X2              =   9420
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   26
      Visible         =   0   'False
      X1              =   9780
      X2              =   9780
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   27
      Visible         =   0   'False
      X1              =   10140
      X2              =   10140
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   28
      Visible         =   0   'False
      X1              =   10500
      X2              =   10500
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   29
      Visible         =   0   'False
      X1              =   10860
      X2              =   10860
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Line lin_Prev 
      BorderWidth     =   2
      Index           =   30
      Visible         =   0   'False
      X1              =   11220
      X2              =   11220
      Y1              =   2760
      Y2              =   3000
   End
   Begin VB.Label lbl_Mode 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6180
      TabIndex        =   79
      ToolTipText     =   "�zemm�d megjelen�t�se - Kattint�sra �tv�lt"
      Top             =   60
      Width           =   1890
   End
   Begin VB.Label lbl_Mode2 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      Caption         =   "�zemm�d :"
      Height          =   330
      Left            =   5100
      TabIndex        =   78
      Top             =   135
      Width           =   1155
   End
   Begin VB.Label lbl_End 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "V�g�llapot"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   9840
      TabIndex        =   76
      ToolTipText     =   "Kattint�sra indul vagy az ""�llapotok"" men�pontb�l"
      Top             =   5640
      Width           =   1560
   End
   Begin VB.Label lbl_File 
      Alignment       =   2  'Center
      BackColor       =   &H00800000&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "New"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   8400
      TabIndex        =   74
      ToolTipText     =   "Az aktu�lis feladat neve"
      Top             =   7800
      Width           =   3015
   End
   Begin VB.Label lbl_Msg 
      Alignment       =   2  'Center
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   600
      TabIndex        =   73
      ToolTipText     =   "�zenetek megjelen�t�se"
      Top             =   7800
      Width           =   6615
   End
   Begin VB.Label lbl_Sim_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Turing-g�p �s felismer� automat�k sz�m�t�g�pes szimul�ci�ja"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   2640
      TabIndex        =   67
      ToolTipText     =   """A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa"" (David Gelernter)"
      Top             =   1020
      Width           =   6750
   End
   Begin VB.Label lbl_Date 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   375
      Left            =   630
      TabIndex        =   66
      ToolTipText     =   """A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa"" (David Gelernter)"
      Top             =   1020
      Width           =   1560
   End
   Begin VB.Label lbl_Time 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   375
      Left            =   9840
      TabIndex        =   65
      ToolTipText     =   """A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa"" (David Gelernter)"
      Top             =   1020
      Width           =   1560
   End
   Begin VB.Label lbl_Reg 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Szab�lyok"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   390
      Left            =   9840
      TabIndex        =   64
      ToolTipText     =   "Kattint�sra indul vagy a ""Szab�lyok"" men�pontb�l"
      Top             =   6600
      Width           =   1560
   End
   Begin VB.Label lbl_Input 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Kezd�sz�"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   9840
      TabIndex        =   63
      ToolTipText     =   "Kattint�sra indul vagy a ""Kezd� sz�"" men�pontb�l"
      Top             =   6135
      Width           =   1560
   End
   Begin VB.Label lbl_Begin 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Kezd��llapot"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   9840
      TabIndex        =   62
      ToolTipText     =   "Kattint�sra indul vagy az ""�llapotok"" men�pontb�l"
      Top             =   5160
      Width           =   1560
   End
   Begin VB.Label lbl_State 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "�llapotok"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   9840
      TabIndex        =   61
      ToolTipText     =   "Kattint�sra indul vagy az ""�llapotok"" men�pontb�l"
      Top             =   4680
      Width           =   1560
   End
   Begin VB.Label lbl_ABC 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "ABC"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   9840
      TabIndex        =   60
      ToolTipText     =   "Kattint�sra indul  vagy az  ""ABC"" menupontb�l "
      Top             =   4200
      Width           =   1560
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   30
      Visible         =   0   'False
      X1              =   11220
      X2              =   11220
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   29
      Visible         =   0   'False
      X1              =   10860
      X2              =   10860
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   28
      Visible         =   0   'False
      X1              =   10500
      X2              =   10500
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   27
      Visible         =   0   'False
      X1              =   10140
      X2              =   10140
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   26
      Visible         =   0   'False
      X1              =   9780
      X2              =   9780
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   25
      Visible         =   0   'False
      X1              =   9420
      X2              =   9420
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   24
      Visible         =   0   'False
      X1              =   9060
      X2              =   9060
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   23
      Visible         =   0   'False
      X1              =   8700
      X2              =   8700
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   22
      Visible         =   0   'False
      X1              =   8340
      X2              =   8340
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   21
      Visible         =   0   'False
      X1              =   7980
      X2              =   7980
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   20
      Visible         =   0   'False
      X1              =   7620
      X2              =   7620
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   19
      Visible         =   0   'False
      X1              =   7260
      X2              =   7260
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   18
      Visible         =   0   'False
      X1              =   6900
      X2              =   6900
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   17
      Visible         =   0   'False
      X1              =   6540
      X2              =   6540
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   16
      Visible         =   0   'False
      X1              =   6180
      X2              =   6180
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   15
      Visible         =   0   'False
      X1              =   5820
      X2              =   5820
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   14
      Visible         =   0   'False
      X1              =   5460
      X2              =   5460
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   13
      Visible         =   0   'False
      X1              =   5100
      X2              =   5100
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   12
      Visible         =   0   'False
      X1              =   4740
      X2              =   4740
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   11
      Visible         =   0   'False
      X1              =   4380
      X2              =   4380
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   10
      Visible         =   0   'False
      X1              =   4020
      X2              =   4020
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   9
      Visible         =   0   'False
      X1              =   3660
      X2              =   3660
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   8
      Visible         =   0   'False
      X1              =   3300
      X2              =   3300
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   7
      Visible         =   0   'False
      X1              =   2940
      X2              =   2940
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   6
      Visible         =   0   'False
      X1              =   2580
      X2              =   2580
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   5
      Visible         =   0   'False
      X1              =   2220
      X2              =   2220
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   4
      Visible         =   0   'False
      X1              =   1860
      X2              =   1860
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   3
      Visible         =   0   'False
      X1              =   1500
      X2              =   1500
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   2
      Visible         =   0   'False
      X1              =   1140
      X2              =   1140
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Line lin_Turing 
      BorderWidth     =   3
      Index           =   1
      Visible         =   0   'False
      X1              =   780
      X2              =   780
      Y1              =   3360
      Y2              =   3600
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "30"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   30
      Left            =   11040
      TabIndex        =   28
      ToolTipText     =   "Az automata szalagj�nak 30. pozici�ja - KATTINT�SRA : Fej�ll�s a kezd�sz� v�g�n"
      Top             =   3000
      WhatsThisHelpID =   22
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "29"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   29
      Left            =   10680
      TabIndex        =   27
      ToolTipText     =   "Az automata szalagj�nak 29. pozici�ja - KATTINT�SRA : Fej�ll�s megad�sa a kezd�sz�n bel�l"
      Top             =   3000
      WhatsThisHelpID =   22
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "28"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   28
      Left            =   10320
      TabIndex        =   26
      ToolTipText     =   "Az automata szalagj�nak 28. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "27"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   27
      Left            =   9960
      TabIndex        =   25
      ToolTipText     =   "Az automata szalagj�nak 27. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "26"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   26
      Left            =   9600
      TabIndex        =   24
      ToolTipText     =   "Az automata szalagj�nak 26. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "25"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   25
      Left            =   9240
      TabIndex        =   23
      ToolTipText     =   "Az automata szalagj�nak 25. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "24"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   24
      Left            =   8880
      TabIndex        =   22
      ToolTipText     =   "Az automata szalagj�nak 24. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "23"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   23
      Left            =   8520
      TabIndex        =   21
      ToolTipText     =   "Az automata szalagj�nak 23. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "22"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   22
      Left            =   8160
      TabIndex        =   20
      ToolTipText     =   "Az automata szalagj�nak 22. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "21"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   21
      Left            =   7800
      TabIndex        =   19
      ToolTipText     =   "Az automata szalagj�nak 21. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "20"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   20
      Left            =   7440
      TabIndex        =   18
      ToolTipText     =   "Az automata szalagj�nak 20. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "19"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   19
      Left            =   7080
      TabIndex        =   17
      ToolTipText     =   "Az automata szalagj�nak 19. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "18"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   18
      Left            =   6720
      TabIndex        =   16
      ToolTipText     =   "Az automata szalagj�nak 18. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "17"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   17
      Left            =   6360
      TabIndex        =   15
      ToolTipText     =   "Az automata szalagj�nak 17. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "16"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   16
      Left            =   6000
      TabIndex        =   14
      ToolTipText     =   "Az automata szalagj�nak 16. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "15"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   15
      Left            =   5640
      TabIndex        =   13
      ToolTipText     =   "Az automata szalagj�nak 15. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "14"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   14
      Left            =   5280
      TabIndex        =   12
      ToolTipText     =   "Az automata szalagj�nak 14. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "13"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   13
      Left            =   4920
      TabIndex        =   11
      ToolTipText     =   "Az automata szalagj�nak 13. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "12"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   12
      Left            =   4560
      TabIndex        =   10
      ToolTipText     =   "Az automata szalagj�nak 12. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "11"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   11
      Left            =   4200
      TabIndex        =   9
      ToolTipText     =   "Az automata szalagj�nak 11. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "10"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   10
      Left            =   3855
      TabIndex        =   8
      ToolTipText     =   "Az automata szalagj�nak 10. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "9"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   9
      Left            =   3480
      TabIndex        =   7
      ToolTipText     =   "Az automata szalagj�nak 9. pozici�ja"
      Top             =   3000
      Width           =   405
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   8
      Left            =   3120
      TabIndex        =   6
      ToolTipText     =   "Az automata szalagj�nak 8. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   7
      Left            =   2760
      TabIndex        =   5
      ToolTipText     =   "Az automata szalagj�nak 7. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   6
      Left            =   2400
      TabIndex        =   4
      ToolTipText     =   "Az automata szalagj�nak 6. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   5
      Left            =   2040
      TabIndex        =   3
      ToolTipText     =   "Az automata szalagj�nak 5. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   4
      Left            =   1680
      TabIndex        =   2
      ToolTipText     =   "Az automata szalagj�nak 4. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   3
      Left            =   1320
      TabIndex        =   1
      ToolTipText     =   "Az automata szalagj�nak 3. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   2
      Left            =   960
      TabIndex        =   0
      ToolTipText     =   "Az automata szalagj�nak 2. pozici�ja"
      Top             =   3000
      Width           =   390
   End
   Begin VB.Label lbl_Turing 
      Alignment       =   2  'Center
      BackColor       =   &H0000FF00&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Index           =   1
      Left            =   600
      TabIndex        =   133
      ToolTipText     =   "Az automata szalagj�nak 1. pozici�ja - KATTINT�SRA : Fej�ll�s a kezd�sz� elej�n"
      Top             =   3000
      WhatsThisHelpID =   22
      Width           =   390
   End
   Begin VB.Menu mnu_File 
      Caption         =   "&File"
      Begin VB.Menu mnu_Param_Open 
         Caption         =   "&Param�terek beolvas�sa..."
      End
      Begin VB.Menu mnu_Param_Save 
         Caption         =   "Pa&ram�terek ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Full_Open 
         Caption         =   "&Teljes feladat beolvas�sa..."
      End
      Begin VB.Menu mnu_Full_Save 
         Caption         =   "Teljes feladat &ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Separator01 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Result_Save 
         Caption         =   "&V�geredm�ny ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Separator10 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Exit 
         Caption         =   "&Kil�p"
         Shortcut        =   ^X
      End
   End
   Begin VB.Menu mnu_ABC 
      Caption         =   "&ABC"
      Begin VB.Menu mnu_ABC_Write 
         Caption         =   "&ABC megad�sa..."
         HelpContextID   =   14
         Shortcut        =   ^A
      End
      Begin VB.Menu mnu_ABC_List 
         Caption         =   "ABC &lista"
         Enabled         =   0   'False
         HelpContextID   =   15
      End
   End
   Begin VB.Menu mnu_State 
      Caption         =   "&�llapotok"
      Begin VB.Menu mnu_State_Rec 
         Caption         =   "&�tmeneti �llapotok megad�sa..."
         HelpContextID   =   16
         Shortcut        =   ^S
      End
      Begin VB.Menu mnu_State_List 
         Caption         =   "�tmeneti �llapotok &list�ja"
         Enabled         =   0   'False
         HelpContextID   =   17
      End
      Begin VB.Menu mnu_Separator02 
         Caption         =   "-"
         Index           =   1
      End
      Begin VB.Menu mnu_State_Begin 
         Caption         =   "&Kezd��llapot megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   18
      End
      Begin VB.Menu mnu_State_End 
         Caption         =   "&V�g�llapot megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   19
      End
   End
   Begin VB.Menu mnu_IO 
      Caption         =   "&Kezd�sz�"
      Begin VB.Menu mnu_Input 
         Caption         =   "&Kezd�sz� megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   20
         Shortcut        =   ^I
      End
      Begin VB.Menu mnu_Input_Pos 
         Caption         =   "Kezd� &pozici� megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   21
      End
      Begin VB.Menu mnu_Head 
         Caption         =   "Fej�ll�s"
         Enabled         =   0   'False
         HelpContextID   =   22
         Begin VB.Menu mnu_Head_Begin 
            Caption         =   "Kezd�sz� &elej�n"
            Checked         =   -1  'True
            HelpContextID   =   22
         End
         Begin VB.Menu mnu_Head_End 
            Caption         =   "Kezd�sz� &v�g�n"
            HelpContextID   =   22
         End
         Begin VB.Menu mnu_Head_Else 
            Caption         =   "&M�shol"
            HelpContextID   =   22
         End
      End
      Begin VB.Menu mnu_Separator03 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Output_Input 
         Caption         =   "Ki&menet �tad�sa bemenetk�nt"
         Enabled         =   0   'False
         HelpContextID   =   23
         Begin VB.Menu mnu_Output_Input_Param 
            Caption         =   "&Param�terek bet�lt�s�hez..."
            HelpContextID   =   23
         End
         Begin VB.Menu mnu_Output_Input_Full 
            Caption         =   "&Teljes feladat bet�lt�s�hez..."
            HelpContextID   =   23
         End
      End
      Begin VB.Menu mnu_Input_Iter 
         Caption         =   "&Iter�ci� alkalmaz�sa"
         Enabled         =   0   'False
         HelpContextID   =   24
      End
   End
   Begin VB.Menu mnu_Szab 
      Caption         =   "S&zab�lyok"
      Begin VB.Menu mnu_Reg_Rec 
         Caption         =   "&Szab�lyok megad�sa..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Reg_List 
         Caption         =   "Szab�lyok &list�ja"
         Enabled         =   0   'False
      End
   End
   Begin VB.Menu mnu_Uzem 
      Caption         =   "&�zemm�d"
      Begin VB.Menu mnu_Mode_Turing 
         Caption         =   "&Turing-g�p"
         Checked         =   -1  'True
         Shortcut        =   ^T
      End
      Begin VB.Menu mnu_Mode_Accept 
         Caption         =   "&Felismer� automata"
         Shortcut        =   ^F
      End
   End
   Begin VB.Menu mnu_Szim 
      Caption         =   "S&zimul�ci�"
      Begin VB.Menu mnu_Sim_Begin 
         Caption         =   "Szimul�ci� &kezd�se"
         Enabled         =   0   'False
         Shortcut        =   ^K
      End
      Begin VB.Menu mnu_Sim_Step 
         Caption         =   "Szimul�ci� &l�p�senk�nt"
         Enabled         =   0   'False
         Shortcut        =   ^L
      End
      Begin VB.Menu mnu_Sim_Execute 
         Caption         =   "Szimul�ci� &v�grehajt�sa"
         Enabled         =   0   'False
         Shortcut        =   ^V
      End
      Begin VB.Menu mnu_Sim_End 
         Caption         =   "Szimul�ci� v�g&eredm�nye"
         Enabled         =   0   'False
         Shortcut        =   ^E
      End
      Begin VB.Menu mnu_Sim_New 
         Caption         =   "&�j szimul�ci�"
         Shortcut        =   ^U
      End
   End
   Begin VB.Menu mnu_Options 
      Caption         =   "&Be�ll�t�sok"
      Begin VB.Menu mnu_Options_Prev 
         Caption         =   "&El�z� �llapot enged�lyez�se"
         Checked         =   -1  'True
         Shortcut        =   ^P
      End
      Begin VB.Menu mnu_Options_Progr 
         Caption         =   "&Folyamatjelz� enged�lyez�se"
         Checked         =   -1  'True
         Shortcut        =   ^J
      End
      Begin VB.Menu mnu_Options_Loop 
         Caption         =   "&V�gtelen ciklusra le�ll"
         Checked         =   -1  'True
         Shortcut        =   ^C
      End
      Begin VB.Menu mnu_Options_Sound 
         Caption         =   "&Hangos lej�tsz�s"
         Checked         =   -1  'True
         Shortcut        =   ^H
      End
      Begin VB.Menu mnu_Options_Flag 
         Caption         =   "&D�szelemek enged�lyez�se"
         Checked         =   -1  'True
         Shortcut        =   ^D
      End
      Begin VB.Menu mnu_Separator05 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Stil 
         Caption         =   "Fej&st�lus"
         Begin VB.Menu mnu_Stil_Inter 
            Caption         =   "&Szakasszal"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Stil_Slider 
            Caption         =   "&Cs�szk�val"
         End
      End
      Begin VB.Menu mnu_Options_Colors 
         Caption         =   "&Sz�nbe�ll�t�sok..."
         Begin VB.Menu mnu_Options_Colors_Back 
            Caption         =   "Szalag &h�tt�rsz�ne"
         End
         Begin VB.Menu mnu_Options_Colors_Front 
            Caption         =   "Szalag &jeleinek sz�ne"
         End
      End
   End
   Begin VB.Menu mnu_Helpp 
      Caption         =   "&S�g�"
      Begin VB.Menu mnu_Help 
         Caption         =   "&Tartalomjegyz�k..."
         HelpContextID   =   10600
      End
      Begin VB.Menu mnu_Index 
         Caption         =   "T�rgy&mutat�..."
      End
      Begin VB.Menu mnu_Navig 
         Caption         =   "&Navig�l�s..."
      End
      Begin VB.Menu mnu_About 
         Caption         =   "N�v&jegy"
      End
   End
   Begin VB.Menu mnu_Sum 
      Caption         =   "�sszes"
      Visible         =   0   'False
      Begin VB.Menu mnu_File2 
         Caption         =   "File"
      End
      Begin VB.Menu mnu_Param_Open2 
         Caption         =   "     Param�terek beolvas�sa..."
      End
      Begin VB.Menu mnu_Param_Save2 
         Caption         =   "     Param�terek ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Full_Open2 
         Caption         =   "     Teljes feladat beolvas�sa..."
      End
      Begin VB.Menu mnu_Full_Save2 
         Caption         =   "     Teljes feladat ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Result_Save2 
         Caption         =   "     V�geredm�ny ment�se..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Exit2 
         Caption         =   "     Kil�p"
      End
      Begin VB.Menu mnu_Separator06 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_ABC2 
         Caption         =   "ABC"
      End
      Begin VB.Menu mnu_ABC_Write2 
         Caption         =   "     ABC megad�sa..."
         HelpContextID   =   14
      End
      Begin VB.Menu mnu_ABC_List2 
         Caption         =   "     ABC lista"
         Enabled         =   0   'False
         HelpContextID   =   15
      End
      Begin VB.Menu mnu_State2 
         Caption         =   "�llapotok"
      End
      Begin VB.Menu mnu_State_Rec2 
         Caption         =   "     �tmeneti �llapotok megad�sa..."
         HelpContextID   =   16
      End
      Begin VB.Menu mnu_State_List2 
         Caption         =   "     �tmeneti �llapotok list�ja"
         Enabled         =   0   'False
         HelpContextID   =   17
      End
      Begin VB.Menu mnu_State_Begin2 
         Caption         =   "     Kezd��llapot megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   18
      End
      Begin VB.Menu mnu_State_End2 
         Caption         =   "     V�g�llapot megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   19
      End
      Begin VB.Menu mnu_IO2 
         Caption         =   "Kezd�sz�"
      End
      Begin VB.Menu mnu_Input2 
         Caption         =   "     Kezd�sz� megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   20
      End
      Begin VB.Menu mnu_Input_Pos2 
         Caption         =   "     Kezd� pozici� megad�sa..."
         Enabled         =   0   'False
         HelpContextID   =   21
      End
      Begin VB.Menu mnu_Head2 
         Caption         =   "     Fej�ll�s"
         Enabled         =   0   'False
         HelpContextID   =   22
         Begin VB.Menu mnu_Head_Begin2 
            Caption         =   "Kezd�sz� elej�n"
            Checked         =   -1  'True
            HelpContextID   =   22
         End
         Begin VB.Menu mnu_Head_End2 
            Caption         =   "Kezd�sz� v�g�n"
            HelpContextID   =   22
         End
         Begin VB.Menu mnu_Head_Else2 
            Caption         =   "M�shol"
            HelpContextID   =   22
         End
      End
      Begin VB.Menu mnu_Output_Input2 
         Caption         =   "     Kimenet �tad�sa bemenetk�nt"
         Enabled         =   0   'False
         HelpContextID   =   23
         Begin VB.Menu mnu_Output_Input_Param2 
            Caption         =   "Param�terek bet�lt�s�hez..."
            HelpContextID   =   23
         End
         Begin VB.Menu mnu_Output_Input_Full2 
            Caption         =   "Teljes feladat bet�lt�s�hez..."
            HelpContextID   =   23
         End
      End
      Begin VB.Menu mnu_Input_Iter2 
         Caption         =   "     Iter�ci� alkalmaz�sa"
         Enabled         =   0   'False
         HelpContextID   =   24
      End
      Begin VB.Menu mnu_Szab2 
         Caption         =   "Szab�lyok"
      End
      Begin VB.Menu mnu_Reg_Rec2 
         Caption         =   "     Szab�lyok megad�sa..."
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Reg_List2 
         Caption         =   "     Szab�lyok list�ja"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Uzem2 
         Caption         =   "�zemm�d"
         Begin VB.Menu mnu_Mode_Turing2 
            Caption         =   "Turing-g�p"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Mode_Accept2 
            Caption         =   "Felismer� automata"
         End
      End
      Begin VB.Menu mnu_Separator07 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Szim2 
         Caption         =   "Szimul�ci�"
      End
      Begin VB.Menu mnu_Sim_Begin2 
         Caption         =   "     Szimul�ci� kezd�se"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Sim_Step2 
         Caption         =   "     Szimul�ci� l�p�senk�nt"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Sim_Execute2 
         Caption         =   "     Szimul�ci� v�grehajt�sa"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Sim_End2 
         Caption         =   "     Szimul�ci� v�geredm�nye"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnu_Sim_New2 
         Caption         =   "     �j szimul�ci�"
      End
      Begin VB.Menu mnu_Separator08 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Options2 
         Caption         =   "Be�ll�t�sok"
         Begin VB.Menu mnu_Options_Prev2 
            Caption         =   "     El�z� �llapot enged�lyez�se"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Options_Progr2 
            Caption         =   "     Folyamatjelz� enged�lyez�se"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Options_Loop2 
            Caption         =   "     V�gtelen ciklusra le�ll"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Options_Sound2 
            Caption         =   "     Hangos lej�tsz�s"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Options_Flag2 
            Caption         =   "     D�szelemek enged�lyez�se"
            Checked         =   -1  'True
         End
         Begin VB.Menu mnu_Separator09 
            Caption         =   "-"
         End
         Begin VB.Menu mnu_Stil2 
            Caption         =   "     Fejst�lus"
            Begin VB.Menu mnu_Stil_Inter2 
               Caption         =   "Szakasszal"
               Checked         =   -1  'True
            End
            Begin VB.Menu mnu_Stil_Slider2 
               Caption         =   "Cs�szk�val"
            End
         End
         Begin VB.Menu mnu_Options_Colors2 
            Caption         =   "     Sz�nbe�ll�t�sok..."
            Begin VB.Menu mnu_Options_Colors_Back2 
               Caption         =   "Szalag h�tt�rsz�ne..."
            End
            Begin VB.Menu mnu_Options_Colors_Frontk2 
               Caption         =   "Szalag jeleinek sz�ne..."
            End
         End
      End
      Begin VB.Menu mnu_Helpp2 
         Caption         =   "S�g�"
         Begin VB.Menu mnu_Help2 
            Caption         =   "    Tartalomjegyz�k..."
         End
         Begin VB.Menu mnu_Index2 
            Caption         =   "    T�rgymutat�..."
         End
         Begin VB.Menu mnu_Navig2 
            Caption         =   "    Navig�l�s..."
         End
         Begin VB.Menu mnu_About2 
            Caption         =   "    N�vjegy"
         End
      End
   End
End
Attribute VB_Name = "frm_Turing_Start"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 ' ------------------------------------------------------------------------------------------ '
'
' frm_Turing_Start  :  Az automata f�men�je (kezd� lapja)
'
' ------------------------------------------------------------------------------------------ '
  Option Explicit
  Private m_bln_Direct     As Boolean           ' �les futtat�s-e ?
  Private m_bln_Loop       As Boolean           ' V�gtelen ciklus-e ?
  Private m_dbl_Filenum1   As Double            ' Szab�lyok beolvas�s�n�l, ment�s�n�l
  Private m_int_Head       As Integer           ' Fej pozici�ja
  Private m_int_Head_Diff  As Integer           ' A kezd� pozici� �s a fej k�z�tti k�l�nbs�g
  Private m_int_Head_Pos   As Integer           ' Fej�ll�s el�l/h�tul/m�shol ?
  Private m_int_Last       As Integer           ' Utols� fej�ll�s
  Private m_int_Nr         As Integer           ' L�p�sek sz�ma
  Private m_int_Turing()   As Integer           ' Turing-g�p l�p�seinek ment�s�hez
  Private m_str_Input_New  As String            ' Output �tad�s�hoz
  Private m_str_Head_Move  As String            ' A fej mozg�s�nak t�pusa (B,J,M)
  Private m_str_Head_State As String            ' A fej �llapota
  Private m_str_Row        As String            ' Eredm�nyek ablak�ban egy sor
  Private m_str_Sign       As String            ' Aktu�lis input a szalagr�l
  Private m_Reg()          As g_Reg_Data        ' Szab�lyok ment�s�hez
' ------------------------------------------------------------------------------------------ '
'                           A feladat futtat�sra k�sz : parancsgombokat, men�ket enged�lyezi '
Public Sub check()
        
        chk_Begin.Visible = True
        cmd_Tur_Start.Enabled = True
        cmd_Tur_Step.Enabled = True
        cmd_Tur_Exec.Enabled = True
        cmd_Tur_New.Enabled = True
        cmd_Tur_Iter.Enabled = True
        lbl_Begin.Enabled = True
        mnu_ABC_List.Enabled = True  ' frm_Turing_Start - ot kiszedni !!!
        mnu_ABC_List2.Enabled = True
        mnu_Head.Enabled = True
        mnu_Head2.Enabled = True
        mnu_Input.Enabled = True
        mnu_Input2.Enabled = True
        mnu_Input_Iter.Enabled = True
        mnu_Input_Iter2.Enabled = True
        mnu_Input_Pos.Enabled = True
        mnu_Input_Pos2.Enabled = True
        mnu_Output_Input.Enabled = True
        mnu_Output_Input2.Enabled = True
        If g_str_Mode = "F" Then
           mnu_State_End.Enabled = True
           mnu_State_End2.Enabled = True
        End If
        mnu_State_Begin.Enabled = True
        mnu_State_Begin2.Enabled = True
        mnu_State_List.Enabled = True
        mnu_State_List2.Enabled = True
        mnu_Reg_List.Enabled = True
        mnu_Reg_List2.Enabled = True
        mnu_Reg_Rec.Enabled = True
        mnu_Reg_Rec2.Enabled = True
        mnu_Sim_Execute.Enabled = True
        mnu_Sim_Execute2.Enabled = True
        mnu_Sim_Begin.Enabled = True
        mnu_Sim_Begin2.Enabled = True
        mnu_Sim_Step.Enabled = True
        mnu_Sim_Step2.Enabled = True
End Sub
' ------------------------------------------------------------------------------------------ '
'                                     Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_ABC_Click()
        
        If frm_Abc_Rec.lst_ABC.ListCount > 0 Then
           chk_ABC.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                     Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_Begin_Click()

        If g_vnt_Input <> "" Then
           chk_Begin.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                       Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_End_Click()
        
        If g_vnt_State_End <> "" Then
           chk_End.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                       Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_Input_Click()

        If frm_Turing_Input.txt_Input.Text <> "" Then
           chk_Input.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                       Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_Reg_Click()

        If frm_Reg_Rec.lst_Reg.ListCount > 0 Then
           chk_Reg.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                       Ne lehessen a jel�l�n�gyzet �llapot�t megv�ltoztatni ! '
Private Sub chk_State_Click()
        
        If frm_State_Rec.lst_State.ListCount > 0 Then
           chk_State.Enabled = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                �j szimul�ci� '
Private Sub cmd_New_Sim_Click()
        mnu_Sim_New_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                               A fej mozg�sa, szalag kezel�se '
Public Sub cmd_Turing_Click(Index As Integer)
        Dim i              As Integer   ' index-v�ltoz�
        Dim j              As Integer   ' index-v�ltoz�
        Dim k              As Integer   ' index-v�ltoz�
        Dim m              As Integer   ' index-v�ltoz�
        Dim int_Reg_Good   As Integer   ' Szerepel-e a szab�lyok list�j�ban ?
        Dim str_Row_Begin  As String    ' Eredm�nyablak sor�nak bevezet� r�sze
        Dim str_Row_Result As String    ' Eredm�nyablak egy sora
        
        If Index = 30 Then
           msg ("K�rem helyezze �t a kezd� pozici�t")
           sld_Turing_Click
           ' msg("")
           '  Exit Sub
           ' cmd_Tur_Start_Click ' int_Nr haszn�lat�val ebbe az
           '                     ' �llapotba �ll�that�
        End If
        m_int_Last = Index
        int_Reg_Good = 0
        msg ("")
        For i = 1 To UBound(m_int_Turing, 2)
            If Chr(m_int_Turing(1, i)) = m_str_Head_State And _
               Chr(m_int_Turing(2, i)) = m_str_Sign Then          ' �llapot �s jel
               int_Reg_Good = i                                     ' hanyadik szab�ly ?
               str_Row_Result = Chr(m_int_Turing(1, int_Reg_Good)) & " , " & _
                            Chr(m_int_Turing(2, int_Reg_Good)) & " -> " & _
                            Chr(m_int_Turing(3, int_Reg_Good))
               If g_str_Mode = "T" Then
                  str_Row_Result = str_Row_Result & " , " & _
                                Chr(m_int_Turing(4, int_Reg_Good)) & _
                                "   " & Chr(m_int_Turing(5, int_Reg_Good))
               End If
               str_Row_Result = str_Row_Result & "  " & Format(Str(m_int_Head), "00") ' 000
               k = lst_Result_Window.ListCount
               str_Row_Result = lst_Result_Window.List(k - 1) & str_Row_Result
               If k > 0 Then
                  lst_Result_Window.RemoveItem k - 1
               End If
               lst_Result_Window.AddItem str_Row_Result
               If mnu_Options_Loop.Checked = True Then
                  For m = 1 To lst_Result_Window.ListCount - 1     ' V�gtelen ciklus keres�se
                      If Mid(lst_Result_Window.List(m - 1), 10, 55) = Mid(str_Row_Result, 10, 55) Then
                         msg ("V�gtelen ciklus !")
                         m_bln_Loop = True
                         m_int_Head = 0                    ' ciklus erre �ll le
                         Exit For
                      End If
                  Next m
               End If
               If m_bln_Direct Then
                  sld_Fej.Value = m_int_Head            ' fej-cs�szka aktualiz�l�sa
               End If
            End If
        Next i
        If int_Reg_Good > 0 And m_int_Head > 0 Then           ' ha a l�p�s lehets�ges
           m_int_Nr = m_int_Nr + 1
           If m_int_Nr >= prg_Turing.Min And m_int_Nr <= prg_Turing.Max Then
              prg_Turing.Value = m_int_Nr               ' folyamatjelz� aktualiz�l�sa
              If prg_Turing.Visible = True Then
                 lbl_Percent = Str(Int((100 * prg_Turing.Value) / prg_Turing.Max)) & "%"
              End If                                  ' % ki�r�sa
           End If
           For i = 1 To 30
               lin_Prev(i).Visible = False            ' el�z� �llapot t�rl�se
               lbl_Prev(i).Visible = False
           Next i
           If mnu_Options_Prev.Checked Then
              lin_Prev(Index).Visible = True          ' aktu�lis el�z� �llapot
              lbl_Prev(Index).Visible = True
              lbl_Prev(Index).Caption = m_str_Head_State & "," & m_str_Sign
           End If
           m_str_Sign = Chr(m_int_Turing(4, int_Reg_Good))      ' �j bemen� jel
           lbl_Turing(Index).Caption = m_str_Sign       ' �j bemen� jel ki�r�sa
           On Error GoTo Err_Handler  ' HIBA
           m_str_Head_State = Chr(m_int_Turing(3, int_Reg_Good)) ' �j bemen� �llapot
           m_str_Head_Move = Chr(m_int_Turing(5, int_Reg_Good))       ' fejmozg�s
           If m_str_Head_Move = "B" Then                      ' a fej balra mozog
              m_int_Head = Index - 1               ' fej pozici�ja 1-gyel cs�kken
              If m_bln_Direct Then
                 lin_Turing(m_int_Head).Visible = True
                 cmd_Turing(m_int_Head).Visible = True
                 sld_Sim.Value = m_int_Head
              End If
              cmd_Turing(m_int_Head).Caption = m_str_Head_State ' �j �llapot
              lin_Turing(Index).Visible = False             ' vonal elt�nik
              cmd_Turing(Index).Visible = False        ' parancsgomb letilt�sa
              cmd_Turing(Index).Caption = ""           ' fel�rat elt�nik
           End If
           If m_str_Head_Move = "J" Then                      ' a fej jobbra mozog
              m_int_Head = Index + 1
              If m_bln_Direct Then                           ' �les futtat�s-e ?
                 lin_Turing(m_int_Head).Visible = True
                 cmd_Turing(m_int_Head).Visible = True
                 sld_Sim.Value = m_int_Head
              End If
              cmd_Turing(m_int_Head).Caption = m_str_Head_State
              lin_Turing(Index).Visible = False
              cmd_Turing(Index).Visible = False
              cmd_Turing(Index).Caption = ""
           End If
           If m_str_Head_Move = "M" Then                      ' a fej helyben marad
              m_int_Head = Index
              cmd_Turing(m_int_Head).Caption = m_str_Head_State
              If Asc(m_str_Head_State) = g_int_Prev(3) And Asc(m_str_Sign) = g_int_Prev(4) And _
                                    Chr(g_int_Prev(5)) = "M" Then  ' v�gtelen ciklus
                 If mnu_Options_Loop.Checked = True Then
                    For j = 1 To 30
                        cmd_Turing(j).Enabled = False
                    Next j
                    cmd_Tur_Step.Enabled = False
                    mnu_Sim_Step.Enabled = False
                    j = lst_Result_Window.ListCount - 1
                    lst_Result_Window.RemoveItem j
                    msg ("V�gtelen ciklus !")
                    m_bln_Loop = True
                    m_int_Head = 0
                 End If
              End If
           End If
           g_int_Prev(3) = m_int_Turing(3, int_Reg_Good)          ' El�z� �llapot
           g_int_Prev(4) = m_int_Turing(4, int_Reg_Good)
           g_int_Prev(5) = m_int_Turing(5, int_Reg_Good)
           If m_int_Head > 0 Then
              m_str_Sign = lbl_Turing(m_int_Head).Caption
              On Error GoTo Err_Handler  ' HIBA
           End If
           If m_bln_Direct And mnu_Options_Sound.Checked = True Then
              Beep
           End If
           j = int_Reg_Good
           m_str_Row = ""
           If lst_Result_Window.ListCount < 99 Then
              If lst_Result_Window.ListCount < 9 Then
                 str_Row_Begin = " 00"
              Else
                 str_Row_Begin = " 0"
              End If
           Else
              str_Row_Begin = " "
           End If
           lst_Result_Window.Visible = True
           For j = 1 To 30
               m_str_Row = m_str_Row & lbl_Turing(j)
           Next j
           m_str_Row = str_Row_Begin & lst_Result_Window.ListCount + 1 & _
                       ". -> " & m_str_Row & "   "
           lst_Result_Window.AddItem m_str_Row
           If m_bln_Direct Then
              lst_Result_Window.ListIndex = k
           End If
        Else
           cmd_Turing(Index).Caption = m_str_Head_State
           If g_str_Mode = "F" Then
              If m_bln_Direct = True Then
                 If m_str_Head_State = g_vnt_State_End Then     ' V�g�llapottal megegyezik
                    msg ("Felismerte !!!")
                    g_bln_Accept = True
                 Else
                    msg ("Nem ismerte fel !!!")
                    g_bln_Accept = False
                 End If
              End If
           End If
           k = lst_Result_Window.ListCount
           If m_bln_Direct Then
              If mnu_Options_Sound.Checked = True Then
                 Beep
              End If
              lbl_Result_Nr = k - 1
              lbl_Window.Visible = True
           End If
           str_Row_Result = " END" & Mid(lst_Result_Window.List(k - 1), 5, 38)
           If g_str_Mode = "T" Then
              str_Row_Result = str_Row_Result & "      V�GE !"
           Else
              str_Row_Result = str_Row_Result & "    V�GE !"
           End If
           sld_Fej.Value = 1
           lst_Result_Window.RemoveItem k - 1
           lst_Result_Window.AddItem str_Row_Result
           For j = 1 To 30
               cmd_Turing(j).Enabled = False
           Next j
           cmd_Tur_Step.Enabled = False
           mnu_Sim_Step.Enabled = False
           m_int_Nr = m_int_Nr + 1
           If m_int_Nr >= prg_Turing.Min And m_int_Nr <= prg_Turing.Max Then
              prg_Turing.Value = m_int_Nr
              If prg_Turing.Visible = True Then
                 lbl_Percent = Str(Int((100 * prg_Turing.Value) / prg_Turing.Max)) & "%"
              End If
           End If
           m_int_Head = 0
           lst_Result_Window.ListIndex = lst_Result_Window.ListCount - 1
        End If
Err_Handler:  Exit Sub
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         Kil�p�s a programb�l '
Private Sub cmd_Tur_End_Click()
        form_End
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       A szimul�ci� v�grehajt�sa egy l�p�sben '
Private Sub cmd_Tur_Exec_Click()
        Dim j As Integer    ' index-v�ltoz�
'       Dim lbl_Time1 As Date
        
'       lbl_Time1 = Now()
        
        j = begin()
        If j = 1 Then
           mnu_Sim_Execute_Click
'          lbl_Time2.Text = Format(Now() - lbl_Time1, "mm:ss")
           mnu_Result_Save.Enabled = True
           mnu_Result_Save2.Enabled = True
           tlb_Turing.Buttons(2).ButtonMenus(3).Enabled = True
           mnu_Sim_End.Enabled = True
           mnu_Sim_End2.Enabled = True
           cmd_Result.Enabled = True
           lbl_Big.Enabled = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       Az output az �j input (visszacsatol�s) '
Public Sub cmd_Tur_Iter_Click()
        Dim i             As Integer   ' index-v�ltoz�
        Dim j             As Integer   ' index-v�ltoz�
        Dim k             As Integer   ' index-v�ltoz�
        Dim int_From_Here As Integer   ' Hol kezd�dik az input
        Dim str_Good      As String    ' Az �j input
        Dim str_Last      As String    ' Utols� konfigur�ci� a list�ban
                
        k = begin()
        If k = 1 Then
           str_Good = ""
           j = lst_Result_Window.ListCount - 1
           str_Last = lst_Result_Window.List(j)
           For i = 10 To 39
               If Mid(str_Last, i, 1) <> "*" Then
                  int_From_Here = i
                  Exit For
               End If
           Next i
           For i = int_From_Here To 39
               If Mid(str_Last, i, 1) <> "*" Then
                  str_Good = str_Good + Mid(str_Last, i, 1)
               Else
                 Exit For
               End If
           Next i
           frm_Turing_Input.txt_Input = str_Good
           mnu_Sim_Begin_Click
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                            �j input megad�sa '
Private Sub cmd_Tur_New_Click()
        Dim j As Integer   ' index-v�ltoz�
                
        j = begin()
        If j = 1 Then
        chk_Input.Value = 0
        frm_Turing_Input.Show 1
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                           Szimul�ci� kezd�se '
Public Sub cmd_Tur_Start_Click()
        Dim i As Integer  ' index-v�ltoz�
        Dim j As Integer  ' index-v�ltoz�
        
        msg ("")
        lbl_Percent = ""
        j = begin()
        If j = 1 Then
           lbl_Result_Nr = ""
           lbl_Window.Visible = False
           sld_Fej.Value = 1
           m_int_Nr = 0
           If m_int_Head + Len(g_vnt_Input) > 30 Then
              msg ("K�rem helyezze �t a kezd� pozici�t")
              sld_Turing_Click
              'msg("")
              'Exit Sub
           End If
           prg_Turing.Value = 0
           mnu_Sim_Begin_Click
           prg_Turing.Visible = False
           lst_Result_Window.Visible = False
           m_bln_Direct = False
           m_bln_Loop = False
           Do While m_int_Head > 0
              cmd_Turing_Click (m_int_Head)
              If m_bln_Loop = True Then
                 Exit Do
              End If
           Loop
           m_bln_Direct = True
           i = lst_Result_Window.ListCount
           m_bln_Loop = False  ' Kell-e ???
           lst_Result_Window.Visible = False
           If mnu_Options_Progr.Checked Then
              prg_Turing.Visible = True
           End If
           prg_Turing.Max = m_int_Nr
           prg_Turing.Value = 0
           mnu_Sim_Begin_Click
           msg ("")
           mnu_Result_Save.Enabled = False
           mnu_Result_Save2.Enabled = False
           tlb_Turing.Buttons(2).ButtonMenus(3).Enabled = False
           mnu_Sim_End.Enabled = False
           mnu_Sim_End2.Enabled = False
           cmd_Result.Enabled = False
           lbl_Big.Enabled = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                       Szimul�l�s l�p�senk�nt '
Private Sub cmd_Tur_Step_Click()
        Dim i As Integer  ' index-v�ltoz�
        Dim j As Integer  ' index-v�ltoz�
                
        j = begin()
        If j = 1 And m_int_Head <> 0 Then
           cmd_Turing_Click (m_int_Head)
        End If
        If j = 1 And m_int_Head = 0 Then
           mnu_Result_Save.Enabled = True
           mnu_Result_Save2.Enabled = True
           tlb_Turing.Buttons(2).ButtonMenus(3).Enabled = True
           mnu_Sim_End.Enabled = True
           mnu_Sim_End2.Enabled = True
           cmd_Result.Enabled = True
           lbl_Big.Enabled = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 Elmentett szab�lyok bet�lt�se (*.rgt, *.rgf) '
Public Sub File_Open_Reg()
       Dim i             As Integer   ' index-v�ltoz�
       Dim j             As Integer   ' index-v�ltoz�
       Dim k             As Integer   ' index-v�ltoz�
       Dim n             As Integer   ' index-v�ltoz�
       Dim str_File_Name As String    ' megnyitand� file neve
       Dim str_Reg       As String    ' szab�ly t�rol�s�hoz
       Dim hossz         As Integer   ' beolvasand� file nev�nek hossza
        
       Close
       ReDim m_Reg(1 To 200) As g_Reg_Data
       m_dbl_Filenum1 = FreeFile
       str_File_Name = frm_Reg_Rec.fil_Turing.FileName
       If str_File_Name <> "" Then
       Open "C:\Turing\" & str_File_Name _
                                             For Random Access Read Write _
             As #m_dbl_Filenum1 Len = Len(m_Reg(1))
       n = LOF(1) / Len(m_Reg(1))
       For i = 1 To n
           Get #m_dbl_Filenum1, i, m_Reg(i)
       Next i
       Close
       ReDim m_int_Turing(1 To 5, 1 To n)
       For i = 1 To n
           m_int_Turing(1, i) = m_Reg(i).int_State1   ' Input �llapot
           m_int_Turing(2, i) = m_Reg(i).int_Sign1    ' Input jel
           m_int_Turing(3, i) = m_Reg(i).int_State2   ' Output �llapot
           m_int_Turing(4, i) = m_Reg(i).int_Sign2    ' Output jel
           m_int_Turing(5, i) = m_Reg(i).int_Head_Pos     ' Fej-mozg�s
       Next i
       frm_Reg_Rec.Reg_Del_All
       For i = 1 To n                              ' Szab�lylista felt�lt�se
           str_Reg = Chr(m_int_Turing(1, i)) & " , " & _
                         Chr(m_int_Turing(2, i)) & " -> " & _
                         Chr(m_int_Turing(3, i))
           If g_str_Mode = "T" Then
              str_Reg = str_Reg & " , " & _
                            Chr(m_int_Turing(4, i)) & " , " & _
                            Chr(m_int_Turing(5, i))
           End If
           frm_Reg_Rec.lst_Reg.AddItem str_Reg
       Next i
       frm_Reg_Rec.lbl_Reg_Nr = frm_Reg_Rec.lst_Reg.ListCount
       hossz = Len(str_File_Name)
       str_File_Name = Left(str_File_Name, hossz - 4)
       frm_Reg_Rec.txt_File_Save = str_File_Name
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                    Szab�lyok file-ba ment�se (*.rgt, *.rgf ) '
Public Sub File_Save_Reg()
       Dim i             As Integer   ' index-v�ltoz�
       Dim j             As Integer   ' index-v�ltoz�
       Dim n             As Integer   ' index-v�ltoz�
       Dim dbl_Filenum2  As Double    ' Szab�lyok ment�s�n�l
       Dim str_File_Name As String    ' mentend� file neve

       Close
       If frm_Reg_Rec.txt_File_Save.Text <> "" Then
       n = UBound(m_int_Turing, 2)
       Dim m_Reg(1 To 200) As g_Reg_Data
       m_dbl_Filenum1 = FreeFile
       If frm_Reg_Rec.txt_File_Save.Text <> "" Then
          If g_str_Mode = "T" Then
             str_File_Name = frm_Reg_Rec.txt_File_Save.Text & ".rgt"
          Else
             str_File_Name = frm_Reg_Rec.txt_File_Save.Text & ".rgf"
          End If
       Else
          str_File_Name = frm_Reg_Rec.fil_Turing.FileName
       End If
       Open "C:\Turing\" & str_File_Name _
            For Random Access Read Write As #m_dbl_Filenum1 Len = Len(m_Reg(1))
       Close
       Kill "C:\Turing\" & str_File_Name
       dbl_Filenum2 = FreeFile
       Open "C:\Turing\" & str_File_Name _
       For Random Access Read Write As #dbl_Filenum2 Len = Len(m_Reg(1))
       For i = 1 To n
           m_Reg(i).int_State1 = m_int_Turing(1, i)
           m_Reg(i).int_Sign1 = m_int_Turing(2, i)
           m_Reg(i).int_State2 = m_int_Turing(3, i)
           m_Reg(i).int_Sign2 = m_int_Turing(4, i)
           m_Reg(i).int_Head_Pos = m_int_Turing(5, i)
           Put #dbl_Filenum2, i, m_Reg(i)
       Next i
       Close
       frm_Reg_Rec.txt_File_Save.Text = ""
       frm_Reg_Rec.cmd_Exit_Click
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             �rlapok bez�r�sa '
Private Sub form_End()
        Dim i As Integer  ' index-v�ltoz�
        
        For i = Forms.Count - 1 To 0 Step -1
            Unload Forms(i)
        Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                              �rlap bet�lt�se '
Private Sub Form_Load()
        Dim i         As Integer       ' index-v�ltoz�
        
        m_int_Head = sld_Turing.Value
        For i = 1 To 30
            lbl_Turing(i).Caption = "*"
        Next i
        frm_Abc_Rec.cmd_Remove.Enabled = (frm_Abc_Rec.lst_ABC.ListCount <> 0)
        frm_Abc_Rec.cmd_Add.Enabled = (Len(frm_Abc_Rec.txt_ABC.Text) > 0)
        lbl_Date.Caption = Format(Now, "yyyy.mm.dd.")
        g_str_Mode = "T"
        If g_str_Mode = "T" Then
           lbl_Mode = "TURING"
        Else
           lbl_Mode = "FELISMER�"
        End If
        lbl_File.Caption = "New"
        m_int_Head_Pos = 1
        mnu_Help.HelpContextID = 10600
        frm_Reg_Rec.mnu_Prev.Checked = False
        frm_Reg_Rec.mnu_Prev2.Checked = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Helyi men� megjelen�t�se '
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, x As Single, _
                         y As Single)
        If Button = 2 Then
           PopupMenu mnu_Sum
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                              A Turing-g�p ABC-j�nek megad�sa '
Private Sub lbl_ABC_Click()
        Dim i As Integer    ' index-v�ltoz�
        
        chk_ABC.Value = 0
        frm_Abc_Rec.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                      A Turing-g�p kezd� �llapot�nak megad�sa '
Private Sub lbl_Begin_Click()
        Dim i As Integer    ' index-v�ltoz�
        
        chk_Begin.Value = 0
        mnu_State_Begin_Click
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                      Eredm�nyablak nagy�t�sa '
Public Sub lbl_Big_Click()
       g_int_Row_Big = lst_Result_Window.ListIndex
       frm_Head.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 A Felismer� automata v�g�llapot�nak megad�sa '
Private Sub lbl_End_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        chk_End.Value = 0
        mnu_State_End_Click
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         A Turing-g�p kezd� szav�nak megad�sa '
Private Sub lbl_Input_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        chk_Input.Value = 0
        frm_Turing_Input.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                �zemm�d be�ll�t�sa a cimk�r�l '
Private Sub lbl_Mode_Click()
        
        mnu_Sim_New_Click ' KELL-E ???
        If g_str_Mode = "T" Then
           g_str_Mode = "F"
           lbl_Mode.Caption = "FELISMER�"
           If chk_State.Value = 1 Then
              mnu_State_End.Enabled = True
              mnu_State_End2.Enabled = True
           End If
           mnu_Mode_Turing.Checked = False
           mnu_Mode_Turing2.Checked = False
           mnu_Mode_Accept.Checked = True
           mnu_Mode_Accept2.Checked = True
           If chk_State = 1 Then
              lbl_End.Enabled = True
              chk_End.Visible = True
           End If
           If param() = 1 Then
              mnu_Param_Save.Enabled = True
              mnu_Param_Save2.Enabled = True
               tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
           Else
              mnu_Param_Save.Enabled = False
              mnu_Param_Save2.Enabled = False
               tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = False
           End If
           frm_Result.lbl_Reg_Turing.Visible = False
           frm_Result.lbl_Reg_Accept.Visible = True
           frm_Result.lbl_Konf_Turing.Visible = False
           frm_Result.lbl_Konf_Accept.Visible = True
           lbl_Konf_Turing.Visible = False
           lbl_Konf_Accept.Visible = True
           lst_Result_Window.ToolTipText = lbl_Konf_Accept.ToolTipText
           frm_Result.lst_Reg_List.ToolTipText = frm_Result.lbl_Reg_Accept.ToolTipText
           frm_Result.lst_Result_Window.ToolTipText = frm_Result.lbl_Konf_Accept.ToolTipText
        Else
           g_str_Mode = "T"
           lbl_Mode.Caption = "TURING"
           mnu_State_End.Enabled = False
           mnu_State_End2.Enabled = False
           mnu_Mode_Turing.Checked = True
           mnu_Mode_Accept.Checked = False
           mnu_Mode_Turing2.Checked = True
           mnu_Mode_Accept2.Checked = False
           chk_End.Visible = False
           lbl_End.Enabled = False
           frm_Result.lbl_Reg_Turing.Visible = True
           frm_Result.lbl_Reg_Accept.Visible = False
           frm_Result.lbl_Konf_Turing.Visible = True
           frm_Result.lbl_Konf_Accept.Visible = False
           lbl_Konf_Turing.Visible = True
           lbl_Konf_Accept.Visible = False
           lst_Result_Window.ToolTipText = lbl_Konf_Turing.ToolTipText
           frm_Result.lst_Reg_List.ToolTipText = frm_Result.lbl_Reg_Turing.ToolTipText
           frm_Result.lst_Result_Window.ToolTipText = frm_Result.lbl_Konf_Turing.ToolTipText
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                           A Turing-g�p szab�lyainak megad�sa '
Private Sub lbl_Reg_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        chk_Reg.Value = 0
        mnu_Reg_Rec_Click
        m_int_Nr = 0
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          V�geredm�ny ment�se '
Private Sub cmd_Result_Click()
        frm_Result.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                            Megjelen�ti a men�rendszer rajz�t '
Private Sub lbl_Sim_Turing_Click()
        frm_Menu1.Show
End Sub
' ------------------------------------------------------------------------------------------ '
'                                           A Turing-g�p �llapotainak megad�sa '
Private Sub lbl_State_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        chk_State.Value = 0
        frm_State_Rec.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                            A fej kezd� pozici�j�nak megad�sa '
Private Sub lbl_Turing_Click(Index As Integer)
        
        Select Case Index
             Case 1
                  mnu_Head_Begin_Click
             Case 29
                  mnu_Head_Else_Click
             Case 30
                  mnu_Head_End_Click
             Case Else
                  sld_Head.Visible = False
                  mnu_Input_Pos_Click
        End Select
End Sub
' ------------------------------------------------------------------------------------------ '
'        Eredm�nyablakban kattintva a kijel�lt konfigur�ci� fej�ll�s�t mutatja '
Private Sub lst_Result_Window_Click()
        Dim i      As Integer  ' index-v�ltoz�
        Dim j      As Integer  ' index-v�ltoz�
        Dim k      As Integer  ' index-v�ltoz�
        Dim m      As Integer  ' index-v�ltoz�
        Dim mettol As Integer  ' fej�ll�s poz�ci�ja az eredm�nyablakban
            
            If g_str_Mode = "T" Then
               mettol = 63
            Else
               mettol = 55
            End If
            j = lst_Result_Window.ListIndex
            m = lst_Result_Window.ListCount - 1
            If j <> m Then
               k = Mid(lst_Result_Window.List(j), mettol, 2)
               sld_Fej.Value = k
            End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                        Eredm�nyablakban kattintva a kijel�lt konfigur�ci�t�l '
'                                      kezdve t�rli a tov�bbiakat (visszav�gja)'
Public Sub lst_Result_Window_DblClick()
        Dim i      As Integer  ' index-v�ltoz�
        Dim j      As Integer  ' index-v�ltoz�
        Dim k      As Integer  ' index-v�ltoz�
        Dim hol    As Integer  ' fej�ll�s poz�ci�ja az eredm�nyablakban
        
        j = lst_Result_Window.ListIndex + 1
        k = lst_Result_Window.ListCount - 1
        m_int_Nr = j - 1
        If m_int_Nr >= prg_Turing.Min And m_int_Nr <= prg_Turing.Max Then
           prg_Turing.Value = m_int_Nr
           If prg_Turing.Visible = True Then
              lbl_Percent = Str(Int((100 * prg_Turing.Value) / prg_Turing.Max)) & "%"
           End If
        End If
        For i = 1 To 30
            lbl_Turing(i).Caption = "*"
            cmd_Turing(i).Visible = False
            cmd_Turing(i).Enabled = True
            lin_Turing(i).Visible = False
            lin_Prev(i).Visible = False
            lbl_Prev(i).Visible = False
        Next i
        For i = 1 To 30
            lbl_Turing(i).Caption = Mid(lst_Result_Window.List(j - 1), i + 9, 1)
        Next i
        If g_str_Mode = "T" Then
           hol = 63
        Else
           hol = 55
        End If
        m_int_Head = Val(Mid(lst_Result_Window.List(j - 1), hol, 2))
        m_str_Head_State = Mid(lst_Result_Window.List(j - 1), 43, 1)
        m_str_Sign = lbl_Turing(m_int_Head)
        For i = j To k
            lst_Result_Window.RemoveItem j
        Next i
        cmd_Turing(m_int_Head).Enabled = True
        cmd_Turing(m_int_Head).Visible = True
        cmd_Turing(m_int_Head).Caption = m_str_Head_State
        sld_Sim.Value = m_int_Head
        lin_Turing(m_int_Head).Visible = True
        cmd_Tur_Step.Enabled = True
        lst_Result_Window.List(j - 1) = Left(lst_Result_Window.List(j - 1), 39) & "   "
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       A Turing-g�p ABC-j�nek list�ja men�b�l '
Private Sub mnu_ABC_List_Click()
        frm_Abc_List.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       A Turing-g�p ABC-j�nek list�ja men�b�l '
Private Sub mnu_ABC_List2_Click()
        mnu_ABC_List_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                      A Turing-g�p ABC-j�nek megad�sa men�b�l '
Private Sub mnu_ABC_Write_Click()
        Dim i As Integer ' index-v�ltoz�
        
        chk_ABC.Value = 0
        frm_Abc_Rec.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                      A Turing-g�p ABC-j�nek megad�sa men�b�l '
Private Sub mnu_ABC_Write2_Click()
            mnu_ABC_Write_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                        N�vjegy megjelen�t�se '
Private Sub mnu_About_Click()
            frm_About.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                        N�vjegy megjelen�t�se '
Private Sub mnu_About2_Click()
        frm_About.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         Kil�p�s a programb�l '
Private Sub mnu_Exit_Click()
        form_End
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         Kil�p�s a programb�l '
Public Sub mnu_Exit2_Click()
       form_End
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    Teljes feladat beolvas�sa '
Private Sub mnu_Full_Open_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        mnu_Sim_New_Click
        frm_Full_Open.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
        cmd_Tur_Start_Click
        mnu_Head_Begin_Click
        sld_Head.Value = sld_Turing.Value
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    Teljes feladat beolvas�sa '
Private Sub mnu_Full_Open2_Click()
        mnu_Full_Open_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                       Teljes feladat ment�se '
Private Sub mnu_Full_Save_Click()
        frm_Full_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                       Teljes feladat ment�se '
Private Sub mnu_Full_Save2_Click()
        mnu_Full_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                A fej a sz� elej�n legyen-e ? '
Private Sub mnu_Head_Begin_Click()
        Dim bln_Head_Begin As Boolean  ' Jel�l� n�gyzet �llapot�nak t�rol�sa
        
        bln_Head_Begin = mnu_Head_Begin.Checked
        If Not bln_Head_Begin Then
           mnu_Head_End.Checked = False
           mnu_Head_Else.Checked = False
           mnu_Head_Begin.Checked = True
           mnu_Head_End2.Checked = False
           mnu_Head_Begin2.Checked = True
           mnu_Head_Else2.Checked = False
           m_int_Head_Pos = 1
           mnu_Sim_Begin_Click
           sld_Head.Value = sld_Turing.Value
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                A fej a sz� elej�n legyen-e ? '
Private Sub mnu_Head_Begin2_Click()
        mnu_Head_Begin_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         Fej�ll�s be�ll�t�sa az inputon bel�l '
Public Sub mnu_Head_Else_Click()

          If Len(frm_Turing_Input.txt_Input.Text) Then
          mnu_Head_End.Checked = False
          mnu_Head_Begin.Checked = False
          mnu_Head_Else.Checked = True
          mnu_Head_End2.Checked = False
          mnu_Head_Begin2.Checked = False
          mnu_Head_Else2.Checked = True
          sld_Head.Min = 2
          sld_Head.Max = 29
          sld_Head.Left = 975 + (sld_Turing.Value - 2) * 360
          sld_Head.Width = Len(frm_Turing_Input.txt_Input.Text) * 360
          sld_Head.Min = sld_Turing.Value
          sld_Head.Max = sld_Turing.Value + Len(frm_Turing_Input.txt_Input.Text) - 1
          If m_int_Head_Pos = 1 Or m_int_Head_Pos = 2 Then
             sld_Head.Value = sld_Turing.Value
             m_int_Head = sld_Turing.Value
          End If
                    
          sld_Head.Visible = True
          
          m_int_Head_Pos = 3
          mnu_Sim_Begin_Click
          End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         Fej�ll�s be�ll�t�sa az inputon bel�l '

Private Sub mnu_Head_Else2_Click()
        mnu_Head_Else_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 A fej a sz� v�g�n legyen-e ? '
Private Sub mnu_Head_End_Click()
        Dim bln_Head_End As Boolean  ' Jel�l� n�gyzet �llapot�nak t�rol�sa
        
        bln_Head_End = mnu_Head_End.Checked
        If Not bln_Head_End Then
           mnu_Head_Begin.Checked = False
           mnu_Head_Else.Checked = False
           mnu_Head_End.Checked = True
           mnu_Head_Begin2.Checked = False
           mnu_Head_End2.Checked = True
           mnu_Head_Else2.Checked = False
           m_int_Head_Pos = 2
           mnu_Sim_Begin_Click
           sld_Head.Value = sld_Turing.Value
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 A fej a sz� v�g�n legyen-e ? '
Private Sub mnu_Head_End2_Click()
        mnu_Head_End_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         A S�g� megjelen�t�se '
Private Sub mnu_Help_Click()
        htmlHelp hwnd, App.Path & "\Turing.chm", HH_DISPLAY_TOC, 0
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         A S�g� megjelen�t�se '
Private Sub mnu_Help2_Click()
        mnu_Help_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         A S�g� megjelen�t�se '
Private Sub mnu_Index_Click()
        htmlHelp hwnd, App.Path & "\Turing.chm", HH_DISPLAY_INDEX, 0
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         A S�g� megjelen�t�se '
Private Sub mnu_Index2_Click()
        mnu_Index_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 A Turing-g�p kezd� szav�nak megad�sa men�b�l '
Private Sub mnu_Input_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        chk_Input.Value = 0
        frm_Turing_Input.Show 1
        msg ("")
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 A Turing-g�p kezd� szav�nak megad�sa men�b�l '
Private Sub mnu_Input2_Click()
        mnu_Input_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                  A kezd�sz�k�nt a kimenet lesz az �j bemenet '
Private Sub mnu_Input_Iter_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        cmd_Tur_Iter_Click
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                  A kezd�sz�k�nt a kimenet lesz az �j bemenet '
Private Sub mnu_Input_Iter2_Click()
        mnu_Input_Iter_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                             A fej kezd�pozici�j�nak megad�sa '
Public Sub mnu_Input_Pos_Click()
       Dim str_Input_Temp As String     ' kezd�sz� t�rol�s�hoz
       
       str_Input_Temp = frm_Turing_Input.txt_Input.Text
       If m_int_Head_Pos = 3 Then
          m_int_Head_Diff = sld_Head.Value - sld_Turing.Value
       End If
       sld_Head.Visible = False
       sld_Turing.Visible = True
       sld_Head.Min = 2
       sld_Head.Max = 29
       sld_Head.Left = 975 + (sld_Turing.Value - 2) * 360
       sld_Head.Width = Len(str_Input_Temp) * 360
       sld_Head.Min = sld_Turing.Value
       If Len(str_Input_Temp) > 0 Then
          sld_Head.Max = sld_Turing.Value + Len(str_Input_Temp) - 1
       End If
       sld_Head.Value = sld_Turing.Value + m_int_Head_Diff
End Sub
' ------------------------------------------------------------------------------------------ '
'                                             A fej kezd�pozici�j�nak megad�sa '
Private Sub mnu_Input_Pos2_Click()
        mnu_Input_Pos_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         Felismer�-automata �zemm�dba �ll�t�s '
Public Sub mnu_Mode_Accept_Click()
        
        mnu_Sim_New_Click ' KELL-E ???
        g_str_Mode = "F"
        mnu_Mode_Turing.Checked = False
        mnu_Mode_Accept.Checked = True
        mnu_Mode_Turing2.Checked = False
        mnu_Mode_Accept2.Checked = True
        If g_str_Mode = "T" Then ' KELL-E IF ???
           lbl_Mode = "TURING"
        Else
           lbl_Mode = "FELISMER�"
        End If
        lbl_End.Enabled = True
        chk_End.Visible = True
        frm_Result.lbl_Reg_Turing.Visible = False
        frm_Result.lbl_Reg_Accept.Visible = True
        frm_Result.lbl_Konf_Turing.Visible = False
        frm_Result.lbl_Konf_Accept.Visible = True
        lbl_Konf_Turing.Visible = False
        lbl_Konf_Accept.Visible = True
        lst_Result_Window.ToolTipText = lbl_Konf_Accept.ToolTipText
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         Felismer�-automata �zemm�dba �ll�t�s '
Private Sub mnu_Mode_Accept2_Click()
        mnu_Mode_Accept_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 Turing-g�p �zemm�dba �ll�t�s '
Public Sub mnu_Mode_Turing_Click()
        
        mnu_Sim_New_Click ' KELL-E ???
        g_str_Mode = "T"
        mnu_State_End.Enabled = False
        mnu_State_End2.Enabled = False
        mnu_Mode_Turing.Checked = True
        mnu_Mode_Accept.Checked = False
        mnu_Mode_Turing2.Checked = True
        mnu_Mode_Accept2.Checked = False
        If g_str_Mode = "T" Then ' KELL-E IF ???
           lbl_Mode = "TURING"
        Else
           lbl_Mode = "FELISMER�"
        End If
        chk_End.Visible = False
        lbl_End.Enabled = False
        frm_Result.lbl_Reg_Turing.Visible = True
        frm_Result.lbl_Reg_Accept.Visible = False
        frm_Result.lbl_Konf_Turing.Visible = True
        frm_Result.lbl_Konf_Accept.Visible = False
        lbl_Konf_Turing.Visible = True
        lbl_Konf_Accept.Visible = False
        lst_Result_Window.ToolTipText = lbl_Konf_Turing.ToolTipText
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 Turing-g�p �zemm�dba �ll�t�s '
Private Sub mnu_Mode_Turing2_Click()
        mnu_Mode_Turing_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                           Egy �j feladat elv�gz�s�hez v�gigvezet a teend�k�n '
Private Sub mnu_Navig_Click()

        mnu_ABC_Write_Click
        mnu_State_Rec_Click
        mnu_State_Begin_Click
        If g_str_Mode = "F" Then
           mnu_State_End_Click
        End If
        mnu_Input_Click
        mnu_Reg_Rec_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                       V�gigvezet a teend�k�n '
Private Sub mnu_Navig2_Click()
        mnu_Navig_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata szalagj�nak h�tt�rsz�ne '
Private Sub mnu_Options_Colors_Back_Click()
        Dim i As Integer  ' index-v�ltoz�
            
        CommonDialog1.CancelError = True
        On Error GoTo ErrHandler
        CommonDialog1.Flags = cdlCCRGBInit
        CommonDialog1.ShowColor
        For i = 1 To 30
            lbl_Turing(i).BackColor = CommonDialog1.Color
        Next i
        Exit Sub
ErrHandler:
        Exit Sub
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata szalagj�nak h�tt�rsz�ne '
Private Sub mnu_Options_Colors_Back2_Click()
        mnu_Options_Colors_Back_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                             Az automata szalagj�nak el�sz�ne '
Private Sub mnu_Options_Colors_Front_Click()
            Dim i As Integer  ' index-v�ltoz�
            
            CommonDialog1.CancelError = True
            On Error GoTo ErrHandler
            CommonDialog1.Flags = cdlCCRGBInit
            CommonDialog1.ShowColor
            For i = 1 To 30
                lbl_Turing(i).ForeColor = CommonDialog1.Color
            Next i
            Exit Sub
ErrHandler:
            Exit Sub
End Sub
' ------------------------------------------------------------------------------------------ '
'                                             Az automata szalagj�nak el�sz�ne '
Private Sub mnu_Options_Colors_Front2_Click()
        mnu_Options_Colors_Front_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     D�szelemek enged�lyez�se '
Private Sub mnu_Options_Flag_Click()
        Dim i        As Integer  ' index-v�ltoz�
        Dim bln_Flag As Boolean  ' D�szelem be van-e kapcsolva ?
            
        bln_Flag = mnu_Options_Flag.Checked
        If bln_Flag Then
           For i = 1 To 6
               lbl_hu(i).Visible = False
           Next i
           mnu_Options_Flag.Checked = False
           mnu_Options_Flag2.Checked = False
        Else
           For i = 1 To 6
               lbl_hu(i).Visible = True
           Next i
           mnu_Options_Flag.Checked = True
           mnu_Options_Flag2.Checked = True
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     D�szelemek enged�lyez�se '
Private Sub mnu_Options_Flag2_Click()
        mnu_Options_Flag_Click
End Sub
' ------------------------------------------------------------------------------------------ '
' KELL - E ???????                              Fej kezd�pozici�j�nak megad�sa '
Private Sub mnu_Options_Head_Click()
        sld_Turing.Enabled = True
        m_int_Head = sld_Turing.Value
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                      V�gtelen ciklusra le�ll '
Private Sub mnu_Options_Loop_Click()
        Dim bln_Endless As Boolean  ' V�gtelen ciklusra le�lljon-e ?
         
        bln_Endless = mnu_Options_Loop.Checked
        If bln_Endless Then
           mnu_Options_Loop.Checked = False
           mnu_Options_Loop2.Checked = False
        Else
           mnu_Options_Loop.Checked = True
           mnu_Options_Loop2.Checked = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                      V�gtelen ciklusra le�ll '
Private Sub mnu_Options_Loop2_Click()
        mnu_Options_Loop_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                        El�z� �llapot enged�lyez�se/letilt�sa '
Private Sub mnu_Options_Prev_Click()
        Dim bln_Prev As Boolean  ' El�z� �llapot enged�lyezve legyen-e ?
         
        bln_Prev = mnu_Options_Prev.Checked
        If bln_Prev Then
           mnu_Options_Prev.Checked = False
           mnu_Options_Prev2.Checked = False
        Else
           mnu_Options_Prev.Checked = True
           mnu_Options_Prev2.Checked = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                        El�z� �llapot enged�lyez�se/letilt�sa '
Private Sub mnu_Options_Prev2_Click()
        mnu_Options_Prev_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       Folyamat ablak enged�lyez�se/letilt�sa '
Private Sub mnu_Options_Progr_Click()
        Dim bln_Progr As Boolean  ' Folyamatjelz� enged�lyezve legyen-e ?
         
        bln_Progr = mnu_Options_Progr.Checked
        If bln_Progr Then
           prg_Turing.Visible = False
           mnu_Options_Progr.Checked = False
           mnu_Options_Progr2.Checked = False
           lin_1.Visible = False
           lin_2.Visible = False
           lin_3.Visible = False
        Else
           prg_Turing.Visible = True
           mnu_Options_Progr.Checked = True
           mnu_Options_Progr2.Checked = True
           lin_1.Visible = True
           lin_2.Visible = True
           lin_3.Visible = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                       Folyamat ablak enged�lyez�se/letilt�sa '
Private Sub mnu_Options_Progr2_Click()
            mnu_Options_Progr_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Hangjelz�s enged�lyez�se '
Private Sub mnu_Options_Sound_Click()
        Dim bln_Sound As Boolean  ' Hangos lej�tsz�s enged�lyezve legyen-e ?
            
        bln_Sound = mnu_Options_Sound.Checked
        If bln_Sound Then
           mnu_Options_Sound.Checked = False
           mnu_Options_Sound2.Checked = False
'          m_bln_Direct = True
        Else
           mnu_Options_Sound.Checked = True
           mnu_Options_Sound2.Checked = True
'          m_bln_Direct = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Hangjelz�s enged�lyez�se '
Private Sub mnu_Options_Sound2_Click()
        mnu_Options_Sound_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                             Kimenet �tad�sa egy m�sik programnak bemenetk�nt '
Private Sub mnu_Output_Input_Full_Click()
        Output_Give
        mnu_Full_Open_Click
        frm_Turing_Input.txt_Input.Text = m_str_Input_New
        mnu_Sim_Begin_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                             Kimenet �tad�sa egy m�sik programnak bemenetk�nt '
Private Sub mnu_Output_Input_Full2_Click()
        mnu_Output_Input_Full_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                             Kimenet �tad�sa egy m�sik feladatnak bemenetk�nt '
Private Sub mnu_Output_Input_Param_Click()
        
        Output_Give
        mnu_Param_Open_Click
        frm_Turing_Input.txt_Input.Text = m_str_Input_New
        mnu_Sim_Begin_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                             Kimenet �tad�sa egy m�sik feladatnak bemenetk�nt '
Private Sub mnu_Output_Input_Param2_Click()
        mnu_Output_Input_Param_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                              Elmentett be�ll�t�sok bet�lt�se '
'                                    ABC, �llapotok, kezd� �llapot, kezd� sz�) '
Private Sub mnu_Param_Open_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        frm_Param_Open.Show 1
        i = begin()
        If i = 1 Then
           check
           cmd_Tur_Start_Click
           mnu_Head_Begin_Click
           sld_Head.Value = sld_Turing.Value
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                              Elmentett be�ll�t�sok bet�lt�se '
'                                    ABC, �llapotok, kezd� �llapot, kezd� sz�) '
Private Sub mnu_Param_Open2_Click()
        mnu_Param_Open_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          Be�ll�t�sok ment�se '
'                                    ABC, �llapotok, kezd� �llapot, kezd� sz�) '
Private Sub mnu_Param_Save_Click()
        frm_Param_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          Be�ll�t�sok ment�se '
'                                    ABC, �llapotok, kezd� �llapot, kezd� sz�) '
Private Sub mnu_Param_Save2_Click()
        mnu_Param_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    Szab�lyok list�ja men�b�l '
Private Sub mnu_Reg_List_Click()
        frm_Reg_List.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    Szab�lyok list�ja men�b�l '
Private Sub mnu_Reg_List2_Click()
        mnu_Reg_List_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   Szab�lyok megad�sa men�b�l '
Private Sub mnu_Reg_Rec_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        frm_Reg_Rec.Show 1
        i = begin()
        If i = 1 Then
           check
           cmd_Tur_Start_Click
           mnu_Head_Begin_Click
           sld_Head.Value = sld_Turing.Value
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   Szab�lyok megad�sa men�b�l '
Private Sub mnu_Reg_Rec2_Click()
        mnu_Reg_Rec_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                V�geredm�ny ment�se file - ba '
Private Sub mnu_Result_Save_Click()
        frm_Result_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                V�geredm�ny ment�se file - ba '
Private Sub mnu_Result_Save2_Click()
        mnu_Result_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                           Szimul�ci� kezd�se '
Private Sub mnu_Sim_Begin_Click()
        Dim i              As Integer  ' index-v�ltoz�
        Dim j              As Integer  ' index-v�ltoz�
        Dim k              As Integer  ' index-v�ltoz�
        Dim int_hossz      As Integer  ' Kezd� sz� hossza
        Dim str_Row_Begin  As String   ' Eredm�nyablak sor�nak bevezet� r�sze
        Dim str_Input_Temp As String   ' kezd�sz� t�rol�s�hoz
        
        k = begin()
        If k = 1 Then
           cmd_Tur_Step.Enabled = True
           mnu_Sim_Step.Enabled = True
           mnu_Options_Loop.Checked = True
           mnu_Options_Loop2.Checked = True
           str_Input_Temp = frm_Turing_Input.txt_Input
           For i = 1 To 30
               lbl_Turing(i).Caption = "*"
               cmd_Turing(i).Visible = False
               cmd_Turing(i).Enabled = True
               lin_Turing(i).Visible = False
               lin_Prev(i).Visible = False
               lbl_Prev(i).Visible = False
           Next i
           int_hossz = Len(str_Input_Temp)
           If m_int_Head_Pos = 3 Then
              m_int_Head = sld_Head.Value
           Else
              m_int_Head = sld_Turing.Value
           End If
           m_int_Nr = 0
           Select Case m_int_Head_Pos
                  Case 1
                       j = m_int_Head - 1
                       For i = 1 To int_hossz
                           lbl_Turing(j + i).Caption = Mid(str_Input_Temp, i, 1)
                           On Error GoTo Err_Handler  ' HIBA
                       Next i
                       sld_Head.Value = sld_Turing.Value
                  Case 2
                       j = m_int_Head + 1
                       For i = 1 To int_hossz
                           k = int_hossz - i + 1
                           lbl_Turing(j - i).Caption = Mid(str_Input_Temp, k, 1)
                           On Error GoTo Err_Handler  ' HIBA
                       Next i
                       sld_Head.Value = sld_Turing.Value - Len(str_Input_Temp) + 1
                  Case 3
                       j = sld_Turing.Value - 1
                       For i = 1 To int_hossz
                           lbl_Turing(j + i).Caption = Mid(str_Input_Temp, i, 1)
                           On Error GoTo Err_Handler  ' HIBA
                       Next i
                       sld_Head.Value = sld_Turing.Value + m_int_Head_Diff
           End Select
           m_str_Head_State = g_vnt_Input
           m_str_Sign = lbl_Turing(m_int_Head).Caption
           On Error GoTo Err_Handler  ' HIBA
           lin_Turing(m_int_Head).Visible = True
           cmd_Turing(m_int_Head).Visible = True
           sld_Sim.Value = m_int_Head
           cmd_Turing(m_int_Head).Caption = m_str_Head_State
           m_str_Row = ""
           lst_Result_Window.Visible = True
           lst_Result_Window.Clear
           m_str_Row = ""
           If lst_Result_Window.ListCount < 100 Then ' CASE
              If lst_Result_Window.ListCount < 10 Then
                 str_Row_Begin = " 00"
              Else
                 str_Row_Begin = " 0"
              End If
           Else
              str_Row_Begin = " "
           End If
           lst_Result_Window.Visible = True
           For j = 1 To 30
               m_str_Row = m_str_Row & lbl_Turing(j)
           Next j
           m_str_Row = str_Row_Begin & lst_Result_Window.ListCount + 1 & _
                     ". -> " & m_str_Row & "   "
           lst_Result_Window.AddItem m_str_Row
           sld_Fej.Value = m_int_Head
        End If
Err_Handler:  Exit Sub
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                           Szimul�ci� kezd�se '
Private Sub mnu_Sim_Begin2_Click()
        mnu_Sim_Begin_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                      Szimul�l�s v�geredm�nye '
Public Sub mnu_Sim_End_Click()
       frm_Result.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                      Szimul�l�s v�geredm�nye '
Private Sub mnu_Sim_End2_Click()
        mnu_Sim_End_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 Szimul�ci� v�grehajt�sa men�b�l egy l�p�sben '
Public Sub mnu_Sim_Execute_Click()
        Dim j As Integer                 ' index-v�ltoz�
        Dim m_bln_Loop_Save As Boolean   ' V�gtelen ciklusra le��jon-e ?
        
        j = begin()
        If j = 1 Then
       
           m_bln_Loop_Save = mnu_Options_Loop.Checked
           cmd_Tur_Start_Click
           mnu_Options_Loop.Checked = m_bln_Loop_Save
           mnu_Options_Loop2.Checked = m_bln_Loop_Save
           m_int_Nr = 0
           If Not mnu_Options_Sound.Checked Then
              m_bln_Direct = False
           End If
           m_bln_Loop = False
           If m_int_Head_Pos = 1 Or m_int_Head_Pos = 2 Then
              m_int_Head = sld_Turing.Value
           Else
              m_int_Head = sld_Head.Value
           End If
           Do While m_int_Head > 0
              cmd_Turing_Click (m_int_Head)
              If m_bln_Loop = True Then
                 Exit Do
              End If
           Loop
           m_bln_Loop = False
           If Not mnu_Options_Sound.Checked Then
              cmd_Turing(m_int_Last).Visible = True
              sld_Sim.Value = m_int_Last
              lin_Turing(m_int_Last).Visible = True
              cmd_Turing(m_int_Last).Caption = Chr(g_int_Prev(3))
           End If
           m_bln_Direct = True
           mnu_Result_Save.Enabled = True
           mnu_Result_Save2.Enabled = True
           tlb_Turing.Buttons(2).ButtonMenus(3).Enabled = True
           mnu_Sim_End.Enabled = True
           mnu_Sim_End2.Enabled = True
           cmd_Result.Enabled = True
           lbl_Big.Enabled = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 Szimul�ci� v�grehajt�sa men�b�l egy l�p�sben '
Private Sub mnu_Sim_Execute2_Click()
        mnu_Sim_Execute_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 �j szimul�ci� (kezd� �llapot vissza�ll�t�sa) '
Private Sub mnu_Sim_New_Click()
        Dim i As Integer  ' index-v�ltoz�
        Dim j As Integer  ' index-v�ltoz�

        For i = Forms.Count - 1 To 0 Step -1
            If Forms(i).Name <> "frm_Turing_Start" Then
               Unload Forms(i)
            End If
        Next i
        lbl_File.Caption = "New"
        lbl_Percent = ""
        msg ("")
        frm_Abc_Rec.lst_ABC.Clear         ' ABC lista t�rl�se
        frm_State_Rec.lst_State.Clear     ' �llapotok list�j�nak t�rl�se
        frm_State_Input.lst_Begin.Clear   ' Kezd� �llapotok list�j�nak t�rl�se
        frm_Turing_Input.txt_Input = ""   ' Input t�rl�se
        With frm_Reg_Rec
             .lst_Reg.Clear              ' Szab�lyok list�j�nak t�rl�se
             .lst_State1.Clear
             .lst_State2.Clear
             .lst_Input.Clear
             .lst_Output.Clear
             .lst_Head.Clear
        End With
        frm_Reg_Rec.lst_Reg.Clear
        frm_State_End.lst_State_End.Clear   ' V�g�llapotok list�j�nak t�rl�se
        lst_Result_Window.Clear             ' Eredm�ny lista t�rl�se
        prg_Turing.Value = 0
        m_int_Nr = 0
        chk_ABC.Value = 0
        chk_State.Value = 0
        chk_Begin.Value = 0
        chk_Input.Value = 0
        chk_Reg.Value = 0
        chk_End.Value = 0
        cmd_Tur_Step.Enabled = True
        mnu_Sim_Step.Enabled = True
        For i = 1 To 30
            lbl_Turing(i).Caption = "*"
            cmd_Turing(i).Visible = False
            cmd_Turing(i).Enabled = True
            lin_Turing(i).Visible = False
            lin_Prev(i).Visible = False
            lbl_Prev(i).Visible = False
'           lbl_Prev(i).Enabled = True
        Next i
        chk_ABC.Value = 0
        chk_Input.Value = 0
        chk_Begin.Value = 0
        chk_State.Value = 0
        chk_Reg.Value = 0
        chk_End.Value = 0
        lbl_Result_Nr = ""
        sld_Fej.Value = 1
        sld_Sim.Value = 1
        sld_Sim.Enabled = False
        chk_Input.Visible = False
        chk_Begin.Visible = False
        chk_Reg.Visible = False
        chk_End.Visible = False
        cmd_Result.Enabled = False
        cmd_Tur_Exec.Enabled = False
        cmd_Tur_Iter.Enabled = False
        cmd_Tur_Start.Enabled = False
        cmd_Tur_Step.Enabled = False
        cmd_Tur_New.Enabled = False
        frm_Reg_Rec.mnu_Prev.Checked = False
        frm_Reg_Rec.mnu_Prev2.Checked = False
        lbl_Input.Enabled = False
        lbl_Begin.Enabled = False
        lbl_Reg.Enabled = False
        lbl_End.Enabled = False
        lbl_Window.Visible = False
        lbl_Big.Enabled = False
        mnu_ABC_List.Enabled = False
        mnu_ABC_List2.Enabled = False
        mnu_Full_Save.Enabled = False
        mnu_Full_Save2.Enabled = False
        tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = False
        mnu_Head.Enabled = False
        mnu_Head2.Enabled = False
        mnu_Input.Enabled = False
        mnu_Input2.Enabled = False
        mnu_Input_Iter.Enabled = False
        mnu_Input_Iter2.Enabled = False
        mnu_Input_Pos.Enabled = False
        mnu_Input_Pos2.Enabled = False
        mnu_Options_Loop.Checked = True ''' KELL-E ???
        mnu_Options_Loop2.Checked = True
        mnu_Output_Input.Enabled = False
        mnu_Output_Input2.Enabled = False
        mnu_Param_Save.Enabled = False
        mnu_Param_Save2.Enabled = False
        tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = False
        mnu_Result_Save.Enabled = False
        mnu_Result_Save2.Enabled = False
        tlb_Turing.Buttons(2).ButtonMenus(3).Enabled = False
        mnu_State_End.Enabled = False
        mnu_State_End2.Enabled = False
        mnu_State_Begin.Enabled = False
        mnu_State_Begin2.Enabled = False
        mnu_State_List.Enabled = False
        mnu_State_List2.Enabled = False
        mnu_Reg_List.Enabled = False
        mnu_Reg_List2.Enabled = False
        mnu_Reg_Rec.Enabled = False
        mnu_Reg_Rec2.Enabled = False
        mnu_Sim_End.Enabled = False
        mnu_Sim_End2.Enabled = False
        mnu_Sim_Execute.Enabled = False
        mnu_Sim_Execute2.Enabled = False
        mnu_Sim_Begin.Enabled = False
        mnu_Sim_Begin2.Enabled = False
        mnu_Sim_Step.Enabled = False
        mnu_Sim_Step2.Enabled = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                 �j szimul�ci� (kezd� �llapot vissza�ll�t�sa) '
Private Sub mnu_Sim_New2_Click()
        mnu_Sim_New_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                               Szimul�l�s l�p�senk�nt men�b�l '
Private Sub mnu_Sim_Step_Click()
        cmd_Tur_Step_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                               Szimul�l�s l�p�senk�nt men�b�l '
Private Sub mnu_Sim_Step2_Click()
        mnu_Sim_Step_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                               Kezd� �llapot megad�sa men�b�l '
Public Sub mnu_State_Begin_Click()
       Dim i As Integer  ' index-v�ltoz�
       
       frm_State_Input.Show 1
       i = begin()
       If i = 1 Then
          check
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                               Kezd� �llapot megad�sa men�b�l '
Private Sub mnu_State_Begin2_Click()
        mnu_State_Begin_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          V�g�llapot megad�sa '
Public Sub mnu_State_End_Click()
       Dim i As Integer  ' index-v�ltoz�
       
       frm_State_End.Show 1
       i = begin()
       If i = 1 Then
          check
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          V�g�llapot megad�sa '
Private Sub mnu_State_End2_Click()
        mnu_State_End_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    �llapotok list�ja men�b�l '
Public Sub mnu_State_List_Click()
       frm_State_List.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                    �llapotok list�ja men�b�l '
Private Sub mnu_State_List2_Click()
        mnu_State_List_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   �llapotok megad�sa men�b�l '
Private Sub mnu_State_Rec_Click()
        Dim i As Integer   ' index-v�ltoz�
        
        chk_State.Value = 0
        frm_State_Rec.Show 1
        i = begin()
        If i = 1 Then
           check
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   �llapotok megad�sa men�b�l '
Private Sub mnu_State_Rec2_Click()
        mnu_State_Rec_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata fejst�lusa : szakasszal '
Private Sub mnu_Stil_Inter_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        If mnu_Stil_Inter.Checked = 1 Then
           mnu_Stil_Inter.Checked = 0
           mnu_Stil_Slider.Checked = 1
           mnu_Stil_Inter2.Checked = 0
           mnu_Stil_Slider2.Checked = 1
           lin_Inter.Visible = False
        Else
           mnu_Stil_Inter.Checked = 1
           mnu_Stil_Slider.Checked = 0
           mnu_Stil_Inter2.Checked = 1
           mnu_Stil_Slider2.Checked = 0
           sld_Sim.Visible = False
           lin_Inter.Visible = True
           For i = 1 To 30
               cmd_Turing(i).Top = 3600
           Next i
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata fejst�lusa : szakasszal '
Private Sub mnu_Stil_Inter2_Click()
        mnu_Stil_Inter_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata fejst�lusa : cs�szk�val '
Private Sub mnu_Stil_Slider_Click()
        Dim i As Integer  ' index-v�ltoz�
        
        If mnu_Stil_Slider.Checked = 1 Then
           mnu_Stil_Slider.Checked = 0
           mnu_Stil_Inter.Checked = 1
           mnu_Stil_Slider2.Checked = 0
           mnu_Stil_Inter2.Checked = 1
           lin_Inter.Visible = True
        Else
           mnu_Stil_Slider.Checked = 1
           mnu_Stil_Inter.Checked = 0
           mnu_Stil_Slider2.Checked = 1
           mnu_Stil_Inter2.Checked = 0
           sld_Sim.Visible = True
           For i = 1 To 30
               cmd_Turing(i).Top = 3690
           Next i
           lin_Inter.Visible = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                          Az automata fejst�lusa : cs�szk�val '
Private Sub mnu_Stil_Slider2_Click()
        mnu_Stil_Slider_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                             Kimenet �tad�sa egy m�sik feladatnak bemenetk�nt '
Public Sub Output_Give()
        Dim i             As Integer   ' index-v�ltoz�
        Dim j             As Integer   ' index-v�ltoz�
        Dim int_From_Here As Integer   ' Hol kezd�dik az input
        Dim str_Last      As String    ' Utols� konfigur�ci� a list�ban
        Dim k As Integer
        
        m_str_Input_New = ""
        j = lst_Result_Window.ListCount - 1
        str_Last = lst_Result_Window.List(j)
        For i = 10 To 39
            If Mid(str_Last, i, 1) <> "*" Then
               int_From_Here = i
               Exit For
            End If
        Next i
        For i = int_From_Here To 39
            If Mid(str_Last, i, 1) <> "*" Then
               m_str_Input_New = m_str_Input_New + Mid(str_Last, i, 1)
            Else
              Exit For
            End If
        Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   Szab�ly t�rl�se a list�b�l '
Public Sub Reg_Delete()
       Dim i              As Integer  ' index-v�ltoz�
       Dim j              As Integer  ' index-v�ltoz�
       Dim k              As Integer  ' index-v�ltoz�
       Dim m              As Integer  ' index-v�ltoz�
       Dim n              As Integer  ' index-v�ltoz�
       Dim int_Reg_Del    As Integer  ' Melyik szab�lyt kell t�r�lni ?
       Dim int_Turing_Del As Integer  ' Szab�ly-t�mbben hanyadik a t�rlend� elem ?
       
       int_Reg_Del = frm_Reg_Rec.lst_Reg.ListIndex
       n = frm_Reg_Rec.lst_Reg.ListCount
       If int_Reg_Del < n Then
          For i = 1 To n
              If m_int_Turing(1, i) = Asc(Left(frm_Reg_Rec.lst_Reg, 1)) And _
                 m_int_Turing(2, i) = Asc(Mid(frm_Reg_Rec.lst_Reg, 5, 1)) Then
                 int_Turing_Del = i
                 Exit For
              End If
          Next i
          For i = int_Turing_Del To n - 1
              For k = 1 To 5
                  m_int_Turing(k, i) = m_int_Turing(k, i + 1)
              Next k
          Next i
          If int_Reg_Del >= 0 Then
             frm_Reg_Rec.lst_Reg.RemoveItem int_Reg_Del
          Else
             Beep
          End If
          ReDim Preserve m_int_Turing(1 To 5, 1 To n)   ' vagy n-1
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                  Szab�ly felv�tele a list�ba '
Public Sub Reg_Record()
       Dim i           As Integer   ' index-v�ltoz�
       Dim j           As Integer   ' index-v�ltoz�
       Dim k           As Integer   ' index-v�ltoz�
       Dim m           As Integer   ' index-v�ltoz�
       Dim n           As Integer   ' index-v�ltoz�
       Dim str_Reg     As String    ' szab�ly megjelen�t�s�hez az ablakban
       Dim int_Temp(5) As Integer   ' Cser�hez szab�ly felv�tel�n�l
       Dim str_Sort(3) As String    ' �sszehasonl�t�shoz szab�ly felv�tel�n�l
       
       n = frm_Reg_Rec.lst_Reg.ListCount
       g_int_Reg = 0
       frm_Reg_Rec.lbl_Reg.Caption = "Szab�lyok megad�sa"
       For i = 1 To n
           If m_int_Turing(1, i) = Asc(frm_Reg_Rec.lbl_State1.Caption) And _
              m_int_Turing(2, i) = Asc(frm_Reg_Rec.lbl_Input.Caption) Then
              g_int_Reg = 1
           End If
       Next i
       If g_int_Reg = 0 Then
          frm_Reg_Rec.lbl_Reg.Caption = "Szab�lyok megad�sa"
          str_Reg = frm_Reg_Rec.lst_State1.Text & " , " & _
          frm_Reg_Rec.lst_Input.Text & " -> " & _
          frm_Reg_Rec.lst_State2.Text
          If g_str_Mode = "T" Then
             str_Reg = str_Reg & " , " & frm_Reg_Rec.lst_Output.Text & " , " & _
                       Left(frm_Reg_Rec.lst_Head.Text, 1)
          End If
          frm_Reg_Rec.lst_Reg.AddItem str_Reg
          n = frm_Reg_Rec.lst_Reg.ListCount
          frm_Reg_Rec.lbl_Reg_Nr = n
          ReDim Preserve m_int_Turing(1 To 5, 1 To n)
          m_int_Turing(1, n) = Asc(frm_Reg_Rec.lbl_State1)
          m_int_Turing(2, n) = Asc(frm_Reg_Rec.lbl_Input)
          m_int_Turing(3, n) = Asc(frm_Reg_Rec.lbl_State2)
          If g_str_Mode = "T" Then
             m_int_Turing(4, n) = Asc(frm_Reg_Rec.lbl_Output)
             m_int_Turing(5, n) = Asc(Left(frm_Reg_Rec.lbl_Head, 1))
          Else
             m_int_Turing(4, n) = m_int_Turing(2, n)
             m_int_Turing(5, n) = Asc("J")
          End If
          If n > 1 Then
             For i = 1 To n - 1
                 str_Sort(1) = ""
                 For k = 1 To 5
                     str_Sort(1) = str_Sort(1) & Chr(m_int_Turing(k, i))
                 Next k
                 For j = i + 1 To n
                     str_Sort(2) = ""
                     For k = 1 To 5
                         str_Sort(2) = str_Sort(2) & Chr(m_int_Turing(k, j))
                     Next k
                     If str_Sort(1) > str_Sort(2) Then
                        For k = 1 To 5
                            int_Temp(k) = m_int_Turing(k, i)
                        Next k
                        For k = 1 To 5
                            m_int_Turing(k, i) = m_int_Turing(k, j)
                        Next k
                        For k = 1 To 5
                            m_int_Turing(k, j) = int_Temp(k)
                        Next k
                     End If
                 Next j
             Next i
          Else
             m_int_Turing(1, 1) = Asc(frm_Reg_Rec.lbl_State1)
             m_int_Turing(2, 1) = Asc(frm_Reg_Rec.lbl_Input)
             m_int_Turing(3, 1) = Asc(frm_Reg_Rec.lbl_State2)
             If g_str_Mode = "T" Then
                m_int_Turing(4, 1) = Asc(frm_Reg_Rec.lbl_Output)
                m_int_Turing(5, 1) = Asc(Left(frm_Reg_Rec.lbl_Head, 1))
             Else
                m_int_Turing(4, 1) = m_int_Turing(2, 1)
                m_int_Turing(5, 1) = Asc("J")
             End If
          End If
          If frm_Reg_Rec.mnu_Prev.Checked = False Then
             frm_Reg_Rec.lst_State1.ListIndex = -1
             frm_Reg_Rec.lst_Input.ListIndex = -1
             frm_Reg_Rec.lst_State2.ListIndex = -1
             frm_Reg_Rec.lst_Output.ListIndex = -1
             frm_Reg_Rec.lst_Head.ListIndex = -1
          End If
       Else
          frm_Reg_Rec.lbl_Reg.Caption = "M�r l�tezik ilyen A1, BE p�ros�t�s !"
          frm_Reg_Rec.cmd_Rec.Enabled = False
          frm_Reg_Rec.lst_State1.SetFocus
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         Fej�ll�s a kezd�sn�l '
Private Sub sld_Head_Click()
       
       m_int_Head = sld_Head.Value
       m_int_Head_Diff = sld_Head.Value - sld_Turing.Value
       sld_Head.Visible = False
       cmd_Tur_Start_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                A fej kezd��rt�k�nek megad�sa '
Public Sub sld_Turing_Click()
       
       sld_Turing.Visible = False
       m_int_Head = sld_Turing.Value
       If m_int_Head + Len(g_vnt_Input) > 25 Then
          GoTo Err_Handler
       End If
       sld_Head.Min = 2
       sld_Head.Max = 29
       sld_Head.Left = 975 + (sld_Turing.Value - 2) * 360
       sld_Head.Width = Len(frm_Turing_Input.txt_Input.Text) * 360
       sld_Head.Min = sld_Turing.Value
       If Len(frm_Turing_Input.txt_Input.Text) > 0 Then
          sld_Head.Max = sld_Turing.Value + Len(frm_Turing_Input.txt_Input.Text) - 1
       End If
       sld_Head.Visible = False
       If m_int_Head_Pos = 1 Or m_int_Head_Pos = 2 Then
          sld_Head.Value = sld_Turing.Value
       Else
          sld_Head.Value = sld_Turing.Value + m_int_Head_Diff
       End If
       cmd_Tur_Start_Click
Err_Handler:  Exit Sub

End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                    Eszk�zt�r '
Private Sub tlb_Turing_ButtonClick(ByVal Button As MSComctlLib.Button)
        
        Select Case Button.Key
               Case "Menuk"
                    frm_Menu1.Show
               Case "Kilep"
                    form_End
               Case "Peldak"
                    mnu_Full_Open_Click
        End Select
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                   Men�gombok '
Private Sub tlb_Turing_ButtonMenuClick(ByVal ButtonMenu As MSComctlLib.ButtonMenu)
        
        Select Case ButtonMenu.Key
               Case "mnu_Reg_Open"
                    mnu_Reg_Rec_Click
               Case "mnu_Param_Open"
                    mnu_Param_Open_Click
               Case "mnu_Full_Open"
                    mnu_Full_Open_Click
               Case "mnu_Param_Save"
                    mnu_Param_Save_Click
                    tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = False
               Case "mnu_Full_Save"
                    mnu_Full_Save_Click
               Case "mnu_Result_Save"
                    mnu_Result_Save_Click
        End Select
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                            �ra megjelen�t�se '
Private Sub tmr_Turing_Timer()
        If lbl_Time.Caption <> CStr(Time) Then
           lbl_Time.Caption = Time
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                     Ellen�rzi, hogy kezd�dhet-e szimul�ci� ? '
Public Function begin()
        Dim i As Integer                ' index-v�ltoz�
        Dim int_Go(1 To 6) As Integer   ' R�sz-tev�kenys�gek el vannak-e v�gezve ?
        
        int_Go(1) = chk_ABC.Value
        int_Go(2) = chk_State.Value
        int_Go(3) = chk_Begin.Value
        If g_str_Mode = "F" Then
           int_Go(4) = chk_End.Value
        Else
           int_Go(4) = 1
        End If
        int_Go(5) = chk_Input.Value
        int_Go(6) = chk_Reg.Value
        begin = 1
        For i = 1 To 6
            begin = begin * int_Go(i)
        Next i
End Function
' ------------------------------------------------------------------------------------------ '
'                                                         �zenet megjelen�t�se '
Public Function msg(szoveg As String) As String
       lbl_Msg.Caption = szoveg
End Function
' ------------------------------------------------------------------------------------------ '
'                            Ellen�rzi, hogy minden param�ter meg van-e adva ? '
Public Function param()
        Dim i As Integer               ' index-v�ltoz�
        Dim int_Go(1 To 5) As Integer  ' R�sz-tev�kenys�gek el vannak-e v�gezve ?
        
        int_Go(1) = chk_ABC.Value
        int_Go(2) = chk_State.Value
        int_Go(3) = chk_Begin.Value
        If g_str_Mode = "F" Then
           int_Go(4) = chk_End.Value
        Else
           int_Go(4) = 1
        End If
        int_Go(5) = chk_Input.Value
        param = 1
        For i = 1 To 5
            param = param * int_Go(i)
        Next i
End Function
' ------------------------------------------------------------------------------------------ '
