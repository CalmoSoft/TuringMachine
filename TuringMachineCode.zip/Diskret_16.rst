

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Diskret_16 Turing-g�p m�k�d�s�nek list�ja.
                      ==========================================



 A megadott ABC     : 0, 1

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5

 Kezd� �llapot      : 1

 Kezd� sz�          : 111111111

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      1 , 0 -> 0 , 1 , B
                      1 , 1 -> 2 , 0 , J
                      2 , 0 -> 2 , 0 , M
                      2 , 1 -> 3 , 0 , J
                      3 , 0 -> 3 , 0 , M
                      3 , 1 -> 4 , 0 , J
                      4 , 0 -> 4 , 0 , M
                      4 , 1 -> 5 , 0 , J
                      5 , 0 -> 1 , 1 , J
                      5 , 1 -> 5 , 1 , M


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************111111111*******   