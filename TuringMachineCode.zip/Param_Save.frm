VERSION 5.00
Begin VB.Form frm_Param_Save 
   BackColor       =   &H00808000&
   Caption         =   "Param�terek ment�se"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   3600
   ControlBox      =   0   'False
   HelpContextID   =   10
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3600
   Begin VB.TextBox txt_Param 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   720
      TabIndex        =   2
      ToolTipText     =   "Az �llom�ny nev�nek megad�sa"
      Top             =   1920
      Width           =   2175
   End
   Begin VB.CommandButton cmd_File_Save 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File ment�se"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   945
      TabIndex        =   1
      ToolTipText     =   "A megadott �llom�ny ment�se"
      Top             =   2925
      Width           =   1710
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   945
      TabIndex        =   0
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   3645
      Width           =   1710
   End
   Begin VB.Shape fra_File_Save 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4095
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   480
      Width           =   2895
   End
   Begin VB.Label lbl_Param1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "File megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   720
      TabIndex        =   3
      Top             =   960
      Width           =   2175
   End
End
Attribute VB_Name = "frm_Param_Save"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Param_Save    :  Az automata be�ll�t�sainak ment�se
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        frm_Turing_Start.msg ("")
        Unload frm_Param_Save
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                            Elmentett be�ll�t�sok ment�se : '
'                                                              ABC lista, �llapotok list�ja, '
'                                                       kezd� �llapot, kezd� sz�, v�g�llapot '
Public Sub cmd_File_Save_Click()
       Dim i               As Integer                 ' index-v�ltoz�
       Dim str_ABC         As String                  ' Az ABC t�rol�s�hoz
       Dim str_State       As String                  ' Az �llapotok t�rol�s�hoz
       Dim fso             As New FileSystemObject    ' File ment�s�hez
       Dim txtFile                                    ' Mentend� file neve
        
        
       Set fso = CreateObject("Scripting.FileSystemObject")
       If g_str_Mode = "T" Then
          Set txtFile = fso.CreateTextFile("C:\turing\" & txt_Param & ".prt", True)
       Else
          Set txtFile = fso.CreateTextFile("C:\turing\" & txt_Param & ".prf", True)
       End If
       str_ABC = ""
       str_State = ""
       For i = 1 To frm_Abc_Rec.lst_ABC.ListCount
           str_ABC = str_ABC + frm_Abc_Rec.lst_ABC.List(i - 1)
       Next i
       For i = 1 To frm_State_Rec.lst_State.ListCount
           str_State = str_State + frm_State_Rec.lst_State.List(i - 1)
       Next i
       With txtFile
            .WriteLine (str_ABC)
            .WriteLine (str_State)
            .WriteLine (frm_State_Input.lbl_Kezdo.Caption)
            If g_str_Mode = "F" Then
               .WriteLine (frm_Turing_Input.txt_Input.Text)
               .WriteLine (frm_State_End.lbl_State_End.Caption)
            Else
               .WriteLine (frm_Turing_Input.txt_Input.Text)
            End If
            .Close
       End With
       frm_Turing_Start.msg ("File ment�se befejez�d�tt")
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        
        If frm_Turing_Start.lbl_File <> "" Then
           txt_Param = frm_Turing_Start.lbl_File
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
