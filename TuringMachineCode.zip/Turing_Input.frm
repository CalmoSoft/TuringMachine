VERSION 5.00
Begin VB.Form frm_Turing_Input 
   BackColor       =   &H00808000&
   Caption         =   "Input megad�sa"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   3615
   ControlBox      =   0   'False
   HelpContextID   =   20
   LinkTopic       =   "Form7"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3615
   Begin VB.ListBox lst_ABC 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1740
      ItemData        =   "Turing_Input.frx":0000
      Left            =   720
      List            =   "Turing_Input.frx":0002
      TabIndex        =   5
      ToolTipText     =   "Az automata ABC-je"
      Top             =   2175
      Width           =   2160
   End
   Begin VB.CommandButton cmd_Clear_Input 
      BackColor       =   &H00C0C0C0&
      Caption         =   "T�r�l"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   720
      TabIndex        =   3
      ToolTipText     =   "T�rli a megadott inputot"
      Top             =   4065
      Width           =   855
   End
   Begin VB.TextBox txt_Input 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   405
      Left            =   720
      TabIndex        =   0
      ToolTipText     =   "Az atomata inputj�nak (kezd�sz�) megad�sa"
      Top             =   1215
      Width           =   2175
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2040
      TabIndex        =   1
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4065
      Width           =   855
   End
   Begin VB.Label lbl_ABC2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "ABC"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   720
      TabIndex        =   6
      Top             =   1800
      Width           =   2175
   End
   Begin VB.Label lbl_Input_Msg 
      Alignment       =   2  'Center
      BackColor       =   &H000000FF&
      Caption         =   "Nem egyezik az ABC-vel !"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   4
      Top             =   165
      Visible         =   0   'False
      Width           =   2880
   End
   Begin VB.Label lbl_Input 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Input megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   720
      TabIndex        =   2
      Top             =   855
      Width           =   2175
   End
   Begin VB.Shape fra_Input 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4095
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   600
      Width           =   2895
   End
End
Attribute VB_Name = "frm_Turing_Input"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Turing_Input  :  Az automata kezd� szava
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                           Az input t�rl�se '
Private Sub cmd_Clear_Input_Click()
        txt_Input = ""
        txt_Input.SetFocus
        lbl_Input_Msg.Visible = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Public Sub cmd_Close_Click()
       
       If Len(txt_Input.Text) > 0 Then
          If Good_Input() = 1 Then
             frm_Turing_Start.msg ("")
             frm_Turing_Input.Hide
             frm_Turing_Start.chk_Input = 1
             frm_Turing_Start.mnu_Head.Enabled = True
             frm_Turing_Start.mnu_Head2.Enabled = True
             frm_Turing_Start.mnu_Input_Pos.Enabled = True
             frm_Turing_Start.mnu_Input_Pos2.Enabled = True
             If frm_Turing_Start.param() = 1 Then
                frm_Turing_Start.mnu_Param_Save.Enabled = True
                frm_Turing_Start.mnu_Param_Save2.Enabled = True
                frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
             End If
             If frm_Turing_Start.begin() = 1 Then
                frm_Turing_Start.mnu_Full_Save.Enabled = True
                frm_Turing_Start.mnu_Full_Save2.Enabled = True
                frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = True
             End If
             lbl_Input_Msg.Visible = False
             frm_Turing_Start.cmd_Tur_Start_Click ' KELL-E ???
          Else
             Beep
             lbl_Input_Msg.Visible = True
             txt_Input.SetFocus
          End If
       Else
          frm_Turing_Input.Hide
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                           �rlap aktiv�l�sa '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�

        lst_ABC.Clear
        For i = 1 To frm_Abc_Rec.lst_ABC.ListCount
            lst_ABC.AddItem frm_Abc_Rec.lst_ABC.List(i - 1)
        Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                             Input mead�sa az ABC-list�b�l eg�rrel kattitva '
Private Sub lst_ABC_Click()
        txt_Input = txt_Input & lst_ABC.Text
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                  J�-e a be�t�tt karakter ? '
Private Sub txt_Input_Change()
        
        If Good_Input() = 0 Then
             Beep
             lbl_Input_Msg.Visible = True
        Else
             lbl_Input_Msg.Visible = False
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            J�-e az input ? '
Public Function Good_Input()
       Dim i         As Integer             ' index-v�ltoz�
       Dim j         As Integer             ' index-v�ltoz�
       Dim int_Good1 As Integer             ' J�-e az input ?
       Dim int_Good2 As Integer             ' J�-e az input ?
       
       int_Good2 = 1
       For i = 1 To Len(txt_Input)
           int_Good1 = 0
           For j = 1 To frm_Abc_Rec.lst_ABC.ListCount
               If Mid(txt_Input, i, 1) = frm_Abc_Rec.lst_ABC.List(j - 1) Then
                  int_Good1 = 1
               End If
           Next j
           int_Good2 = int_Good2 * int_Good1
       Next i
       Good_Input = int_Good2
End Function
' ------------------------------------------------------------------------------------------ '

