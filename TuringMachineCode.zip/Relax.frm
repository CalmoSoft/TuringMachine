VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frm_Relax 
   BackColor       =   &H00808000&
   Caption         =   "                                 Relax - Sam Lloyd 15-�s logikai j�t�ka"
   ClientHeight    =   3300
   ClientLeft      =   660
   ClientTop       =   4215
   ClientWidth     =   7635
   ControlBox      =   0   'False
   LinkTopic       =   "form13"
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   3300
   ScaleWidth      =   7635
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "1"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   1
      Left            =   1530
      TabIndex        =   21
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1013
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "2"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   2
      Left            =   2010
      TabIndex        =   20
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1013
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   3
      Left            =   2490
      TabIndex        =   19
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1013
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   4
      Left            =   2970
      TabIndex        =   18
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1013
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   5
      Left            =   1530
      TabIndex        =   17
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1493
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   6
      Left            =   2010
      TabIndex        =   16
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1493
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   7
      Left            =   2490
      TabIndex        =   15
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1493
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   8
      Left            =   2970
      TabIndex        =   14
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1493
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "9"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   9
      Left            =   1530
      TabIndex        =   13
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1973
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "10"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   10
      Left            =   2010
      TabIndex        =   12
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1973
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "11"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   11
      Left            =   2490
      TabIndex        =   11
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1973
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "12"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   12
      Left            =   2970
      TabIndex        =   10
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   1973
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "13"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   13
      Left            =   1530
      TabIndex        =   9
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   2453
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "14"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   14
      Left            =   2010
      TabIndex        =   8
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   2453
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      Caption         =   "15"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   15
      Left            =   2490
      TabIndex        =   7
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   2453
      Width           =   495
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Index           =   16
      Left            =   2970
      TabIndex        =   6
      ToolTipText     =   "Kattint�sra : ha a szomsz�dos cella �res, akkor ez az elem annak hely�re l�p, ez pedig �res lesz"
      Top             =   2453
      Width           =   495
   End
   Begin VB.TextBox msg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00800080&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   1530
      MultiLine       =   -1  'True
      TabIndex        =   5
      ToolTipText     =   "T�ves l�p�sek sz�ma, megold�s jelz�se"
      Top             =   286
      Visible         =   0   'False
      Width           =   1935
   End
   Begin VB.CommandButton cmdExit 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kil�p�s"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4170
      TabIndex        =   4
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   2453
      Width           =   1935
   End
   Begin VB.CommandButton cmdGameStart 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Alaphelyzet"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4170
      TabIndex        =   3
      ToolTipText     =   "Alaphelyzetbe �ll�tja a t�bl�t"
      Top             =   1973
      Width           =   1935
   End
   Begin VB.CommandButton cmdGameMix2 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Tr�kk�s kever�s"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4170
      TabIndex        =   2
      ToolTipText     =   """Nem lehet kirakni"" -  kever�s"
      Top             =   1493
      Width           =   1935
   End
   Begin VB.CommandButton cmdGameMix 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Kever�s"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4170
      TabIndex        =   1
      ToolTipText     =   "V�letlenszer� kever�st v�gez a t�bl�n"
      Top             =   1013
      Width           =   1935
   End
   Begin VB.TextBox msg2 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00800080&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   495
      Left            =   4170
      MultiLine       =   -1  'True
      TabIndex        =   0
      ToolTipText     =   "L�p�sek sz�ma"
      Top             =   286
      Visible         =   0   'False
      Width           =   1935
   End
   Begin VB.Timer Timer1 
      Interval        =   500
      Left            =   5520
      Top             =   5040
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   6240
      Top             =   5040
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   3015
      Left            =   570
      Shape           =   4  'Rounded Rectangle
      Top             =   143
      Width           =   6495
   End
   Begin VB.Menu mnuGame 
      Caption         =   "&J�t�k"
      Begin VB.Menu mnuGameMix 
         Caption         =   "&Kever�s"
      End
      Begin VB.Menu mnuGameMix2 
         Caption         =   "&Tr�kk�s kever�s"
      End
      Begin VB.Menu mnuSeparator1 
         Caption         =   "-"
         Index           =   1
      End
      Begin VB.Menu mnuGameStart 
         Caption         =   "&Alaphelyzet"
      End
      Begin VB.Menu mnuSeparator2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExitKilep 
         Caption         =   "Kil�p"
      End
   End
   Begin VB.Menu mnuOpt 
      Caption         =   "&Opci�k"
      Begin VB.Menu mnuOptColor 
         Caption         =   "&H�tt�rsz�n"
      End
      Begin VB.Menu mnuOptSzoveg 
         Caption         =   "&Sz�vegsz�n"
      End
      Begin VB.Menu mnuOptSzovHat 
         Caption         =   "S&z�veg h�tt�rsz�ne"
      End
      Begin VB.Menu mnuSeparator3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuOptKever 
         Caption         =   "&Kever�sek sz�ma"
      End
   End
End
Attribute VB_Name = "frm_Relax"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 ' ---------------------------------------------------------------------------- '
'
' frm_Relax         :  Sam Lloyd 15-�s (logikai-kirak�s) j�t�ka
'
' ---------------------------------------------------------------------------- '
       Option Explicit
       Option Base 1
' ---------------------------------------------------------------------------- '
       Public csere        As Integer
       Public kev_nr       As Integer
       Public lepes        As Integer
       Public teves_lepes  As Integer
       Public ugyes        As Integer
       Public ures         As Integer
       Dim Kever(4)        As Integer
       Dim Mix(16)         As Integer
       Dim Jo(16, 4)       As Integer
' ---------------------------------------------------------------------------- '
'
Private Sub Form_Load()
       Dim i As Integer
       Dim j As Integer
       Dim k As Integer
       Dim hol As Integer
       Dim szoveg As String
       Dim sor As String
       Dim sor1 As String
       Dim sor2 As String
       Dim sor3 As String
       Dim vel As Single

       ures = 16
       kev_nr = 50
       lepes = 0
       teves_lepes = 0

'      sor1 = "0205000001030600020407000308000001060900"
'      sor2 = "0205071003060811040712000510130006091114"
'      sor3 = "071012150811160009140000101315001114160012150000"
'      sor = sor1 & sor2 & sor3

'      For i = 1 To 16
'          For j = 1 To 4
'              hol = 8 * (i - 1) + 2 * (j - 1) + 1
'              Jo(i, j) = Val(Mid(sor, hol, 2))
'          Next j
'      Next i
       For i = 1 To 16
           k = 0
           If i > 4 Then
              k = k + 1
              Jo(i, k) = i - 4
           End If
           If i Mod 4 <> 1 Then
              k = k + 1
              Jo(i, k) = i - 1
           End If
           If i Mod 4 > 0 Then
              k = k + 1
              Jo(i, k) = i + 1
           End If
           If i < 13 Then
              k = k + 1
              Jo(i, k) = i + 4
           End If
           If k < 4 Then
              For j = k + 1 To 4
                  Jo(i, j) = 0
              Next j
          End If
       Next i
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub Command1_Click(Index As Integer)

        csere = Mehet(Index)
        If csere <> 0 Then
           msg.Visible = False
           Command1(ures).Caption = Command1(Index).Caption
           Command1(Index).Caption = ""
           ures = Index
           If Kesz() = 15 Then
              msg.Visible = True
              msg.Text = "sorRENDBEN!"
           Else
              msg.Visible = False
           End If
           lepes = lepes + 1
           msg2.Visible = True
           msg2.Text = lepes & ". " & "l�p�s"
        Else
           teves_lepes = teves_lepes + 1
           msg.Visible = True
           msg.Text = teves_lepes & ". " & "t�ves l�p�s"
        End If
End Sub
' ---------------------------------------------------------------------------- '
'
Public Function Mehet(ind As Integer) As Integer
       Dim i As Integer
       Dim ok As Integer

       ok = 0
       For i = 1 To 4
           If ures = Jo(ind, i) Then
              ok = Jo(ind, i)
              Exit For
           End If
       Next i
       Mehet = ok
End Function
' ---------------------------------------------------------------------------- '
'
Function Kesz() As Integer
         Dim i, j As Integer
         
         j = 0
         For i = 1 To 15
             If Command1(i).Caption = i Then
                j = j + 1
             End If
         Next i
         Kesz = j
End Function
' ---------------------------------------------------------------------------- '
'
Private Sub cmdGameMix2_Click()
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        Dim van As Integer
        Dim vege As Integer

        msg.Visible = False
        msg.Text = ""
        msg2.Visible = False
        msg2.Text = ""
        lepes = 0
        teves_lepes = 0
        vege = 1
        j = 1
        van = 0
        For i = 1 To 16
            Mix(i) = 99
        Next i
        Mix(1) = 15 * Rnd
        Do While vege = 1
           van = 0
           i = 15 * Rnd
           For k = 1 To j
               If Mix(k) = i Then
                  van = 1
                  Exit For
               End If
           Next k
           If van = 0 Then
              j = j + 1
              Mix(j) = i
           End If
           If j = 16 Then
              vege = 0
           End If
        Loop
        For k = 1 To 16
            Command1(k).Caption = Mix(k)
            If Mix(k) = 0 Then
               ures = k
               Command1(k).Caption = ""
            End If
        Next k
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub cmdGameMix_Click()
        Dim i        As Integer
        Dim j        As Integer
        Dim k        As Integer
        Dim m        As Integer
        Dim ind      As Integer
        Dim vege     As Integer
        Dim veletlen As Integer
        
        msg2.Visible = False
        msg2.Text = ""
        lepes = 0
        teves_lepes = 0
        msg.Visible = False
        msg.Text = ""
        For k = 1 To kev_nr
            m = 0
            For i = 1 To 16
                For j = 1 To 4
                    If Jo(i, j) = ures Then
                       m = m + 1
                       Kever(m) = i
                    End If
                Next j
            Next i
            vege = 1
            Do While vege = 1
               veletlen = Int(m * Rnd) + 1
               If veletlen > 0 Then
                  vege = 0
               End If
            Loop
            ind = Kever(veletlen)
            Command1(ures).Caption = Command1(ind).Caption
            Command1(ind).Caption = ""
            ures = ind
        Next k
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub cmdGameStart_Click()
        Dim i As Integer
        
        msg2.Visible = False
        msg2.Text = ""
        lepes = 0
        teves_lepes = 0
        msg.Visible = False
        msg.Text = ""
        For i = 1 To 15
            Command1(i).Caption = i
        Next i
        Command1(16).Caption = ""
        ures = 16
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub cmdExit_Click()
        Unload Me
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuExitKilep_Click()
        End
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuGameMix_Click()
        Call cmdGameMix_Click
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuGameMix2_Click()
        Call cmdGameMix2_Click
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuGameStart_Click()
        Call cmdGameStart_Click
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuOptColor_Click()

        CommonDialog1.CancelError = True
        On Error GoTo ErrHandler
        CommonDialog1.Flags = cdlCCRGBInit
        CommonDialog1.ShowColor
        frm_Relax.BackColor = CommonDialog1.Color
        Exit Sub
ErrHandler:
        Exit Sub
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuOptKever_Click()
        kev_nr = InputBox("K�rem adja meg a kever�sek sz�m�t")
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuOptSzoveg_Click()

        CommonDialog1.CancelError = True
        On Error GoTo ErrHandler
        CommonDialog1.Flags = cdlCCRGBInit
        CommonDialog1.ShowColor
        msg.ForeColor = CommonDialog1.Color
        msg2.ForeColor = CommonDialog1.Color
        Exit Sub
ErrHandler:
        Exit Sub
End Sub
' ---------------------------------------------------------------------------- '
'
Private Sub mnuOptSzovHat_Click()

        CommonDialog1.CancelError = True
        On Error GoTo ErrHandler
        CommonDialog1.Flags = cdlCCRGBInit
        CommonDialog1.ShowColor
        msg.BackColor = CommonDialog1.Color
        msg2.BackColor = CommonDialog1.Color
        Exit Sub
ErrHandler:
        Exit Sub
End Sub
' ---------------------------------------------------------------------------- '
