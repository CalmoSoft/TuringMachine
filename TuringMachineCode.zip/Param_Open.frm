VERSION 5.00
Begin VB.Form frm_Param_Open 
   BackColor       =   &H00808000&
   Caption         =   "Param�terek beolvas�sa"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2850
   ClientWidth     =   4440
   ControlBox      =   0   'False
   HelpContextID   =   9
   LinkTopic       =   "Form10"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   4440
   Begin VB.FileListBox fil_Param 
      Appearance      =   0  'Flat
      Height          =   2565
      Left            =   960
      TabIndex        =   0
      ToolTipText     =   "A megnyithat� �llom�nyok list�ja"
      Top             =   990
      Width           =   2535
   End
   Begin VB.CommandButton cmd_File_Open 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File bet�lt�se"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   960
      TabIndex        =   1
      ToolTipText     =   "A kijel�lt �llom�ny megnyit�sa"
      Top             =   3765
      Width           =   2520
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   960
      TabIndex        =   2
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4275
      Width           =   2520
   End
   Begin VB.Shape fra_File_Open 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4575
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   3735
   End
   Begin VB.Label lbl_Param2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "File kiv�laszt�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   960
      TabIndex        =   3
      Top             =   390
      Width           =   2535
   End
End
Attribute VB_Name = "frm_Param_Open"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Param_Open    :  Az automata mentett be�ll�t�sainak bet�lt�se
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        frm_Turing_Start.msg ("")
        frm_Param_Open.Hide ' Unload nem lehet !
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          Elmentett be�ll�t�sok bet�lt�se : '
'                                                              ABC lista, �llapotok list�ja, '
'                                                       kezd� �llapot, kezd� sz�, v�g�llapot '
Public Sub cmd_File_Open_Click()
        Dim i               As Integer                ' index-v�ltoz�
        Dim int_State_Count As Integer                ' �llapotok sz�ma
        Dim str_ABC         As String                 ' Az ABC t�rol�s�hoz
        Dim str_State       As String                 ' Az �llapotok t�rol�s�hoz
        Dim int_State_Begin As String                 ' Kezd� �llapot t�rol�s�hoz
        Dim str_Input       As String                 ' Kezd�sz� t�rol�s�hoz
        Dim str_State_End   As String                 ' V�g�llapot t�rol�s�hoz
        Dim fso             As New FileSystemObject   ' File megnyit�s�hoz
        Dim file_1          As File                   ' Megnyitand� file neve
        Dim ts              As TextStream             ' Sorok beolvas�s�hoz
        Dim str_File_Name   As String                 ' File nev�nek t�rol�s�hoz
            
        str_File_Name = fil_Param.FileName
        Set file_1 = fso.GetFile("C:\turing\" & str_File_Name)
        Set ts = file_1.OpenAsTextStream(ForReading)
        With ts                                       ' sorok beolvas�sa
             str_ABC = .ReadLine
             str_State = .ReadLine
             int_State_Begin = .ReadLine
             str_Input = .ReadLine
             If g_str_Mode = "F" Then
                str_State_End = .ReadLine
             End If
             .Close
        End With
        frm_Abc_Rec.lst_ABC.Clear
        frm_Abc_List.lst_ABC.Clear
        For i = 1 To Len(str_ABC)                     ' ABC lista felt�lt�se
            frm_Abc_Rec.lst_ABC.AddItem Mid(str_ABC, i, 1)
            frm_Abc_List.lst_ABC.AddItem Mid(str_ABC, i, 1)
        Next i
        frm_State_Rec.lst_State.Clear
        frm_State_List.lst_State.Clear
        frm_State_Input.lst_Begin.Clear
        frm_State_End.lst_State_End.Clear
        For i = 1 To Len(str_State)                   ' �llapot lista felt�lt�se
            frm_State_Rec.lst_State.AddItem Mid(str_State, i, 1)
            frm_State_List.lst_State.AddItem Mid(str_State, i, 1)
            frm_State_Input.lst_Begin.AddItem Mid(str_State, i, 1)
            frm_State_End.lst_State_End.AddItem Mid(str_State, i, 1)
        Next i
        int_State_Count = frm_State_Input.lst_Begin.ListCount - 1
        For i = 0 To int_State_Count                  ' Kezd� �llapot be�ll�t�sa
            If frm_State_Input.lst_Begin.List(i) = int_State_Begin Then
               frm_State_Input.lst_Begin.ListIndex = i
               frm_State_Input.lbl_Kezdo.Caption = _
               frm_State_Input.lst_Begin.Text
            End If
        Next i
        g_vnt_Input = int_State_Begin                 ' Kezd� �llapot
        If g_str_Mode = "F" Then
                                                      ' V�g�llapot be�ll�t�a
           For i = 0 To frm_State_End.lst_State_End.ListCount - 1
               If frm_State_End.lst_State_End.List(i) = str_State_End Then
                  frm_State_End.lst_State_End.ListIndex = i
                  frm_State_End.lbl_State_End.Caption = _
                  frm_State_End.lst_State_End.Text
               End If
           Next i
           g_vnt_State_End = str_State_End            ' V�g�llapot
        End If
        frm_Turing_Input.txt_Input.Text = str_Input   ' Input bet�lt�se
        With frm_Turing_Start
             .chk_ABC.Value = 1
             .chk_State.Value = 1
             .chk_Begin.Value = 1
             .chk_Input.Value = 1
             If g_str_Mode = "F" Then
                .chk_End.Value = 1
             Else
                .chk_End.Value = 0
             End If
        End With
        
        With frm_Turing_Start
             .mnu_ABC_List.Enabled = True
             .mnu_ABC_List2.Enabled = True
             .mnu_Head.Enabled = True
             .mnu_Head2.Enabled = True
             .mnu_Input.Enabled = True
             .mnu_Input2.Enabled = True
             .mnu_Input_Pos.Enabled = True
             .mnu_Input_Pos2.Enabled = True
             .mnu_Param_Save.Enabled = True
             .mnu_Param_Save2.Enabled = True
             .tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
             .mnu_State_Begin.Enabled = True
             .mnu_State_Begin2.Enabled = True
             .mnu_State_List.Enabled = True
             .mnu_State_List2.Enabled = True
             .mnu_Reg_Rec.Enabled = True
             .mnu_Reg_Rec2.Enabled = True
             .chk_ABC.Visible = True
             .chk_State.Visible = True
             .chk_Input.Visible = True
             .chk_Begin.Visible = True
             .chk_ABC.Value = 1
             .chk_State.Value = 1
             .chk_Input.Value = 1
             .chk_Begin.Value = 1
             .lbl_ABC.Enabled = True
             .lbl_State.Enabled = True
             .lbl_Input.Enabled = True
             .lbl_Begin.Enabled = True
             .chk_Reg.Visible = True
             .chk_Reg.Value = 0
             .lbl_Reg.Enabled = True
             If g_str_Mode = "F" Then
                .mnu_State_End.Enabled = True
                .mnu_State_End2.Enabled = True
                .chk_End.Visible = True
                .chk_End.Value = 1
                .lbl_End.Enabled = True
             End If
             .msg ("File bet�lt�se befejez�d�tt")
             i = Len(str_File_Name) - 4
             .lbl_File.Caption = Left(str_File_Name, i)
        End With
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                               Az adott �llom�ny megnyit�sa '
Private Sub fil_Param_DblClick()
            cmd_File_Open_Click
            cmd_Close_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                           �rlap aktiv�l�sa '
Private Sub Form_Activate()
        Dim str_File_Name As String                   ' File nev�nek t�rol�s�hoz

        fil_Param.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Param.Pattern = "*.prt"
        Else
           fil_Param.Pattern = "*.prf"
        End If
        str_File_Name = fil_Param.FileName

End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim str_File_Name As String                   ' File nev�nek t�rol�s�hoz

        fil_Param.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Param.Pattern = "*.prt"
        Else
           fil_Param.Pattern = "*.prf"
        End If
        str_File_Name = fil_Param.FileName
End Sub
' ------------------------------------------------------------------------------------------ '
