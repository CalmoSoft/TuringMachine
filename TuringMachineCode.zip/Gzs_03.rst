

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      New Turing-g�p m�k�d�s�nek list�ja.
                      ===================================



 A megadott ABC     : *, /, 0, 1, a, b

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5, 6, 7, 8, 9

 Kezd� �llapot      : 0

 Kezd� sz�          : 110/1001

 Szab�lyok          : 0 , * -> 0 , * , J
                      0 , 0 -> 1 , 0 , J
                      0 , 1 -> 1 , 1 , J


         Az automata konfigur�ci�i  : 

 00. -> **************110/1001********   