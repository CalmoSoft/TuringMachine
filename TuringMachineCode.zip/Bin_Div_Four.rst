

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Bin_Div_Four Turing-g�p m�k�d�s�nek list�ja.
                      ============================================



 A megadott ABC     : *, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, N, Y

 �tmeneti �llapotok : 0, 1, 4, 6, 7, 9, a, N, Y

 Kezd� �llapot      : 0

 Kezd� sz�          : 101100*

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , * -> 1 , * , B
                      1 , 0 -> 4 , * , B
                      1 , 1 -> 9 , * , B
                      4 , * -> 9 , * , J
                      4 , 0 -> 6 , * , B
                      4 , 1 -> 6 , * , B
                      6 , * -> 7 , * , J
                      6 , 0 -> 6 , * , B
                      6 , 1 -> 6 , * , B
                      7 , * -> Y , Y , M
                      9 , * -> a , * , J
                      9 , 0 -> 9 , * , B
                      9 , 1 -> 9 , * , B
                      a , * -> N , N , M


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************101100**********   