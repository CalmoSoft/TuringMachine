

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Mod5 Turing-g�p m�k�d�s�nek list�ja.
                      ====================================



 A megadott ABC     : 0, 1, 2, 3, 4

 �tmeneti �llapotok : 0, 1, 2, 3, 4

 Kezd� �llapot      : 0

 Kezd� sz�          : 2314

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , 0 -> 0 , 0 , J
                      0 , 1 -> 0 , 0 , J
                      0 , 2 -> 0 , 2 , J
                      0 , 3 -> 0 , 3 , J
                      0 , 4 -> 0 , 4 , J
                      1 , 0 -> 0 , 0 , J
                      1 , 1 -> 1 , 1 , J
                      1 , 2 -> 2 , 2 , J
                      1 , 3 -> 3 , 3 , J
                      1 , 4 -> 4 , 4 , J
                      2 , 0 -> 0 , 0 , J
                      2 , 1 -> 2 , 1 , J
                      2 , 2 -> 4 , 2 , J
                      2 , 3 -> 1 , 3 , J
                      2 , 4 -> 3 , 4 , J
                      3 , 0 -> 0 , 0 , J
                      3 , 1 -> 3 , 1 , J
                      3 , 2 -> 1 , 2 , J
                      3 , 3 -> 4 , 3 , J
                      3 , 4 -> 2 , 4 , J
                      4 , 0 -> 0 , 0 , J
                      4 , 1 -> 4 , 1 , J
                      4 , 2 -> 3 , 2 , J
                      4 , 3 -> 2 , 3 , J
                      4 , 4 -> 1 , 4 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************2314************   