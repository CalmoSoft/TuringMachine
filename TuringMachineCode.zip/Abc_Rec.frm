VERSION 5.00
Begin VB.Form frm_Abc_Rec 
   BackColor       =   &H00808000&
   Caption         =   "ABC megad�sa"
   ClientHeight    =   5010
   ClientLeft      =   660
   ClientTop       =   2850
   ClientWidth     =   3645
   ControlBox      =   0   'False
   HelpContextID   =   14
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3645
   Begin VB.TextBox txt_ABC 
      Alignment       =   2  'Center
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   0
      ToolTipText     =   "Az automat ABC-j�nek megad�sa ; sorozat pl. : 0-9 vagy a-z"
      Top             =   1320
      Width           =   855
   End
   Begin VB.ListBox lst_ABC 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2310
      ItemData        =   "Abc_Rec.frx":0000
      Left            =   720
      List            =   "Abc_Rec.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   5
      ToolTipText     =   "Az automata ABC-je"
      Top             =   1920
      Width           =   855
   End
   Begin VB.CommandButton cmd_Add 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "R�gz�t"
      Default         =   -1  'True
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   1
      ToolTipText     =   "Felveszi a megadott elemet a list�ra"
      Top             =   1320
      Width           =   1200
   End
   Begin VB.CommandButton cmd_Remove 
      BackColor       =   &H00C0C0C0&
      Caption         =   "T�r�l"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   2
      ToolTipText     =   "T�rli a kiv�lasztott elemet a list�r�l"
      Top             =   1920
      Width           =   1200
   End
   Begin VB.CommandButton cmd_Clear 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�res"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   3
      ToolTipText     =   "T�rli az �sszes elemet a list�r�l"
      Top             =   2640
      Width           =   1200
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1800
      TabIndex        =   4
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   3360
      Width           =   1200
   End
   Begin VB.Label lbl_ABC_Msg 
      Alignment       =   2  'Center
      BackColor       =   &H000000FF&
      Caption         =   "INPUT-ban szerepel !"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   9
      Top             =   120
      Visible         =   0   'False
      Width           =   2985
   End
   Begin VB.Shape fra_ABC1 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4095
      Left            =   375
      Shape           =   4  'Rounded Rectangle
      Top             =   480
      Width           =   3015
   End
   Begin VB.Label lbl_ABC_Rec 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "ABC megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   720
      TabIndex        =   8
      Top             =   840
      Width           =   2265
   End
   Begin VB.Label lbl_Nr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Nr:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   1800
      TabIndex        =   7
      Top             =   3960
      Width           =   375
   End
   Begin VB.Label lbl_Display 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   2625
      TabIndex        =   6
      ToolTipText     =   "Az ABC elemeinek sz�ma"
      Top             =   3960
      Width           =   360
   End
End
Attribute VB_Name = "frm_Abc_Rec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Abc_Rec       :  Az automata ABC-j�nek megad�sa
'
' ------------------------------------------------------------------------------------------ '
       Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                           �jabb elem hozz�ad�sa az ABC-hez '
Private Sub cmd_Add_Click()
        Dim i          As Integer           ' index-v�ltoz�
        Dim j          As Integer           ' index-v�ltoz�
        Dim int_Unique As Integer           ' Szerepel-e az ABC-list�ban ?
        Dim bln_Series As Boolean           ' Elemek sorozat�nak megad�s�r�l van sz�?
        Dim int_Left   As Integer           ' Sorozat els� eleme
        Dim int_Right  As Integer           ' Sorozat utols� eleme
        
        int_Unique = 0
        txt_ABC.SetFocus
        If Len(txt_ABC.Text) = 1 Then       ' Csak egy karakter szerepelhet
           For i = 0 To lst_ABC.ListCount - 1
               If lst_ABC.List(i) = txt_ABC.Text Then
                  int_Unique = 1
                  Beep
               End If
           Next i
           If int_Unique = 0 Then           ' M�g nem szerepelt a list�n
              lst_ABC.AddItem txt_ABC.Text
              txt_ABC.Text = ""
              txt_ABC.SetFocus
              lbl_Display.Caption = lst_ABC.ListCount   ' Sz�ml�l�
              lbl_ABC_Msg.Visible = False
           Else
              txt_ABC.Text = ""
              txt_ABC.SetFocus
           End If
        Else
           int_Left = Asc(Left(txt_ABC.Text, 1))
           int_Right = Asc(Right(txt_ABC.Text, 1))
           bln_Series = Len(txt_ABC.Text) = 3 And Mid(txt_ABC.Text, 2, 1) = "-" And _
                        int_Left < int_Right
           If bln_Series Then
              For i = int_Left To int_Right
                  int_Unique = 0
                  For j = 0 To lst_ABC.ListCount - 1
                      If lst_ABC.List(j) = Chr(i) Then
                         int_Unique = 1
                      End If
                  Next j
                  If int_Unique = 0 Then
                     lst_ABC.AddItem Chr(i)
                  End If
              Next i
              txt_ABC.Text = ""
              txt_ABC.SetFocus
              lbl_Display.Caption = lst_ABC.ListCount
              lbl_ABC_Msg.Visible = False
           End If
        End If
        cmd_Clear.Enabled = (lst_ABC.ListCount > 0) And (frm_Turing_Start.chk_Input.Value = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                 A teljes ABC lista t�rl�se '
Private Sub cmd_Clear_Click()
        If Del_All() = 0 Then
           lst_ABC.Clear
           cmd_Remove.Enabled = False
           lbl_ABC_Msg.Visible = False
           lbl_Display.Caption = lst_ABC.ListCount
           txt_ABC.SetFocus
           cmd_Remove.Enabled = (lst_ABC.ListCount > 0)
           cmd_Clear.Enabled = (lst_ABC.ListCount > 0)
           lbl_ABC_Msg.Visible = False
        Else
           lbl_ABC_Msg.Visible = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        Dim bln_Cond As Boolean             ' Felt�tel vizsg�lat�hoz
        
        frm_Abc_Rec.Hide
        bln_Cond = (lst_ABC.ListCount > 0)
        If bln_Cond Then
           frm_Turing_Start.chk_ABC.Value = 1
        Else
           frm_Turing_Start.chk_ABC.Value = 0
        End If
        frm_Turing_Start.mnu_ABC_List.Enabled = bln_Cond
        frm_Turing_Start.mnu_ABC_List2.Enabled = bln_Cond
        frm_Turing_Start.mnu_Input.Enabled = bln_Cond
        frm_Turing_Start.mnu_Input2.Enabled = bln_Cond
        frm_Turing_Start.lbl_Input.Enabled = bln_Cond
        frm_Turing_Start.chk_Input.Visible = bln_Cond
        If frm_Turing_Start.chk_State.Value = 1 Then
           frm_Turing_Start.mnu_Reg_Rec.Enabled = bln_Cond
           frm_Turing_Start.mnu_Reg_Rec2.Enabled = bln_Cond
           frm_Turing_Start.chk_Reg.Visible = bln_Cond
           frm_Turing_Start.lbl_Reg.Enabled = bln_Cond
        End If
        If frm_Turing_Start.param() = 1 Then
           frm_Turing_Start.mnu_Param_Save.Enabled = bln_Cond
           frm_Turing_Start.mnu_Param_Save2.Enabled = bln_Cond
           frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = bln_Cond
        End If
        lbl_ABC_Msg.Visible = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                    Elem t�rl�se a list�b�l '
Private Sub cmd_Remove_Click()
        Dim ind As Integer                  'index-mutat�
        
        ind = lst_ABC.ListIndex
        If ind >= 0 And Del_One() = 0 Then
           lst_ABC.RemoveItem ind
           lbl_Display.Caption = lst_ABC.ListCount
           lbl_ABC_Msg.Visible = False
        Else
           lbl_ABC_Msg.Visible = True
           Beep
        End If
        cmd_Remove.Enabled = False
        txt_ABC.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                           �rlap aktiv�l�sa '
Private Sub Form_Activate()
        lbl_Display.Caption = lst_ABC.ListCount
        txt_ABC.SetFocus
        cmd_Clear.Enabled = (lst_ABC.ListCount > 0) And (frm_Turing_Start.chk_Input.Value = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                           �res-e a lista ? '
Private Sub lst_ABC_Click()
        
        lbl_ABC_Msg.Visible = (Del_One() <> 0)
        cmd_Remove.Enabled = (lst_ABC.ListCount > 0) And (Del_One() = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                      Van-e bevihet� adat ? '
Private Sub txt_ABC_Change()
        Dim i          As Integer           ' index-v�ltoz�
        Dim j          As Integer           ' index-v�ltoz�
        Dim int_Unique As Integer           ' Szerepel-e az ABC-list�ban ?
        Dim bln_Series As Boolean           ' Elemek sorozat�nak megad�s�r�l van sz�?
        Dim int_Left   As Integer           ' Sorozat els� eleme
        Dim int_Right  As Integer           ' Sorozat utols� eleme
        
        int_Unique = 0
        If Len(txt_ABC.Text) = 1 Then       ' Csak egy karakter szerepelhet
           For i = 0 To lst_ABC.ListCount - 1
               If lst_ABC.List(i) = txt_ABC.Text Then
                  int_Unique = 1
                  Beep
               End If
           Next i
        Else
           If Len(txt_ABC.Text) = 3 Then
              int_Left = Asc(Left(txt_ABC.Text, 1))
              int_Right = Asc(Right(txt_ABC.Text, 1))
              bln_Series = Mid(txt_ABC.Text, 2, 1) = "-" And int_Left < int_Right
              If bln_Series Then
                 int_Unique = 0
              Else
                 int_Unique = 1
              End If
           Else
              int_Unique = 1
           End If
        End If
        cmd_Add.Enabled = (int_Unique = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                         Ellen�rz�s egy ABC-elem t�rl�s�hez '
Public Function Del_One()
       Dim i              As Integer        ' index-v�ltoz�
       Dim str_Input_Temp As String         ' Kezd�sz� t�rol�s�ra
       Dim int_Good_Del   As Integer        ' Lehet-e t�r�lni a kijel�lt elemet ?
       Dim ind            As Integer        ' index-mutat�
       Dim str_Item       As String         ' Melyik elemr�l van sz� ?
       
       int_Good_Del = 0
       ind = lst_ABC.ListIndex
       str_Item = lst_ABC.List(ind)
       str_Input_Temp = frm_Turing_Input.txt_Input
       If str_Input_Temp <> "" Then
          For i = 1 To Len(str_Input_Temp)
              If Mid(str_Input_Temp, i, 1) = str_Item Then
                 int_Good_Del = 1
              End If
          Next i
       End If
       Del_One = int_Good_Del
End Function
' ------------------------------------------------------------------------------------------ '
'                                                   Ellen�rz�s az �sszes ABC-elem t�rl�s�hez '
Public Function Del_All()
       Dim i              As Integer        ' index-v�ltoz�
       Dim j              As Integer        ' index-v�ltoz�
       Dim str_Input_Temp As String         ' Kezd�sz� t�rol�s�ra
       Dim int_Good_Del   As Integer        ' Lehet-e t�r�lni a kijel�lt elemet ?
       Dim ind            As Integer        ' index-mutat�
       
       int_Good_Del = 0
       ind = lst_ABC.ListCount
       str_Input_Temp = frm_Turing_Input.txt_Input
       If str_Input_Temp <> "" Then
          For i = 1 To Len(str_Input_Temp)
              For j = 1 To ind
                  If Mid(str_Input_Temp, i, 1) = lst_ABC.List(j - 1) Then
                     int_Good_Del = 1
                  End If
              Next j
          Next i
       End If
       Del_All = int_Good_Del
End Function
' ------------------------------------------------------------------------------------------ '

