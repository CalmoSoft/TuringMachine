VERSION 5.00
Begin VB.Form frm_Menu2 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00808000&
   Caption         =   "                                                  Men�rendszer fel�p�t�se - 2."
   ClientHeight    =   8595
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   11880
   ControlBox      =   0   'False
   ForeColor       =   &H80000001&
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8595
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_End 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   9195
      TabIndex        =   12
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   240
      Width           =   1725
   End
   Begin VB.CommandButton cmd_Prev 
      BackColor       =   &H00C0C0C0&
      Caption         =   "El�z�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   7200
      TabIndex        =   11
      ToolTipText     =   "Az el�z� oldal megjelen�t�se"
      Top             =   240
      Width           =   1725
   End
   Begin VB.Line Line25 
      X1              =   2145
      X2              =   2415
      Y1              =   8280
      Y2              =   8280
   End
   Begin VB.Line Line3 
      X1              =   2145
      X2              =   2415
      Y1              =   7800
      Y2              =   7800
   End
   Begin VB.Label Label30 
      BackColor       =   &H00C0C0C0&
      Caption         =   "N�vjegy"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   31
      Top             =   8160
      Width           =   3735
   End
   Begin VB.Label Label29 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Navig�l�s"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   30
      Top             =   7680
      Width           =   3735
   End
   Begin VB.Line Line37 
      X1              =   6665
      X2              =   7200
      Y1              =   3840
      Y2              =   3840
   End
   Begin VB.Label Label28 
      BackColor       =   &H00C0C0C0&
      Caption         =   "El�z� �llapot enged�lyez�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   29
      Top             =   2640
      Width           =   3720
   End
   Begin VB.Line Line36 
      X1              =   2130
      X2              =   2400
      Y1              =   6285
      Y2              =   6285
   End
   Begin VB.Line Line35 
      X1              =   2145
      X2              =   2415
      Y1              =   5820
      Y2              =   5820
   End
   Begin VB.Line Line34 
      X1              =   6665
      X2              =   6665
      Y1              =   5340
      Y2              =   5820
   End
   Begin VB.Line Line33 
      X1              =   6665
      X2              =   7200
      Y1              =   5340
      Y2              =   5340
   End
   Begin VB.Line Line26 
      X1              =   6150
      X2              =   7200
      Y1              =   5820
      Y2              =   5820
   End
   Begin VB.Line Line28 
      X1              =   6665
      X2              =   6665
      Y1              =   6330
      Y2              =   6810
   End
   Begin VB.Line Line27 
      X1              =   6665
      X2              =   7200
      Y1              =   6795
      Y2              =   6795
   End
   Begin VB.Line Line32 
      X1              =   6165
      X2              =   7200
      Y1              =   6315
      Y2              =   6315
   End
   Begin VB.Line Line14 
      X1              =   6665
      X2              =   7200
      Y1              =   4260
      Y2              =   4260
   End
   Begin VB.Line Line5 
      X1              =   6665
      X2              =   7200
      Y1              =   3330
      Y2              =   3330
   End
   Begin VB.Line Line4 
      X1              =   6665
      X2              =   7200
      Y1              =   2850
      Y2              =   2850
   End
   Begin VB.Line Line2 
      X1              =   6665
      X2              =   6665
      Y1              =   2850
      Y2              =   4680
   End
   Begin VB.Label Label27 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szalag h�tt�rsz�ne"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   28
      Top             =   6105
      Width           =   3705
   End
   Begin VB.Label Label26 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szalag jeleinek sz�ne"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   27
      Top             =   6630
      Width           =   3705
   End
   Begin VB.Line Line7 
      X1              =   2130
      X2              =   2130
      Y1              =   4680
      Y2              =   6285
   End
   Begin VB.Label Label23 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Sz�nbe�ll�t�sok"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   26
      Top             =   6105
      Width           =   3735
   End
   Begin VB.Label Label22 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Fejst�lus"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   25
      Top             =   5625
      Width           =   3735
   End
   Begin VB.Label Label21 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Cs�szk�val"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   24
      Top             =   5625
      Width           =   3705
   End
   Begin VB.Label Label3 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szakasszal"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   23
      Top             =   5145
      Width           =   3705
   End
   Begin VB.Line Line13 
      X1              =   1800
      X2              =   2400
      Y1              =   1620
      Y2              =   1620
   End
   Begin VB.Label Label17 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Tartalomjegyz�k"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   22
      Top             =   6720
      Width           =   3720
   End
   Begin VB.Label Label16 
      BackColor       =   &H00C0C0C0&
      Caption         =   "T�rgymutat�"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   21
      Top             =   7200
      Width           =   3735
   End
   Begin VB.Line Line12 
      X1              =   1800
      X2              =   2145
      Y1              =   7185
      Y2              =   7185
   End
   Begin VB.Line Line11 
      X1              =   2145
      X2              =   2415
      Y1              =   6930
      Y2              =   6930
   End
   Begin VB.Line Line10 
      X1              =   2145
      X2              =   2415
      Y1              =   7410
      Y2              =   7410
   End
   Begin VB.Line Line9 
      X1              =   2145
      X2              =   2145
      Y1              =   6945
      Y2              =   8280
   End
   Begin VB.Label Label15 
      BackColor       =   &H00C0C0C0&
      Caption         =   "S�g�"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   225
      TabIndex        =   20
      Top             =   7020
      Width           =   1575
   End
   Begin VB.Label Label14 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Be�ll�t�sok"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   19
      Top             =   4485
      Width           =   1560
   End
   Begin VB.Label Label13 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Folyamatjelz� enged�lyez�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   18
      Top             =   3120
      Width           =   3720
   End
   Begin VB.Label Label6 
      BackColor       =   &H00C0C0C0&
      Caption         =   "V�gtelen ciklusra le�ll"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   17
      Top             =   3600
      Width           =   3720
   End
   Begin VB.Label Label5 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Hangos lej�tsz�s"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   16
      Top             =   4095
      Width           =   3720
   End
   Begin VB.Label Label4 
      BackColor       =   &H00C0C0C0&
      Caption         =   "D�szelemek enged�lyez�se"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   15
      Top             =   4560
      Width           =   3720
   End
   Begin VB.Line Line6 
      X1              =   1755
      X2              =   2415
      Y1              =   4665
      Y2              =   4665
   End
   Begin VB.Line Line1 
      X1              =   2415
      X2              =   7200
      Y1              =   4665
      Y2              =   4665
   End
   Begin VB.Label Label2 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�zemm�d"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   14
      Top             =   1440
      Width           =   1575
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "�zemm�d"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   -4035
      TabIndex        =   13
      Top             =   -4245
      Width           =   1455
   End
   Begin VB.Label Label25 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Turing-g�p"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   10
      Top             =   1185
      Width           =   3720
   End
   Begin VB.Label Label24 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Felismer� automata"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   7200
      TabIndex        =   9
      Top             =   1680
      Width           =   3720
   End
   Begin VB.Line Line31 
      X1              =   2415
      X2              =   7200
      Y1              =   1380
      Y2              =   1380
   End
   Begin VB.Line Line30 
      X1              =   2415
      X2              =   7200
      Y1              =   1845
      Y2              =   1845
   End
   Begin VB.Line Line29 
      X1              =   2415
      X2              =   2415
      Y1              =   1380
      Y2              =   1845
   End
   Begin VB.Line Line24 
      X1              =   2145
      X2              =   2415
      Y1              =   3315
      Y2              =   3315
   End
   Begin VB.Line Line23 
      X1              =   2145
      X2              =   2415
      Y1              =   3795
      Y2              =   3795
   End
   Begin VB.Line Line22 
      X1              =   2130
      X2              =   2400
      Y1              =   4260
      Y2              =   4260
   End
   Begin VB.Line Line21 
      X1              =   2130
      X2              =   2400
      Y1              =   2835
      Y2              =   2835
   End
   Begin VB.Line Line20 
      X1              =   2145
      X2              =   2415
      Y1              =   2355
      Y2              =   2355
   End
   Begin VB.Line Line17 
      X1              =   1785
      X2              =   2130
      Y1              =   3315
      Y2              =   3315
   End
   Begin VB.Line Line15 
      X1              =   2130
      X2              =   2130
      Y1              =   2355
      Y2              =   4275
   End
   Begin VB.Label Label20 
      BackColor       =   &H00C0C0C0&
      Caption         =   "�j szimul�ci�"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   8
      Top             =   4095
      Width           =   3735
   End
   Begin VB.Label Label19 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szimul�ci� v�geredm�nye"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   7
      Top             =   3615
      Width           =   3735
   End
   Begin VB.Label Label18 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szimul�ci� v�grehajt�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   6
      Top             =   3135
      Width           =   3735
   End
   Begin VB.Label Label12 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szimul�ci� l�p�senk�nt"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   5
      Top             =   2655
      Width           =   3735
   End
   Begin VB.Label Label11 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szimul�ci� kezd� �llapota"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2415
      TabIndex        =   4
      Top             =   2175
      Width           =   3735
   End
   Begin VB.Label Label10 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szimul�ci�"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   3
      Top             =   3135
      Width           =   1575
   End
   Begin VB.Line Line19 
      X1              =   2160
      X2              =   2160
      Y1              =   420
      Y2              =   885
   End
   Begin VB.Line Line18 
      X1              =   2160
      X2              =   2430
      Y1              =   885
      Y2              =   885
   End
   Begin VB.Line Line16 
      X1              =   2160
      X2              =   2430
      Y1              =   405
      Y2              =   405
   End
   Begin VB.Line Line8 
      X1              =   1815
      X2              =   2160
      Y1              =   660
      Y2              =   660
   End
   Begin VB.Label Label9 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szab�lyok list�ja"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   2
      Top             =   720
      Width           =   3735
   End
   Begin VB.Label Label8 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szab�lyok megad�sa"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   2430
      TabIndex        =   1
      Top             =   225
      Width           =   3735
   End
   Begin VB.Label Label7 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Szab�lyok"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   11.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   375
      Left            =   240
      TabIndex        =   0
      Top             =   480
      Width           =   1575
   End
End
Attribute VB_Name = "frm_Menu2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Menu2         :  Megjelen�ti a men�rendszer 2. r�sz�t
'
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_End_Click()
        Unload frm_Menu2
        Unload frm_Menu1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             El�z� men�-ablak megjelen�t�se '
Private Sub cmd_Prev_Click()
        frm_Menu1.Show
End Sub
' ------------------------------------------------------------------------------------------ '
