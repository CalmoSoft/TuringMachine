VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frm_Result 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00808000&
   Caption         =   "V�geredm�ny"
   ClientHeight    =   8310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_List 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Lista"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5760
      TabIndex        =   21
      ToolTipText     =   "A v�geredm�ny teljes k�perny�s list�ja"
      Top             =   6840
      Width           =   5775
   End
   Begin VB.CommandButton cmd_Save 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Ment�s"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   360
      TabIndex        =   19
      ToolTipText     =   "A v�geredm�ny elment�se �llom�nyba"
      Top             =   6840
      Width           =   3855
   End
   Begin VB.CommandButton cmd_Exit 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4455
      TabIndex        =   0
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   6840
      Width           =   1095
   End
   Begin VB.ListBox lst_State 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   3855
      IntegralHeight  =   0   'False
      ItemData        =   "Result.frx":0000
      Left            =   1080
      List            =   "Result.frx":0002
      TabIndex        =   15
      ToolTipText     =   "Az automata �llapotai"
      Top             =   1440
      Width           =   735
   End
   Begin VB.ListBox lst_Result_Window 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   3180
      ItemData        =   "Result.frx":0004
      Left            =   4455
      List            =   "Result.frx":0006
      TabIndex        =   6
      TabStop         =   0   'False
      ToolTipText     =   $"Result.frx":0008
      Top             =   1680
      Width           =   7095
   End
   Begin VB.ListBox lst_Reg_List 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   3615
      IntegralHeight  =   0   'False
      ItemData        =   "Result.frx":00A2
      Left            =   1920
      List            =   "Result.frx":00A4
      TabIndex        =   4
      ToolTipText     =   "Az automata szab�lyai"
      Top             =   1680
      Width           =   2295
   End
   Begin VB.ListBox lst_ABC 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   3855
      IntegralHeight  =   0   'False
      ItemData        =   "Result.frx":00A6
      Left            =   360
      List            =   "Result.frx":00A8
      TabIndex        =   1
      ToolTipText     =   "Az automata ABC-je"
      Top             =   1440
      Width           =   615
   End
   Begin MSComctlLib.Slider sld_Fej_Result 
      Height          =   480
      Left            =   5250
      TabIndex        =   31
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   4815
      Width           =   3495
      _ExtentX        =   6165
      _ExtentY        =   847
      _Version        =   393216
      BorderStyle     =   1
      Min             =   1
      Max             =   30
      SelStart        =   1
      TickStyle       =   1
      Value           =   1
      TextPosition    =   1
   End
   Begin VB.Line Line3 
      BorderWidth     =   2
      X1              =   4470
      X2              =   4470
      Y1              =   4830
      Y2              =   5280
   End
   Begin VB.Line Line2 
      BorderWidth     =   2
      X1              =   11535
      X2              =   11535
      Y1              =   4830
      Y2              =   5280
   End
   Begin VB.Line Line1 
      BorderWidth     =   2
      X1              =   4470
      X2              =   11520
      Y1              =   5280
      Y2              =   5280
   End
   Begin VB.Label lbl_Big 
      Alignment       =   2  'Center
      BackColor       =   &H00808080&
      Caption         =   "Nagy�t�s"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   18
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   435
      Left            =   8730
      TabIndex        =   33
      ToolTipText     =   "Az eredm�nyablak nagy�t�sa"
      Top             =   4860
      Width           =   2820
   End
   Begin VB.Label Label26 
      Alignment       =   2  'Center
      BackColor       =   &H00808080&
      Caption         =   "FEJ"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   20.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   435
      Left            =   4470
      TabIndex        =   32
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   4845
      Width           =   795
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   7575
      Left            =   195
      Shape           =   4  'Rounded Rectangle
      Top             =   360
      Width           =   11655
   End
   Begin VB.Label lbl_Konf_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   10785
      TabIndex        =   30
      ToolTipText     =   "Konfigur�ci�k sz�ma"
      Top             =   5295
      Width           =   735
   End
   Begin VB.Label Label8 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   4440
      TabIndex        =   29
      Top             =   5295
      Width           =   375
   End
   Begin VB.Label Label9 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   1080
      TabIndex        =   28
      Top             =   5280
      Width           =   255
   End
   Begin VB.Label Label7 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   360
      TabIndex        =   27
      Top             =   5280
      Width           =   375
   End
   Begin VB.Label Label6 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   1920
      TabIndex        =   26
      Top             =   5280
      Width           =   375
   End
   Begin VB.Label lbl_Reg_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   1920
      TabIndex        =   25
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot"
      Top             =   1440
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.Label lbl_Konf_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " Nr.           Konfigur�ci�k :            A1  BE   A2  F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   4440
      TabIndex        =   24
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, F = Fej pozici�ja"
      Top             =   1440
      Visible         =   0   'False
      Width           =   7095
   End
   Begin VB.Label lbl_Konf_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   " Nr.           Konfigur�ci�k :            A1  BE   A2  KI  M   F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   4440
      TabIndex        =   23
      ToolTipText     =   $"Result.frx":00AA
      Top             =   1440
      Width           =   7095
   End
   Begin VB.Label lbl_Reg_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2  KI  M"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   1920
      TabIndex        =   22
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, KI = Kimen� jel, M = Fejmozg�s (B=Balra, J=Jobbra, M=Marad)"
      Top             =   1440
      Width           =   2295
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Az automata konfigur�ci�i"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   4440
      TabIndex        =   20
      Top             =   1080
      Width           =   7095
   End
   Begin VB.Label lbl_Reg_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   3480
      TabIndex        =   18
      ToolTipText     =   "Az automata szab�lyainak sz�ma"
      Top             =   5280
      Width           =   735
   End
   Begin VB.Label lbl_State_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   1440
      TabIndex        =   17
      ToolTipText     =   "�llapotok sz�ma"
      Top             =   5280
      Width           =   375
   End
   Begin VB.Label lbl_ABC_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   480
      TabIndex        =   16
      ToolTipText     =   "ABC elemeinek sz�ma"
      Top             =   5280
      Width           =   495
   End
   Begin VB.Label lbl_Veg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   1920
      TabIndex        =   14
      ToolTipText     =   "Az automata v�g�llapota"
      Top             =   6240
      Width           =   2295
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "V�g�llapot"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   360
      TabIndex        =   13
      Top             =   6240
      Width           =   1455
   End
   Begin VB.Label lbl_Output 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   5760
      TabIndex        =   12
      ToolTipText     =   "Az automata outputja (v�geredm�ny)"
      Top             =   6240
      Width           =   5775
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Kimenet :"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   4440
      TabIndex        =   11
      Top             =   6240
      Width           =   1095
   End
   Begin VB.Label lbl_Input 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   5760
      TabIndex        =   10
      ToolTipText     =   "Az automata inputja (kezd�sz�)"
      Top             =   5640
      Width           =   5775
      WordWrap        =   -1  'True
   End
   Begin VB.Label lbl_Kezdo 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   1920
      TabIndex        =   9
      ToolTipText     =   "Az automata kezd��llapota"
      Top             =   5640
      Width           =   2295
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Bemenet :"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   4440
      TabIndex        =   8
      Top             =   5640
      Width           =   1095
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Kezd��llapot"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   360
      TabIndex        =   7
      Top             =   5640
      Width           =   1455
   End
   Begin VB.Label lbl_Szab_List 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Szab�lyok"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   1920
      TabIndex        =   5
      Top             =   1080
      Width           =   2295
   End
   Begin VB.Label lbl_State2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "�llapot"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   1080
      TabIndex        =   3
      Top             =   1080
      Width           =   735
   End
   Begin VB.Label lbl_ABC2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "ABC"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   360
      TabIndex        =   2
      Top             =   1080
      Width           =   615
   End
   Begin VB.Menu mnu_Save 
      Caption         =   "&Ment�s"
   End
   Begin VB.Menu mnu_List 
      Caption         =   "&Lista"
   End
   Begin VB.Menu mnu_Exit 
      Caption         =   "&Kil�p"
   End
   Begin VB.Menu mnu_Sum 
      Caption         =   "�sszes"
      Visible         =   0   'False
      Begin VB.Menu mnu_Save2 
         Caption         =   "Ment�s"
      End
      Begin VB.Menu mnu_List2 
         Caption         =   "Lista"
      End
      Begin VB.Menu mnu_Exit2 
         Caption         =   "Kil�p"
      End
   End
End
Attribute VB_Name = "frm_Result"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Result        :  Az automata szimul�ci�j�nak v�geredm�nye
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Exit_Click()
        frm_Turing_Start.lst_Result_Window.ListIndex = lst_Result_Window.ListIndex
        frm_Turing_Start.lbl_Msg = ""
        frm_Result.Hide
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Teljes oldalas megjelen�t�s '
Public Sub cmd_List_Click()
        Dim FileName      As String         ' A file neve
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz
        Dim str_Buffer1   As String         ' Sorok beolvas�s�hoz
        Dim str_Buffer2   As String         ' File t�rol�s�hoz
        Dim str_Ext       As String         ' File kiterjeszt�se
        Dim FileNum       As Integer        ' File sorsz�ma
        

        If g_str_Mode = "T" Then
           str_Ext = ".rst"
        Else
           str_Ext = ".rsf"
        End If
        If frm_Turing_Start.lbl_File = "" Or frm_Turing_Start.lbl_File = "New" Then
           frm_Turing_Start.lbl_File = "New"
           frm_Result.Hide
           str_File_Name = "New"
           frm_Param_Save.txt_Param.Text = str_File_Name
           frm_Param_Save.cmd_File_Save_Click
           frm_Result.Hide
           frm_Reg_Rec.txt_File_Save.Text = str_File_Name
           frm_Turing_Start.File_Save_Reg
           frm_Result_Save.txt_Param = str_File_Name
           frm_Result_Save.cmd_File_Save_Click
        End If
        frm_Result_List.Caption = frm_Result_List.Caption & " - " & frm_Turing_Start.lbl_File & str_Ext
        Me.Hide
        frm_Result_Save.cmd_File_Save_Click
        Me.Show
        If g_str_Mode = "T" Then
           FileName = "C:\turing\" & frm_Turing_Start.lbl_File & ".rst"
        Else
           FileName = "C:\turing\" & frm_Turing_Start.lbl_File & ".rsf"
        End If
        FileNum = FreeFile
        Open FileName For Input As FileNum
        Do While Not EOF(FileNum)
           Line Input #FileNum, str_Buffer1
           str_Buffer2 = str_Buffer2 & str_Buffer1 & vbCrLf
        Loop
        Close FileNum
        frm_Result_List.txt_Result_List = str_Buffer2
        frm_Result_List.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                         Eredm�nyek ment�se '
Private Sub cmd_Save_Click()
        frm_Result_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                    Szimul�l�s v�geredm�nye '
Public Sub Form_Activate()
        Dim i             As Integer        ' index-v�ltoz�
        Dim j             As Integer        ' index-v�ltoz�
        Dim int_From_Here As Integer        ' Kimenet meg�llap�t�s�hoz kezd�poz�ci�
        Dim mettol        As Integer        ' Kimenet meg�llap�t�s�hoz szalagpoz�ci�
        Dim meddig        As Integer        ' Kimenet meg�llap�t�s�hoz szalagpoz�ci�
        Dim str_Ext       As String         ' File kiterjeszt�se
        Dim str_Last      As String         ' Utols� konfigur�ci�
        Dim str_Good      As String         ' Utols� konfigur�ci� kimenet r�sze
        
        If g_str_Mode = "T" Then
           str_Ext = ".rst"
           lbl_Reg_Turing.Visible = True
           lbl_Reg_Accept.Visible = False
           lbl_Konf_Turing.Visible = True
           lbl_Konf_Accept.Visible = False
           lst_Reg_List.ToolTipText = lbl_Reg_Turing.ToolTipText
           lst_Result_Window.ToolTipText = lbl_Konf_Turing.ToolTipText
        Else
           str_Ext = ".rsf"
           lbl_Reg_Turing.Visible = False
           lbl_Reg_Accept.Visible = True
           lbl_Konf_Turing.Visible = False
           lbl_Konf_Accept.Visible = True
           lst_Reg_List.ToolTipText = lbl_Reg_Accept.ToolTipText
           lst_Result_Window.ToolTipText = lbl_Konf_Accept.ToolTipText
        End If
        If frm_Turing_Start.lbl_File = "" Then
           frm_Turing_Start.lbl_File = "New"
        End If
        frm_Result.Caption = Space(47) & "V�geredm�ny" & " - " & _
                             frm_Turing_Start.lbl_File & str_Ext
        lst_ABC.Clear
        lst_State.Clear
        lst_Reg_List.Clear
        lst_Result_Window.Clear
        lbl_Kezdo = ""
        lbl_Input = ""
        lbl_Veg = ""
        lbl_Output = ""
        j = frm_Abc_Rec.lst_ABC.ListCount
        For i = 1 To j
            lst_ABC.AddItem frm_Abc_Rec.lst_ABC.List(i - 1)
        Next i
        lbl_ABC_Nr.Caption = j
        j = frm_State_Rec.lst_State.ListCount
        For i = 1 To j
            lst_State.AddItem frm_State_Rec.lst_State.List(i - 1)
        Next i
        lbl_State_Nr.Caption = j
        j = frm_Reg_Rec.lst_Reg.ListCount
        For i = 1 To j
            lst_Reg_List.AddItem Left(frm_Reg_Rec.lst_Reg.List(i - 1), 18)
        Next i
        lbl_Reg_Nr.Caption = j
        j = frm_Turing_Start.lst_Result_Window.ListCount
        For i = 1 To j
            lst_Result_Window.AddItem _
            frm_Turing_Start.lst_Result_Window.List(i - 1)
        Next i
        lbl_Konf_Nr.Caption = j - 1
        lbl_Kezdo = g_vnt_Input
        lbl_Input = frm_Turing_Input.txt_Input
        lbl_Veg = Chr(g_int_Prev(3))
        str_Good = ""
        j = frm_Turing_Start.lst_Result_Window.ListCount - 1
        str_Last = frm_Turing_Start.lst_Result_Window.List(j)
        If g_str_Mode = "T" Then
           mettol = 10
           meddig = 39
           For i = mettol To meddig
               If Mid(str_Last, i, 1) <> "*" Then
                  int_From_Here = i
                  Exit For
               End If
           Next i
           For i = int_From_Here To meddig
               If Mid(str_Last, i, 1) <> "*" Then
                  str_Good = str_Good + Mid(str_Last, i, 1)
               Else
                 Exit For
               End If
           Next i
        Else
           If g_bln_Accept = True Then
              str_Good = "Felismerte"
           Else
              str_Good = "Nem ismerte fel"
           End If
        End If
        lbl_Output = str_Good
        lst_Result_Window.ListIndex = frm_Turing_Start.lst_Result_Window.ListIndex
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim str_Ext As String               ' A file kiterjeszt�se
         
        If g_str_Mode = "T" Then
           str_Ext = ".rst"
           lbl_Reg_Turing.Visible = True
           lbl_Reg_Accept.Visible = False
           lbl_Konf_Turing.Visible = True
           lbl_Konf_Accept.Visible = False
           lst_Reg_List.ToolTipText = lbl_Reg_Turing.ToolTipText
           lst_Result_Window.ToolTipText = lbl_Konf_Turing.ToolTipText
        Else
           str_Ext = ".rsf"
           lbl_Reg_Turing.Visible = False
           lbl_Reg_Accept.Visible = True
           lbl_Konf_Turing.Visible = False
           lbl_Konf_Accept.Visible = True
           lst_Reg_List.ToolTipText = lbl_Reg_Accept.ToolTipText
           lst_Result_Window.ToolTipText = lbl_Konf_Accept.ToolTipText
        End If
        If frm_Turing_Start.lbl_File = "" Then
           frm_Turing_Start.lbl_File = "New"
        End If
        frm_Result.Caption = "V�geredm�ny" & " - " & frm_Turing_Start.lbl_File & str_Ext
        sld_Fej_Result.Value = 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                   Helyi men� megjelen�t�se '
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, x As Single, _
                         y As Single)
        If Button = 2 Then
           PopupMenu mnu_Sum
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                    Eredm�nyablak nagy�t�sa '
Private Sub lbl_Big_Click()
        g_int_Row_Big = lst_Result_Window.ListIndex
        Me.Hide
        frm_Head.Show 1
        Me.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 A kijel�lt konfigur�ci� fej�ll�s�t mutatja '
Private Sub lst_Result_Window_Click()
        Dim i       As Integer              ' index-v�ltoz�
        Dim j       As Integer              ' index-v�ltoz�
        Dim k       As Integer              ' index-v�ltoz�
        Dim m       As Integer              ' index-v�ltoz�
        Dim int_Pos As Integer              ' A fej�ll�s poz�ci�j�nak helye
            
            If g_str_Mode = "T" Then
               int_Pos = 63
            Else
               int_Pos = 55
            End If
            j = lst_Result_Window.ListIndex
            m = lst_Result_Window.ListCount - 1
            If j <> m Then
               k = Mid(lst_Result_Window.List(j), int_Pos, 2)
               sld_Fej_Result.Value = k
            End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit_Click()
            cmd_Exit_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit2_Click()
        mnu_Exit_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Teljes oldalas megjelen�t�s '
Private Sub mnu_List_Click()
        cmd_List_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Teljes oldalas megjelen�t�s '
Private Sub mnu_List2_Click()
        mnu_List_Click
End Sub

' ------------------------------------------------------------------------------------------ '
'                                                                         Eredm�nyek ment�se '
Private Sub mnu_Save_Click()
        frm_Result_Save.Show 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                         Eredm�nyek ment�se '
Private Sub mnu_Save2_Click()
        mnu_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
