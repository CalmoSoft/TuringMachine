

2002.08.04. 17:29:59


 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


 Mott�              : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


 Funkci�            : 'Matek_099' Turing-g�p m�k�d�s�nek list�ja.
                      =========================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : 0, 1, 2

 Kezd� �llapot      : 0

 Kezd� sz�          : 11101

 V�gs� �llapot      : 

 Output             : 1111

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , * -> 0 , * , M
                      0 , 0 -> 1 , 1 , M
                      0 , 1 -> 0 , 1 , J
                      1 , * -> 2 , * , B
                      1 , 0 -> 1 , 0 , M
                      1 , 1 -> 1 , 1 , J
                      2 , 1 -> 2 , * , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************11101***********   0 , 1 -> 0 , 1   J  15
 002. -> **************11101***********   0 , 1 -> 0 , 1   J  16
 003. -> **************11101***********   0 , 1 -> 0 , 1   J  17
 004. -> **************11101***********   0 , 0 -> 1 , 1   M  18
 005. -> **************11111***********   1 , 1 -> 1 , 1   J  18
 006. -> **************11111***********   1 , 1 -> 1 , 1   J  19
 007. -> **************11111***********   1 , * -> 2 , *   B  20
 008. -> **************11111***********   2 , 1 -> 2 , *   J  19
 END. -> **************1111************         V�GE !