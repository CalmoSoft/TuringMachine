

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Penrose_059 Turing-g�p m�k�d�s�nek list�ja.
                      ===========================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : !, 0, 1

 Kezd� �llapot      : 0

 Kezd� sz�          : 1111

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , 0 -> 0 , 0 , J
                      0 , 1 -> 1 , 1 , J
                      1 , * -> ! , 1 , J
                      1 , 1 -> 1 , 1 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************1111************   