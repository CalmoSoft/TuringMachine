

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Disk_01_1 Turing-g�p m�k�d�s�nek list�ja.
                      =========================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : 0, 1, 2, 3

 Kezd� �llapot      : 1

 Kezd� sz�          : 1110011

 V�gs� �llapot      : 

 Output             : 


 Szab�lyok          : A1  BE   A2  KI  M

                      1 , 0 -> 2 , 0 , J
                      1 , 1 -> 1 , 1 , J
                      2 , 0 -> 3 , 0 , J
                      2 , 1 -> 1 , 1 , B
                      3 , 0 -> 0 , 0 , M
                      3 , 1 -> 2 , 1 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

 001. -> **************1110011*********   