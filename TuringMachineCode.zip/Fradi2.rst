

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                          sz�m�t�g�pes szimul�ci�ja
                            Visual Basic 6.0-ban


 D�tum, id�         : 2002.08.10. 9:12:02


 Mott�              : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


 Funkci�            : 'Fradi2' Turing-g�p m�k�d�s�nek list�ja.
                      ======================================



 A megadott ABC     : A, D, F, I, R

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5, 6, 7, 8, 9

 Kezd� �llapot      : 0

 Kezd� sz�          : FRADI

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�poz�ci�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , A -> 0 , A , J
                      0 , D -> 0 , D , J
                      0 , F -> 0 , F , J
                      0 , I -> 1 , I , B
                      0 , R -> 0 , R , J
                      1 , A -> 1 , A , B
                      1 , D -> 1 , D , B
                      1 , R -> 0 , R , B


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************FRADI***********   