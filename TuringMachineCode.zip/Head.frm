VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frm_Head 
   BackColor       =   &H00808000&
   Caption         =   "Konfigur�ci�k"
   ClientHeight    =   8310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   11880
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_End 
      Caption         =   "V�ge"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   8775
      TabIndex        =   8
      Top             =   6990
      Width           =   1305
   End
   Begin VB.TextBox txt_Step 
      Alignment       =   2  'Center
      BeginProperty DataFormat 
         Type            =   1
         Format          =   "#�##0"
         HaveTrueFalseNull=   0
         FirstDayOfWeek  =   0
         FirstWeekOfYear =   0
         LCID            =   1038
         SubFormatType   =   1
      EndProperty
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   7200
      TabIndex        =   7
      ToolTipText     =   "A megadott sorsz�m� konfigur�ci�ra ugrik"
      Top             =   6975
      Visible         =   0   'False
      Width           =   1305
   End
   Begin VB.ListBox lst_Result_Window 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      CausesValidation=   0   'False
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   4755
      ItemData        =   "Head.frx":0000
      Left            =   480
      List            =   "Head.frx":0002
      TabIndex        =   1
      TabStop         =   0   'False
      ToolTipText     =   $"Head.frx":0004
      Top             =   1320
      Width           =   11025
   End
   Begin MSComctlLib.Slider sld_Fej 
      Height          =   630
      Left            =   1875
      TabIndex        =   0
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   6060
      Width           =   5205
      _ExtentX        =   9181
      _ExtentY        =   1111
      _Version        =   393216
      BorderStyle     =   1
      Min             =   1
      Max             =   30
      SelStart        =   1
      TickStyle       =   1
      Value           =   1
      TextPosition    =   1
   End
   Begin VB.Label lbl_Head_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   285
      Left            =   11055
      TabIndex        =   11
      ToolTipText     =   "�llapotok sz�ma"
      Top             =   645
      Width           =   375
   End
   Begin VB.Label lbl_Window 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      ForeColor       =   &H00000000&
      Height          =   210
      Left            =   510
      TabIndex        =   10
      Top             =   660
      Width           =   375
   End
   Begin VB.Label lbl_Error 
      Alignment       =   2  'Center
      BackColor       =   &H000000FF&
      Caption         =   "A megadott �rt�k kisebb vagy nagyobb  a konfigur�ci�k sz�m�n�l !"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   345
      Left            =   1845
      TabIndex        =   9
      Top             =   7590
      Visible         =   0   'False
      Width           =   8250
   End
   Begin VB.Shape shp_Head 
      BorderWidth     =   2
      Height          =   7935
      Left            =   120
      Shape           =   4  'Rounded Rectangle
      Top             =   180
      Width           =   11655
   End
   Begin VB.Label lbl_Ugras 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "Konfigur�ci� sorsz�ma :"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   345
      Left            =   1830
      TabIndex        =   6
      Top             =   6990
      Visible         =   0   'False
      Width           =   5205
   End
   Begin VB.Label lbl_Konf_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "  Nr.           Konfigur�ci�k :           A1  BE   A2  KI  M   F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   480
      TabIndex        =   5
      ToolTipText     =   $"Head.frx":0093
      Top             =   960
      Width           =   11025
   End
   Begin VB.Label lbl_Konf_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00800080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "  Nr.           Konfigur�ci�k :           A1  BE   A2  F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   360
      Left            =   480
      TabIndex        =   4
      ToolTipText     =   " A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, F = Fej pozici�ja "
      Top             =   960
      Width           =   11025
   End
   Begin VB.Label lbl_Head 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "FEJ"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   27.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   465
      TabIndex        =   3
      ToolTipText     =   "A kijel�lt konfigur�ci� fejpozici�ja"
      Top             =   6060
      Width           =   1425
   End
   Begin VB.Label lbl_Small 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Kicsiny�t�s"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   27.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   7065
      TabIndex        =   2
      ToolTipText     =   "Az eredm�nyablak kicsiny�t�se"
      Top             =   6060
      Width           =   4425
   End
   Begin VB.Menu mnu_Step 
      Caption         =   "&Ugr�s"
   End
   Begin VB.Menu mnu_Exit 
      Caption         =   "&Kil�p"
   End
   Begin VB.Menu mnu_Sum 
      Caption         =   "�sszes"
      Visible         =   0   'False
      Begin VB.Menu mnu_Step2 
         Caption         =   "Ugr�s"
      End
      Begin VB.Menu mnu_Exit2 
         Caption         =   "Kil�p"
      End
   End
End
Attribute VB_Name = "frm_Head"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Head          :  Az eredm�nyablak nagy�t�sa
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_End_Click()
        lbl_Ugras.Visible = False
        txt_Step.Visible = False
        cmd_End.Visible = False
        lbl_Error.Visible = False
        lst_Result_Window.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
        Dim k As Integer                    ' index-v�ltoz�
        Dim m As Integer                    ' index-v�ltoz�
        Dim n As Integer                    ' index-v�ltoz�
        
        lbl_Konf_Turing.Visible = (g_str_Mode = "T")
        lbl_Konf_Accept.Visible = (g_str_Mode = "F")
        lbl_Ugras.Visible = False
        txt_Step.Visible = False
        cmd_End.Visible = False
        j = frm_Turing_Start.lst_Result_Window.ListCount
        lst_Result_Window.Clear
        For i = 1 To j
            lst_Result_Window.AddItem frm_Turing_Start.lst_Result_Window.List(i - 1)
        Next i
        
        n = lst_Result_Window.ListCount
        
        If Len(lst_Result_Window.List(n - 1)) = 0 Then
           lst_Result_Window.RemoveItem n - 1
           frm_Turing_Start.msg ("�res")
        End If
        
        If n < 15 Then
           k = Int((n + 1) * (lst_Result_Window.Height / 15))
           m = lst_Result_Window.Top + k
           lst_Result_Window.Height = k
           lbl_Head.Top = lst_Result_Window.Top + lst_Result_Window.Height - 15
           sld_Fej.Top = lst_Result_Window.Top + lst_Result_Window.Height - 15
           lbl_Small.Top = lst_Result_Window.Top + lst_Result_Window.Height - 15
        Else
           lst_Result_Window.Height = 4755
           lbl_Head.Top = 6060
           sld_Fej.Top = 6060
           lbl_Small.Top = 6060
        End If
        m = sld_Fej.Top + 930
        lbl_Ugras.Top = m
        txt_Step.Top = m
        cmd_End.Top = m
        lbl_Error.Top = sld_Fej.Top + 1515
        shp_Head.Height = sld_Fej.Top + 1875
        lst_Result_Window.ListIndex = g_int_Row_Big
        lbl_Head_Nr = lst_Result_Window.ListCount - 1
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                   Helyi men� megjelen�t�se '
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, x As Single, _
                         y As Single)
        If Button = 2 Then
           PopupMenu mnu_Sum
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        Ugr�s megjelen�t�se '
Private Sub lbl_Head_Click()
        mnu_Step_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                   Eredm�nyablak kicsiny�t�se (visszal�p�s) '
Public Sub lbl_Small_Click()
       Dim int_Row_Small As Integer                ' Kicsiny�t�sn�l melyik sor van kijel�lve '

            int_Row_Small = lst_Result_Window.ListIndex
            frm_Turing_Start.lst_Result_Window.ListIndex = int_Row_Small
            Unload frm_Head
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                 A kijel�lt konfigur�ci� fej�ll�s�t mutatja '
Private Sub lst_Result_Window_Click()
        Dim i       As Integer              ' index-v�ltoz�
        Dim j       As Integer              ' index-v�ltoz�
        Dim k       As Integer              ' index-v�ltoz�
        Dim m       As Integer              ' index-v�ltoz�
        Dim int_Pos As Integer              ' Hol kezd�dik a fej�ll�s ?
            
            If g_str_Mode = "T" Then
               int_Pos = 63
            Else
               int_Pos = 55
            End If
            j = lst_Result_Window.ListIndex
            m = lst_Result_Window.ListCount - 1
            If j <> m Then
               k = Mid(lst_Result_Window.List(j), int_Pos, 2)
               sld_Fej.Value = k
            End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit_Click()
        Unload frm_Head
        frm_Turing_Start.lst_Result_Window.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit2_Click()
        mnu_Exit_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Ugr�s az adott sorsz�m� konfigur�ci�ra '
Private Sub mnu_Step_Click()
        lbl_Ugras.Visible = True
        txt_Step.Visible = True
        cmd_End.Visible = True
        txt_Step.SetFocus
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     Ugr�s az adott sorsz�m� konfigur�ci�ra '
Private Sub mnu_Step2_Click()
        mnu_Step_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                Ellen�rzi, hogy helyes-e az adott sorsz�m ? '
Private Sub txt_Step_Change()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
        
        j = lst_Result_Window.ListCount
        If Val(txt_Step) > 0 And Val(txt_Step) <= j Then
           lst_Result_Window.ListIndex = Val(txt_Step) - 1
           lst_Result_Window.SetFocus
           txt_Step.SetFocus
           lbl_Error.Visible = False
        Else
           lbl_Error.Visible = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
