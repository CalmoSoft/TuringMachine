

 SimTuring 1.0 - Turing-g�p �s felismer� automat�k
                 sz�m�t�g�pes szimul�ci�ja
                 Visual Basic 6.0-ban


 Birk_080 Turing-automata m�k�d�s�nek nyomtat�sa.



 A megadott ABC     : *, 0, 1, D, E

 �tmeneti �llapotok : 0, 1, 2

 Kezd� �llapot      : 0

 Kezd� sz�          : 101010101010

 Szab�lyok          : 0 , * -> 0 , * , Jobbra
                      0 , 0 -> 1 , 0 , Jobbra, 
                      0 , 1 -> 2 , 1 , Jobbra, 
                      1 , * -> 1 , E , Marad, 
                      1 , 0 -> 1 , 0 , Jobbra, 
                      1 , 1 -> 2 , 1 , Jobbra, 
                      2 , * -> 2 , D , Marad, 
                      2 , 0 -> 2 , 0 , Jobbra, 
                      2 , 1 -> 1 , 1 , Jobbra, 


         Az automata konfigur�ci�i  : 

 00. -> **************101010101010****   