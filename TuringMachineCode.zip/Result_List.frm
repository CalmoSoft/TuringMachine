VERSION 5.00
Begin VB.Form frm_Result_List 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00800080&
   Caption         =   "                                                V�geredm�ny megtekint�se"
   ClientHeight    =   8310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   11880
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "Courier New"
      Size            =   12
      Charset         =   238
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00FFFFFF&
   HelpContextID   =   31
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   Begin VB.TextBox txt_Result_List 
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   8055
      Left            =   105
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      ToolTipText     =   "A teljes feladat adatai �s a v�geredm�nye"
      Top             =   120
      Width           =   11655
   End
   Begin VB.Menu mnu_Exit 
      Caption         =   "&Kil�p"
   End
End
Attribute VB_Name = "frm_Result_List"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Result_List   :  Az eredm�nyek megjelen�t�se
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                           �rlap aktiv�l�sa '
Private Sub Form_Activate()
        Dim str_Ext As String               ' File kiterjeszt�se
        
        If g_str_Mode = "T" Then
           str_Ext = ".rst"
        Else
           str_Ext = ".rsf"
        End If
        
        If frm_Turing_Start.lbl_File = "" Then
           frm_Turing_Start.lbl_File = "New"
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim str_Ext As String

        If g_str_Mode = "T" Then
           str_Ext = ".rst"
        Else
           str_Ext = ".rsf"
        End If
        
        If frm_Turing_Start.lbl_File = "" Then
           frm_Turing_Start.lbl_File = "New"
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit_Click()
            Unload frm_Result_List
End Sub
' ------------------------------------------------------------------------------------------ '
