Attribute VB_Name = "Turing"
' ------------------------------------------------------------------------------------------ '
'
' C�m               :  SimTuring 1.0
' Le�r�s            :  Turing-g�p �s felismer� automat�k
'                      sz�m�t�g�pes szimul�ci�ja
'                      Visual Basic 6.0 - ban
' Program kezdete   :  2002.05.06.
' Utols� m�dos�t�s  :  2002.08.15.
' Szerz�            :  G�l Zsolt
'
' ------------------------------------------------------------------------------------------ '
'
' FORMOK            :  RENDELTET�S�K
'
' frm_Abc_List      :  Az automata ABC-j�nek list�ja
' frm_Abc_Rec       :  Az automata ABC-j�nek megad�sa
' frm_About         :  N�vjegy
' frm_Full_Open     :  Az automata mentett be�ll�t�sainak bet�lt�se egy l�p�sben
' frm_Full_Save     :  Az automata be�ll�t�sainak ment�se egy l�p�sben
' frm_Head          :  Az eredm�nyablak nagy�t�sa
' frm_Menu1         :  Megjelen�ti a men�rendszer 1. r�sz�t
' frm_Menu2         :  Megjelen�ti a men�rendszer 2. r�sz�t
' frm_Param_Open    :  Az automata mentett be�ll�t�sainak bet�lt�se
' frm_Param_Save    :  Az automata be�ll�t�sainak ment�se
' frm_Reg_List      :  Az automata szab�lyainak list�ja
' frm_Reg_Rec       :  Az automata szab�lyai
' frm_Result        :  Az automata szimul�ci�j�nak v�geredm�nye
' frm_Result_List   :  Az automata szimul�ci�j�nak v�geredm�nye list�val
' frm_Result_Save   :  Az automata szimul�ci�j�nak v�geredm�ny�nek ment�se
' frm_State_End     :  A Felismer�-automata v�g�llapotainak megad�sa
' frm_State_Input   :  Az automata kezd� �llapota
' frm_State_List    :  Az automata �llapotainak list�ja
' frm_State_Rec     :  Az automata �llapotainak megad�sa
' frm_Turing_Input  :  Az automata kezd� szava
' frm_Turing_Start  :  Az automata f�men�je (kezd� lapja)
'
' ------------------------------------------------------------------------------------------ '
Option Explicit
       
       Public g_bln_Accept       As Boolean      ' Felismerte-e a bemen� sz�t ?
       Public g_int_Reg          As Integer      ' A megadott szab�ly r�gz�thet�-e ?
       Public g_int_Prev(3 To 5) As Integer      ' El�z� �llapot t�rol�sa
       Public g_int_Row_Big      As Integer      ' Nagy�t�sn�l melyik sor van kijel�lve
       Public g_str_Mode         As String       ' �zemm�d
       Public g_vnt_Input        As Variant      ' Kezd� sz�
       Public g_vnt_State_End    As Variant      ' V�g�llapot
       
       Type g_Reg_Data                           ' Szab�lyok ment�s�hez/beolvas�s�hoz
            int_State1       As Integer          ' Input �llapot
            int_State2       As Integer          ' Output �llapot
            int_Sign1        As Integer          ' Input jel
            int_Sign2        As Integer          ' Output jel
            int_Head_Pos     As Integer          ' Fej-mozg�s
       End Type
       
       Declare Function htmlHelp Lib "hhctrl.ocx" _
               Alias "HtmlHelpA" (ByVal hwnd As Long, _
               ByVal lpHelpFile As String, _
               ByVal wCommand As Long, _
               ByVal dwData As String) As Long
               
       Public Const HH_DISPLAY_TOPIC = &H0
       Public Const HH_DISPLAY_TOC = &H1
       Public Const HH_DISPLAY_INDEX = &H2
       
' ------------------------------------------------------------------------------------------ '
