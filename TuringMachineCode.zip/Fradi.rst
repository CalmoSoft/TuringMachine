

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Fradi Turing-g�p m�k�d�s�nek list�ja.
                      =====================================



 A megadott ABC     : *, a, d, f, i, r

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5

 Kezd� �llapot      : 0

 Kezd� sz�          : fradi

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , f -> 1 , f , J
                      1 , a -> 1 , a , J
                      1 , d -> 1 , d , J
                      1 , i -> 2 , i , B
                      1 , r -> 1 , r , J
                      2 , a -> 2 , a , B
                      2 , d -> 2 , d , B
                      2 , f -> 0 , f , M
                      2 , r -> 2 , r , B


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************fradi***********   