

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : MRNS Turing-g�p m�k�d�s�nek list�ja.
                      ====================================



 A megadott ABC     : 1, 2, 3, 4, 5, 6, 7, 8, 9, a, A, b, c, C, d, e, f, g, G, h, i, j, k, l, m, n, o, p, q, r, s, t, U

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P

 Kezd� �llapot      : 0

 Kezd� sz�          : AUGGAG

 V�gs� �llapot      : O

 Output             : AUoGAi

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , A -> 1 , A , J
                      0 , C -> 0 , C , J
                      0 , G -> 0 , G , J
                      0 , U -> 0 , U , J
                      1 , A -> 1 , A , J
                      1 , C -> 0 , C , J
                      1 , G -> 0 , G , J
                      1 , U -> 2 , U , J
                      2 , A -> 1 , A , J
                      2 , C -> 0 , C , J
                      2 , G -> 3 , o , J
                      2 , U -> 0 , U , J
                      3 , A -> 5 , A , J
                      3 , C -> 5 , C , J
                      3 , G -> 7 , G , J
                      3 , U -> 4 , U , J
                      4 , A -> A , A , J
                      4 , C -> 9 , C , J
                      4 , G -> B , G , J
                      4 , U -> 8 , U , J
                      5 , A -> E , A , J
                      5 , C -> D , C , J
                      5 , G -> F , G , J
                      5 , U -> C , U , J
                      6 , A -> I , A , J
                      6 , C -> H , C , J
                      6 , G -> J , G , J
                      6 , U -> G , U , J
                      7 , A -> M , A , J
                      7 , C -> L , C , J
                      7 , G -> N , G , J
                      7 , U -> K , U , J
                      8 , A -> O , d , J
                      8 , C -> O , p , J
                      8 , G -> O , d , J
                      8 , U -> O , p , J
                      9 , A -> O , f , J
                      9 , C -> O , f , J
                      9 , G -> O , f , J
                      9 , U -> O , f , J
                      A , A -> P , A , J
                      A , C -> O , q , J
                      A , G -> P , G , J
                      A , U -> O , q , J
                      B , A -> P , A , J
                      B , C -> O , n , J
                      B , G -> O , r , J
                      B , U -> O , n , J
                      C , A -> O , d , J
                      C , C -> O , d , J
                      C , G -> 0 , d , J
                      C , U -> O , d , J
                      D , A -> O , t , J
                      D , C -> O , t , J
                      D , G -> O , t , J
                      D , U -> O , t , J
                      E , A -> O , m , J
                      E , C -> O , s , J
                      E , G -> O , m , J
                      E , U -> O , s , J
                      F , A -> O , k , J
                      F , C -> O , k , J
                      F , G -> O , k , J
                      F , U -> O , k , J
                      G , A -> O , e , J
                      G , C -> O , e , J
                      G , G -> O , o , J
                      G , U -> O , e , J
                      H , A -> O , g , J
                      H , C -> 0 , g , J
                      H , G -> 0 , g , J
                      H , U -> O , g , J
                      I , A -> O , j , J
                      I , C -> O , l , J
                      I , G -> O , j , J
                      I , U -> O , l , J
                      J , A -> O , k , J
                      J , C -> O , f , J
                      J , G -> O , k , J
                      J , U -> O , f , J
                      K , A -> O , c , J
                      K , C -> O , c , J
                      K , G -> O , c , J
                      K , U -> O , c , J
                      L , A -> O , b , J
                      L , C -> O , b , J
                      L , G -> O , b , J
                      L , U -> O , b , J
                      M , A -> O , i , J
                      M , C -> O , h , J
                      M , G -> O , i , J
                      M , U -> O , h , J
                      N , A -> O , a , J
                      N , C -> O , a , J
                      N , G -> O , a , J
                      N , U -> O , a , J
                      O , A -> 6 , A , J
                      O , C -> 5 , C , J
                      O , G -> 7 , G , J
                      O , U -> 4 , U , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************AUGGAG**********   0 , A -> 1 , A   J  15
 002. -> **************AUGGAG**********   1 , U -> 2 , U   J  16
 003. -> **************AUGGAG**********   2 , G -> 3 , o   J  17
 004. -> **************AUoGAG**********   3 , G -> 7 , G   J  18
 005. -> **************AUoGAG**********   7 , A -> M , A   J  19
 006. -> **************AUoGAG**********   M , G -> O , i   J  20
 END. -> **************AUoGAi**********         V�GE !