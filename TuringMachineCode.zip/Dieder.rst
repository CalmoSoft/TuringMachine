

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


Mott�               : 'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


Funkci�             : Dieder Turing-g�p m�k�d�s�nek list�ja.
                      ======================================



 A megadott ABC     : 0, 1, 2, 3, 4, 5, 6, 7

 �tmeneti �llapotok : 0, 1, 2, 3, 4, 5, 6, 7

 Kezd� �llapot      : 0

 Kezd� sz�          : 123

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , 0 -> 0 , 0 , J
                      0 , 1 -> 1 , 1 , J
                      0 , 2 -> 2 , 2 , J
                      0 , 3 -> 3 , 3 , J
                      0 , 4 -> 4 , 4 , J
                      0 , 5 -> 5 , 5 , J
                      0 , 6 -> 6 , 6 , J
                      0 , 7 -> 7 , 7 , J
                      1 , 0 -> 1 , 0 , J
                      1 , 1 -> 2 , 1 , J
                      1 , 2 -> 3 , 2 , J
                      1 , 3 -> 0 , 3 , J
                      1 , 4 -> 5 , 4 , J
                      1 , 5 -> 6 , 5 , J
                      1 , 6 -> 7 , 6 , J
                      1 , 7 -> 4 , 7 , J
                      2 , 0 -> 2 , 0 , J
                      2 , 1 -> 3 , 1 , J
                      2 , 2 -> 0 , 2 , J
                      2 , 3 -> 1 , 3 , J
                      2 , 4 -> 6 , 4 , J
                      2 , 5 -> 7 , 5 , J
                      2 , 6 -> 4 , 6 , J
                      2 , 7 -> 5 , 7 , J
                      3 , 0 -> 3 , 0 , J
                      3 , 1 -> 0 , 1 , J
                      3 , 2 -> 1 , 2 , J
                      3 , 3 -> 2 , 3 , J
                      3 , 4 -> 7 , 4 , J
                      3 , 5 -> 4 , 5 , J
                      3 , 6 -> 5 , 6 , J
                      3 , 7 -> 6 , 7 , J
                      4 , 0 -> 4 , 0 , J
                      4 , 1 -> 7 , 1 , J
                      4 , 2 -> 6 , 2 , J
                      4 , 3 -> 5 , 3 , J
                      4 , 4 -> 0 , 4 , J
                      4 , 5 -> 3 , 5 , J
                      4 , 6 -> 2 , 6 , J
                      4 , 7 -> 1 , 7 , J
                      5 , 0 -> 5 , 0 , J
                      5 , 1 -> 4 , 1 , J
                      5 , 2 -> 7 , 2 , J
                      5 , 3 -> 6 , 3 , J
                      5 , 4 -> 1 , 4 , J
                      5 , 5 -> 0 , 5 , J
                      5 , 6 -> 3 , 6 , J
                      5 , 7 -> 2 , 7 , J
                      6 , 0 -> 6 , 0 , J
                      6 , 1 -> 5 , 1 , J
                      6 , 2 -> 4 , 2 , J
                      6 , 3 -> 7 , 3 , J
                      6 , 4 -> 2 , 4 , J
                      6 , 5 -> 1 , 5 , J
                      6 , 6 -> 0 , 6 , J
                      6 , 7 -> 3 , 7 , J
                      7 , 0 -> 7 , 0 , J
                      7 , 1 -> 6 , 1 , J
                      7 , 2 -> 5 , 2 , J
                      7 , 3 -> 4 , 3 , J
                      7 , 4 -> 3 , 4 , J
                      7 , 5 -> 2 , 5 , J
                      7 , 6 -> 1 , 6 , J
                      7 , 7 -> 0 , 7 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************123*************   