

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Penrose_058 Turing-g�p m�k�d�s�nek list�ja.
                      ===========================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : !, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a

 Kezd� �llapot      : 0

 Kezd� sz�          : 11110111111

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , 0 -> 0 , 0 , J
                      0 , 1 -> 1 , 1 , B
                      1 , 0 -> 2 , 1 , J
                      1 , 1 -> 1 , 1 , B
                      2 , 0 -> a , 0 , J
                      2 , 1 -> 3 , 0 , J
                      3 , 0 -> 4 , 0 , J
                      3 , 1 -> 3 , 1 , J
                      4 , 0 -> 4 , 0 , J
                      4 , 1 -> 3 , 0 , J
                      5 , 0 -> 7 , 0 , B
                      5 , 1 -> 6 , 1 , B
                      6 , 0 -> 6 , 0 , B
                      6 , 1 -> 1 , 1 , B
                      7 , 0 -> 7 , 0 , B
                      7 , 1 -> 8 , 1 , B
                      8 , 0 -> 9 , 0 , B
                      8 , 1 -> 8 , 1 , B
                      9 , 0 -> 2 , 0 , J
                      9 , 1 -> 1 , 1 , B
                      a , 0 -> ! , 0 , M
                      a , 1 -> a , 1 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************11110111111*****   