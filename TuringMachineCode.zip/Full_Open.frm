VERSION 5.00
Begin VB.Form frm_Full_Open 
   BackColor       =   &H00808000&
   Caption         =   "Teljes feladat beolvas�sa"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2850
   ClientWidth     =   4425
   ControlBox      =   0   'False
   HelpContextID   =   11
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   4425
   Begin VB.ListBox lst_Full_Open 
      Appearance      =   0  'Flat
      Height          =   2565
      ItemData        =   "Full_Open.frx":0000
      Left            =   960
      List            =   "Full_Open.frx":0002
      TabIndex        =   4
      ToolTipText     =   "A megny�that� �llom�nyok list�ja"
      Top             =   1200
      Width           =   2535
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   2655
      TabIndex        =   2
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4080
      Width           =   840
   End
   Begin VB.CommandButton cmd_Full_Open 
      BackColor       =   &H00C0C0C0&
      Caption         =   "File bet�lt�se"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   960
      TabIndex        =   1
      ToolTipText     =   "A kijel�lt �llom�ny megnyit�sa"
      Top             =   4080
      Width           =   1635
   End
   Begin VB.FileListBox fil_Param 
      Appearance      =   0  'Flat
      Height          =   2565
      Left            =   600
      TabIndex        =   0
      Top             =   1440
      Visible         =   0   'False
      Width           =   2535
   End
   Begin VB.Label lbl_Param2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "File kiv�laszt�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   960
      TabIndex        =   3
      Top             =   600
      Width           =   2535
   End
   Begin VB.Shape fra_File_Open 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4575
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   3735
   End
End
Attribute VB_Name = "frm_Full_Open"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Full_Open     :  Az automata mentett be�ll�t�sainak bet�lt�se egy l�p�sben
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        frm_Turing_Start.msg ("")
        frm_Full_Open.Hide
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          Elmentett be�ll�t�sok bet�lt�se : '
'                                                              ABC lista, �llapotok list�ja, '
'                                                       kezd� �llapot, kezd� sz�, v�g�llapot '
Public Sub cmd_Full_Open_Click()
        Dim i             As Integer        ' index-v�ltoz�
        Dim j             As Integer        ' index-v�ltoz�
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz
            
        frm_Full_Open.Hide
        
        j = lst_Full_Open.ListIndex
        If j > -1 Then '''
        If g_str_Mode = "T" Then
           str_File_Name = lst_Full_Open.List(j) & ".prt"
        Else
           str_File_Name = lst_Full_Open.List(j) & ".prf"
        End If
        frm_Param_Open.fil_Param.FileName = str_File_Name
        frm_Param_Open.cmd_File_Open_Click
        
        frm_Full_Open.Hide
        j = lst_Full_Open.ListIndex
        If g_str_Mode = "T" Then
           str_File_Name = lst_Full_Open.List(j) & ".rgt"
        Else
           str_File_Name = lst_Full_Open.List(j) & ".rgf"
        End If
        frm_Reg_Rec.fil_Turing.FileName = str_File_Name
        frm_Turing_Start.File_Open_Reg
        With frm_Turing_Start
            .chk_Reg.Visible = True
            .chk_ABC.Visible = True
            .chk_State.Visible = True
            .chk_Input.Visible = True
            .chk_Begin.Visible = True
            .chk_Reg.Value = 1
            .chk_ABC.Value = 1
            .chk_State.Value = 1
            .chk_Input.Value = 1
            .chk_Begin.Value = 1
            .lbl_Reg.Enabled = True
            .lbl_ABC.Enabled = True
            .lbl_State.Enabled = True
            .lbl_Input.Enabled = True
            .lbl_Begin.Enabled = True
            If g_str_Mode = "F" Then
               .chk_End.Visible = True
               .chk_End.Value = 1
               .lbl_End.Enabled = True
            End If
            .mnu_Param_Save.Enabled = True
            .mnu_Param_Save2.Enabled = True
                   .tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
            .mnu_Full_Save.Enabled = True
            .mnu_Full_Save2.Enabled = True
            .tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = True
            .msg ("File bet�lt�se befejez�d�tt")
        End With
        End If '''
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                           �rlap aktiv�l�sa '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz
        
        fil_Param.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Param.Pattern = "*.prt"
        Else
           fil_Param.Pattern = "*.prf"
        End If
        str_File_Name = fil_Param.FileName
        lst_Full_Open.Clear
        For i = 1 To fil_Param.ListCount
            j = Len(fil_Param.List(i - 1))
            lst_Full_Open.AddItem Left(fil_Param.List(i - 1), j - 4)
        Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz
        
        
        fil_Param.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Param.Pattern = "*.prt"
        Else
           fil_Param.Pattern = "*.prf"
        End If
        str_File_Name = fil_Param.FileName
        lst_Full_Open.Clear
        For i = 1 To fil_Param.ListCount
            j = Len(fil_Param.List(i - 1))
            lst_Full_Open.AddItem Left(fil_Param.List(i - 1), j - 4)
        Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             A kijel�lt �llom�nyt megnyitja '
Private Sub lst_Full_Open_DblClick()
            cmd_Full_Open_Click
            cmd_Close_Click
End Sub
' ------------------------------------------------------------------------------------------ '

