VERSION 5.00
Begin VB.Form frm_State_End 
   BackColor       =   &H00808000&
   Caption         =   "V�g�llapot"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   2280
   ControlBox      =   0   'False
   HelpContextID   =   19
   LinkTopic       =   "Form11"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   2280
   Begin VB.ListBox lst_State_End 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2310
      ItemData        =   "State_End.frx":0000
      Left            =   720
      List            =   "State_End.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   0
      ToolTipText     =   "Az automata �llapotai"
      Top             =   1680
      Width           =   855
   End
   Begin VB.CommandButton cmd_State_End_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   1
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4200
      Width           =   855
   End
   Begin VB.Shape fra_State_End 
      BorderWidth     =   2
      Height          =   4575
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   240
      Width           =   1575
   End
   Begin VB.Label lbl_State_End 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   720
      TabIndex        =   3
      ToolTipText     =   "Az felismer� automata v�g�llapot�nak megad�sa"
      Top             =   1320
      Width           =   855
   End
   Begin VB.Label lbl_State_Veg 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "V�g- �llapot"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   720
      TabIndex        =   2
      Top             =   480
      Width           =   855
   End
End
Attribute VB_Name = "frm_State_End"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_State_End     :  A Felismer�-automata v�g�llapotainak megad�sa
'
' ------------------------------------------------------------------------------------------ '
       Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Public Sub cmd_State_End_Close_Click()
        If g_vnt_State_End <> "" Then
           frm_State_End.Hide
           frm_Turing_Start.chk_End.Value = 1
           If frm_Turing_Start.param() = 1 Then
              frm_Turing_Start.mnu_Param_Save.Enabled = True
              frm_Turing_Start.mnu_Param_Save2.Enabled = True
               frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(1).Enabled = True
           End If
           If frm_Turing_Start.begin() = 1 Then
              frm_Turing_Start.mnu_Full_Save.Enabled = True
              frm_Turing_Start.mnu_Full_Save2.Enabled = True
              frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = True
           End If
        Else
           lst_State_End.SetFocus
           Beep
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        V�g�llapot megad�sa '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�
        Dim j As Integer                    ' index-v�ltoz�
                
        j = lst_State_End.ListIndex
        If j >= 0 Then
            g_vnt_State_End = lst_State_End.List(j)
        Else
            g_vnt_State_End = ""
        End If
        If lst_State_End.ListCount = 0 Then
           For i = 1 To frm_State_Rec.lst_State.ListCount
               lst_State_End.AddItem _
               frm_State_Rec.lst_State.List(i - 1)
           Next i
        End If
        lbl_State_End.Caption = g_vnt_State_End
        frm_Turing_Start.chk_End.Value = 0
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                        V�g�llapot megad�sa '
Public Sub lst_State_End_Click()
        If frm_State_Rec.lst_State.ListCount > 0 Then
           g_vnt_State_End = lst_State_End.Text
           lbl_State_End.Caption = g_vnt_State_End
        End If
End Sub
' ------------------------------------------------------------------------------------------ '

