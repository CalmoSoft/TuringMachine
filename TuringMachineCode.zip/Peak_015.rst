

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Peak_015 Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : u, v, x, y

 �tmeneti �llapotok : a, b, c, d

 Kezd� �llapot      : a

 Kezd� sz�          : xyxy

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      a , x -> b , v , J
                      a , y -> c , u , J
                      b , x -> a , u , J
                      b , y -> c , u , J
                      c , x -> b , v , J
                      c , y -> d , v , J
                      d , x -> d , v , J
                      d , y -> b , v , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************xyxy************   