

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Papa_023 Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : *, >, 0, 1

 �tmeneti �llapotok : 1, 2, 3, 4, 5, 6, 7, 8

 Kezd� �llapot      : 1

 Kezd� sz�          : >11011

 V�gs� �llapot      : 

 Output             : 


 Szab�lyok          : A1  BE   A2  KI  M

                      1 , * -> 2 , * , B
                      1 , > -> 1 , > , J
                      1 , 0 -> 1 , 0 , J
                      1 , 1 -> 1 , 1 , J
                      2 , * -> 2 , * , M
                      2 , > -> 8 , > , J
                      2 , 0 -> 3 , * , J
                      2 , 1 -> 4 , * , J
                      3 , * -> 1 , 0 , B
                      3 , > -> 5 , > , J
                      3 , 0 -> 1 , 0 , B
                      3 , 1 -> 1 , 0 , B
                      4 , * -> 1 , 1 , B
                      4 , > -> 5 , > , J
                      4 , 0 -> 1 , 1 , B
                      4 , 1 -> 1 , 1 , B
                      5 , * -> 6 , * , B
                      5 , > -> 5 , > , J
                      5 , 0 -> 5 , 0 , J
                      5 , 1 -> 5 , 1 , J
                      6 , > -> 7 , > , J
                      6 , > -> 7 , > , J
                      6 , 0 -> 7 , 1 , M
                      6 , 1 -> 6 , 0 , B
                      8 , * -> 5 , 0 , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

 001. -> **************>11011**********   