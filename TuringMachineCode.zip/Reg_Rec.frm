VERSION 5.00
Begin VB.Form frm_Reg_Rec 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00808000&
   Caption         =   "Szab�lyok megad�sa"
   ClientHeight    =   8310
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   11880
   ControlBox      =   0   'False
   HelpContextID   =   25
   LinkTopic       =   "Form8"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   8310
   ScaleWidth      =   11880
   Begin VB.CommandButton cmd_Mod 
      BackColor       =   &H00C0C0C0&
      Caption         =   "M�dos�t"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6615
      TabIndex        =   40
      ToolTipText     =   "Megadott szab�ly felv�tele a list�ra"
      Top             =   1680
      Width           =   825
   End
   Begin VB.TextBox txt_File_Save 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8400
      TabIndex        =   22
      ToolTipText     =   "�llom�ny neve kiterjeszt�s n�lk�l"
      Top             =   1680
      Width           =   2295
   End
   Begin VB.FileListBox fil_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   4755
      Left            =   8415
      Pattern         =   "*.dat"
      System          =   -1  'True
      TabIndex        =   21
      ToolTipText     =   "Megnyithat� szab�lyok list�ja"
      Top             =   2520
      Width           =   2295
   End
   Begin VB.ListBox lst_Reg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4815
      IntegralHeight  =   0   'False
      ItemData        =   "Reg_Rec.frx":0000
      Left            =   5895
      List            =   "Reg_Rec.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   19
      ToolTipText     =   "Szab�lyok megjelen�t�se"
      Top             =   2400
      Width           =   2295
   End
   Begin VB.CommandButton cmd_Exit 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Left            =   5880
      TabIndex        =   18
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   1320
      Width           =   2295
   End
   Begin VB.CommandButton cmd_Del 
      BackColor       =   &H00C0C0C0&
      Caption         =   "T�r�l"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7440
      TabIndex        =   17
      ToolTipText     =   "Megadott szab�ly t�rl�se"
      Top             =   1680
      Width           =   735
   End
   Begin VB.CommandButton cmd_Rec 
      BackColor       =   &H00C0C0C0&
      Caption         =   "R�gz�t"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5880
      TabIndex        =   16
      ToolTipText     =   "Megadott szab�ly felv�tele a list�ra"
      Top             =   1680
      Width           =   735
   End
   Begin VB.ListBox lst_Head 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5070
      ItemData        =   "Reg_Rec.frx":0004
      Left            =   4560
      List            =   "Reg_Rec.frx":0006
      TabIndex        =   12
      ToolTipText     =   "Fej �llapotainak list�ja"
      Top             =   2160
      Width           =   1095
   End
   Begin VB.ListBox lst_Output 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5070
      ItemData        =   "Reg_Rec.frx":0008
      Left            =   3720
      List            =   "Reg_Rec.frx":000A
      TabIndex        =   9
      ToolTipText     =   "Kimen� jelek list�ja"
      Top             =   2160
      Width           =   735
   End
   Begin VB.ListBox lst_State2 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5070
      ItemData        =   "Reg_Rec.frx":000C
      Left            =   2880
      List            =   "Reg_Rec.frx":000E
      TabIndex        =   6
      ToolTipText     =   "Kimen� �llapotok list�ja"
      Top             =   2160
      Width           =   735
   End
   Begin VB.ListBox lst_Input 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5070
      ItemData        =   "Reg_Rec.frx":0010
      Left            =   2040
      List            =   "Reg_Rec.frx":0012
      TabIndex        =   3
      ToolTipText     =   "Bemen� jelek list�ja"
      Top             =   2160
      Width           =   735
   End
   Begin VB.ListBox lst_State1 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5070
      ItemData        =   "Reg_Rec.frx":0014
      Left            =   1200
      List            =   "Reg_Rec.frx":0016
      TabIndex        =   0
      ToolTipText     =   "Bemen� �llapotok list�ja"
      Top             =   2160
      Width           =   735
   End
   Begin VB.Label lbl_Reg_Rec_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   5895
      TabIndex        =   39
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot"
      Top             =   2160
      Visible         =   0   'False
      Width           =   2295
   End
   Begin VB.Label lbl_Fej_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   5160
      TabIndex        =   38
      ToolTipText     =   "Fej �llapotainak sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_A1_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   1440
      TabIndex        =   37
      ToolTipText     =   "Bemen� �llapotok sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_BE_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   2280
      TabIndex        =   36
      ToolTipText     =   "Bemen� jelek sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_A2_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   3120
      TabIndex        =   35
      ToolTipText     =   "Kimen� �llapotok sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_Open_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   10200
      TabIndex        =   34
      ToolTipText     =   "Megnyithat� szab�lyok �llom�nyainak sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_KI_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   3960
      TabIndex        =   33
      ToolTipText     =   "Kimen� jelek sz�ma"
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_Reg_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   7680
      TabIndex        =   32
      Top             =   7200
      Width           =   495
   End
   Begin VB.Label lbl_KI 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   3720
      TabIndex        =   31
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_A2 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   2880
      TabIndex        =   30
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_RegWhat 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   5880
      TabIndex        =   29
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_FEJ 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   4560
      TabIndex        =   28
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_Open 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   8400
      TabIndex        =   27
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_BE 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   2040
      TabIndex        =   26
      Top             =   7200
      Width           =   375
   End
   Begin VB.Label lbl_A1 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   1200
      TabIndex        =   25
      Top             =   7200
      Width           =   375
   End
   Begin VB.Shape Shape1 
      BorderWidth     =   2
      Height          =   7575
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   360
      Width           =   11175
   End
   Begin VB.Label lbl_Reg_Rec_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2  KI  M"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   5895
      TabIndex        =   24
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, KI = Kimen� jel, M = Fejmozg�s(B=Balra, J=Jobbra, M=Marad)"
      Top             =   2160
      Width           =   2295
   End
   Begin VB.Label lbl_File_Open 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Bet�lt�s"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   8400
      TabIndex        =   23
      ToolTipText     =   "Szab�lyok megnyit�sa"
      Top             =   2160
      Width           =   2295
   End
   Begin VB.Label lbl_File_Save 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Ment�s"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   8400
      TabIndex        =   20
      ToolTipText     =   "Szab�lyok ment�se a megadott n�vvel"
      Top             =   1320
      Width           =   2295
   End
   Begin VB.Label lbl_Reg 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Szab�lyok megad�sa"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   1200
      TabIndex        =   15
      Top             =   720
      Width           =   9495
   End
   Begin VB.Label lbl_Reg5 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "FEJ"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   4560
      TabIndex        =   14
      ToolTipText     =   "Fejmozg�s"
      Top             =   1320
      Width           =   1095
   End
   Begin VB.Label lbl_Head 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   4560
      TabIndex        =   13
      ToolTipText     =   "Kiv�lasztott fej�llapot"
      Top             =   1680
      Width           =   1095
   End
   Begin VB.Label lbl_Reg4 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "KI"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   3720
      TabIndex        =   11
      ToolTipText     =   "Kimen� jel"
      Top             =   1320
      Width           =   735
   End
   Begin VB.Label lbl_Output 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   3720
      TabIndex        =   10
      ToolTipText     =   "Kiv�lasztott kimen� jel"
      Top             =   1680
      Width           =   735
   End
   Begin VB.Label lbl_State2 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   2880
      TabIndex        =   8
      ToolTipText     =   "Kiv�lasztott kimen� �llapot"
      Top             =   1680
      Width           =   735
   End
   Begin VB.Label lbl_Szab3 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A2"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   2880
      TabIndex        =   7
      ToolTipText     =   "Kimen� �llapot"
      Top             =   1320
      Width           =   735
   End
   Begin VB.Label lbl_Input 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   2040
      TabIndex        =   5
      ToolTipText     =   "Kiv�lasztott bemen� jel"
      Top             =   1680
      Width           =   735
   End
   Begin VB.Label lbl_Reg2 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "BE"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   2040
      TabIndex        =   4
      ToolTipText     =   "Bemen� jel"
      Top             =   1320
      Width           =   735
   End
   Begin VB.Label lbl_Reg1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   8.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   1200
      TabIndex        =   2
      ToolTipText     =   "Bemen� �llapot"
      Top             =   1320
      Width           =   735
   End
   Begin VB.Label lbl_State1 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   14.25
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   1200
      TabIndex        =   1
      ToolTipText     =   "Kiv�lasztott bemen� �llapot"
      Top             =   1680
      Width           =   735
   End
   Begin VB.Menu mnu_File 
      Caption         =   "&File"
      Begin VB.Menu mnu_File_Open 
         Caption         =   "Szab�lyok bet�lt�se"
      End
      Begin VB.Menu mnu_File_Save 
         Caption         =   "Szab�lyok ment�se"
      End
   End
   Begin VB.Menu mnu_Muv 
      Caption         =   "&M�veletek"
      Begin VB.Menu mnu_Rec 
         Caption         =   "&R�gz�t"
      End
      Begin VB.Menu mnu_Mod 
         Caption         =   "&M�dos�t"
      End
      Begin VB.Menu mnu_Del 
         Caption         =   "&T�r�l"
      End
   End
   Begin VB.Menu mnu_Options 
      Caption         =   "Be�ll�t�sok"
      Begin VB.Menu mnu_Prev 
         Caption         =   "El�z� adatok maradnak"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnu_Kilep 
      Caption         =   "&Kil�p"
      Begin VB.Menu mnu_Exit 
         Caption         =   "&Kil�p"
      End
   End
   Begin VB.Menu mnu_Sum 
      Caption         =   "�sszes"
      Visible         =   0   'False
      Begin VB.Menu mnu_File2 
         Caption         =   "File"
      End
      Begin VB.Menu mnu_File_Open2 
         Caption         =   "     Szab�lyok bet�lt�se"
      End
      Begin VB.Menu mnu_File_Save2 
         Caption         =   "     Szab�lyok ment�se"
      End
      Begin VB.Menu mnu_Sep1 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Muv2 
         Caption         =   "M�veletek"
      End
      Begin VB.Menu mnu_Rec2 
         Caption         =   "     R�gz�t"
      End
      Begin VB.Menu mnu_Mod2 
         Caption         =   "     M�dos�t"
      End
      Begin VB.Menu mnu_Del2 
         Caption         =   "     T�r�l"
      End
      Begin VB.Menu mnu_Options2 
         Caption         =   "Be�ll�t�sok"
      End
      Begin VB.Menu mnu_Prev2 
         Caption         =   "     El�z� adatok maradnak"
      End
      Begin VB.Menu mnu_Sep2 
         Caption         =   "-"
      End
      Begin VB.Menu mnu_Kilep2 
         Caption         =   "Kil�p"
      End
      Begin VB.Menu mnu_Exit2 
         Caption         =   "     Kil�p"
      End
   End
End
Attribute VB_Name = "frm_Reg_Rec"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Reg_Rec      :  Az automata szab�lyai
'
' ------------------------------------------------------------------------------------------ '
       Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                 Szab�ly t�rl�se a list�b�l '
Public Sub cmd_Del_Click()
        Dim ind As Integer                  ' index-v�ltoz�
        
        ind = lst_Reg.ListIndex
        If ind >= 0 Then
           frm_Turing_Start.Reg_Delete
           lbl_Reg_Nr = lst_Reg.ListCount
        End If
        cmd_Del.Enabled = False
        mnu_Del.Enabled = False
        mnu_Del2.Enabled = False
        cmd_Mod.Enabled = False
        mnu_Mod.Enabled = False
        mnu_Mod2.Enabled = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Public Sub cmd_Exit_Click()
       If lst_Reg.ListCount > 0 Then
          frm_Reg_Rec.Hide
          frm_Turing_Start.chk_Reg.Value = 1
          frm_Turing_Start.mnu_Reg_List.Enabled = True
          frm_Turing_Start.mnu_Reg_List2.Enabled = True
          frm_Turing_Start.chk_Reg.Visible = True
          frm_Turing_Start.lbl_Reg.Visible = True
          If frm_Turing_Start.param() = 1 Then
             frm_Turing_Start.mnu_Full_Save.Enabled = True
             frm_Turing_Start.mnu_Full_Save2.Enabled = True
             frm_Turing_Start.tlb_Turing.Buttons(2).ButtonMenus(2).Enabled = True
          End If
       Else
          frm_Reg_Rec.Hide
          frm_Turing_Start.chk_Reg.Value = 0
       End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                              A kijel�lt szab�ly m�dos�t�sa '
Public Sub cmd_Mod_Click()
        Dim i           As Integer          ' index-v�ltoz�
        Dim int_Reg_Ind As Integer          ' Melyik szab�ly van kijel�lve ?
        Dim vissza      As Integer          ' Listaelem �jboli megjelen�t�s�hez
        
        int_Reg_Ind = lst_Reg.ListIndex
        If int_Reg_Ind >= 0 Then
            For i = 1 To lst_State1.ListCount
                If Asc(lst_State1.List(i - 1)) = _
                   Asc(Mid(lst_Reg.List(int_Reg_Ind), 1, 1)) Then
                   lst_State1.ListIndex = i - 1
                   vissza = i - 1
                   Exit For
                End If
            Next i
            For i = 1 To lst_Input.ListCount
                If Asc(lst_Input.List(i - 1)) = _
                   Asc(Mid(lst_Reg.List(int_Reg_Ind), 5, 1)) Then
                   lst_Input.ListIndex = i - 1
                   Exit For
                End If
            Next i
            For i = 1 To lst_State2.ListCount
                If Asc(lst_State2.List(i - 1)) = _
                   Asc(Mid(lst_Reg.List(int_Reg_Ind), 10, 1)) Then
                   lst_State2.ListIndex = i - 1
                   Exit For
                End If
            Next i
            If g_str_Mode = "T" Then
               For i = 1 To lst_Output.ListCount
                   If Asc(lst_Output.List(i - 1)) = _
                      Asc(Mid(lst_Reg.List(int_Reg_Ind), 14, 1)) Then
                      lst_Output.ListIndex = i - 1
                      Exit For
                   End If
               Next i
               For i = 1 To lst_Head.ListCount
                   If Asc(Left(lst_Head.List(i - 1), 1)) = _
                      Asc(Mid(lst_Reg.List(int_Reg_Ind), 18, 1)) Then
                      lst_Head.ListIndex = i - 1
                      Exit For
                   End If
               Next i
            End If
            frm_Turing_Start.Reg_Delete
            lst_State1.ListIndex = vissza
            lbl_State1 = lst_State1.List(vissza)
        End If
        lbl_Reg_Nr = lst_Reg.ListCount
        cmd_Mod.Enabled = False
        mnu_Mod.Enabled = False
        mnu_Mod2.Enabled = False
        cmd_Del.Enabled = False
        mnu_Del.Enabled = False
        mnu_Del2.Enabled = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Szab�ly felv�tele a list�ba '
Private Sub cmd_Rec_Click()
        Dim i As Integer                    ' index-v�ltoz�
        
        i = Rec_Good()
        If i > 0 Then
           frm_Turing_Start.Reg_Record
           lbl_Reg_Nr = lst_Reg.ListCount
        End If
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
        cmd_Rec.Enabled = (g_int_Reg = 0)
        mnu_Rec.Enabled = (g_int_Reg = 0)
        mnu_Rec2.Enabled = (g_int_Reg = 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                     A kijel�lt szab�ly-�llom�ny megnyit�sa '
Private Sub fil_Turing_DblClick()
        frm_Turing_Start.File_Open_Reg
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                 Szab�lyok megad�sa men�b�l '
Private Sub Form_Activate()
        Dim i             As Integer        ' index-v�ltoz�
        Dim bln_Cond      As Boolean        ' Felt�tel vizsg�lathoz
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz

        lbl_Reg.Caption = "Szab�lyok megad�sa"
        lst_State1.SetFocus
        fil_Turing.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Turing.Pattern = "*.rgt"
        Else
           fil_Turing.Pattern = "*.rgf"
        End If
        str_File_Name = fil_Turing.FileName
        If g_str_Mode = "T" Then
           lbl_Reg_Rec_Turing.Visible = True
           lbl_Reg_Rec_Accept.Visible = False
        Else
           lbl_Reg_Rec_Turing.Visible = False
           lbl_Reg_Rec_Accept.Visible = True
        End If
        lst_State1.Clear
        lst_State2.Clear
        lst_Input.Clear
        lst_Output.Clear
        lst_Head.Clear
        For i = 1 To frm_State_Rec.lst_State.ListCount   ' Input �llapot
            lst_State1.AddItem _
            frm_State_Rec.lst_State.List(i - 1)
        Next i
        lbl_A1_Nr = i - 1
        For i = 1 To frm_Abc_Rec.lst_ABC.ListCount       ' Input jel
            lst_Input.AddItem _
            frm_Abc_Rec.lst_ABC.List(i - 1)
        Next i
        lbl_BE_Nr = i - 1
        For i = 1 To frm_State_Rec.lst_State.ListCount   ' Output �llapot
            lst_State2.AddItem _
            frm_State_Rec.lst_State.List(i - 1)
        Next i
        lbl_A2_Nr = i - 1
        For i = 1 To frm_Abc_Rec.lst_ABC.ListCount       ' Output jel
            lst_Output.AddItem _
            frm_Abc_Rec.lst_ABC.List(i - 1)
        Next i
        lbl_KI_Nr = i - 1
        lst_Head.AddItem "Balra"                         ' Fej �llapotai
        lst_Head.AddItem "Jobbra"
        lst_Head.AddItem "Marad"
        lbl_Fej_Nr = 3
        lbl_Reg_Nr = lst_Reg.ListCount
        lbl_Open_Nr = fil_Turing.ListCount
        bln_Cond = (g_str_Mode = "T")
        lbl_Reg4.Enabled = bln_Cond
        lbl_Output.Enabled = bln_Cond
        lst_Output.Enabled = bln_Cond
        lbl_Reg5.Enabled = bln_Cond
        lbl_Head.Enabled = bln_Cond
        lst_Head.Enabled = bln_Cond
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
        lbl_State1 = ""
        lbl_Input = ""
        lbl_State2 = ""
        lbl_Output = ""
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                            �rlap bet�lt�se '
Private Sub Form_Load()
        Dim bln_Cond As Boolean             ' Felt�tel vizsg�lathoz
        Dim str_File_Name As String         ' File nev�nek t�rol�s�hoz

        lbl_Reg.Caption = "Szab�lyok megad�sa"
        fil_Turing.Path = "C:\TURING"
        If g_str_Mode = "T" Then
           fil_Turing.Pattern = "*.rgt"
        Else
           fil_Turing.Pattern = "*.rgf"
        End If
        str_File_Name = fil_Turing.FileName
        If frm_Turing_Start.lbl_File <> "" Then
           txt_File_Save = frm_Turing_Start.lbl_File
        End If
        bln_Cond = (g_str_Mode = "T")
        lbl_Reg4.Enabled = bln_Cond
        lbl_Output.Enabled = bln_Cond
        lst_Output.Enabled = bln_Cond
        lbl_Reg5.Enabled = bln_Cond
        lbl_Head.Enabled = bln_Cond
        lst_Head.Enabled = bln_Cond
        frm_Turing_Start.chk_Reg.Value = 0
        lbl_Reg_Nr = lst_Reg.ListCount
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                   Helyi men� megjelen�t�se '
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, x As Single, _
                         y As Single)
        If Button = 2 Then
           PopupMenu mnu_Sum
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                       Mentett szab�lyok bet�lt�se file-b�l '
Private Sub lbl_File_Open_Click()
        frm_Turing_Start.File_Open_Reg
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                  Szab�lyok ment�se file-ba '
Private Sub lbl_File_Save_Click()
        frm_Turing_Start.File_Save_Reg
End Sub

' ------------------------------------------------------------------------------------------ '
'                                                                    Fej-mozg�s kiv�laszt�sa '
Private Sub lst_Head_Click()
        lbl_Head = lst_Head.Text
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                     Input jel kiv�laszt�sa '
Private Sub lst_Input_Click()
        lbl_Input = lst_Input.Text
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                    Output jel kiv�laszt�sa '
Private Sub lst_Output_Click()
        lbl_Output = lst_Output.Text
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                            Egy szab�ly kijel�l�s�n�l enged�lyezi a t�rl�st �s a m�dos�t�st '
Private Sub lst_Reg_Click()
        If lst_Reg.ListCount > 0 Then
           cmd_Del.Enabled = True
           mnu_Del.Enabled = True
           mnu_Del2.Enabled = True
           cmd_Mod.Enabled = True
           mnu_Mod.Enabled = True
           mnu_Mod2.Enabled = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                 Input �llapot kiv�laszt�sa '
Private Sub lst_State1_Click()
        lbl_State1 = lst_State1.Text
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Output �llapot kiv�laszt�sa '
Private Sub lst_State2_Click()
        lbl_State2 = lst_State2.Text
        cmd_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec.Enabled = (Rec_Good() > 0)
        mnu_Rec2.Enabled = (Rec_Good() > 0)
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                 A kijel�lt szab�ly t�rl�se '
Private Sub mnu_Del_Click()
        Dim int_Reg_Ind As Integer          ' Melyik szab�ly van kijel�lve ?
        
        int_Reg_Ind = lst_Reg.ListIndex
        If int_Reg_Ind >= 0 Then
           frm_Turing_Start.Reg_Delete
           lbl_Reg_Nr = lst_Reg.ListCount
        End If
        cmd_Del.Enabled = False
        mnu_Del.Enabled = False
        mnu_Del2.Enabled = False
        cmd_Mod.Enabled = False
        mnu_Mod.Enabled = False
        mnu_Mod2.Enabled = False
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                 A kijel�lt szab�ly t�rl�se '
Private Sub mnu_Del2_Click()
        mnu_Del_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit_Click()
        cmd_Exit_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub mnu_Exit2_Click()
        mnu_Exit_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          File megnyit�s�nak kezdem�nyez�se '
Private Sub mnu_File_Open_Click()
        frm_Turing_Start.File_Open_Reg
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                          File megnyit�s�nak kezdem�nyez�se '
Private Sub mnu_File_Open2_Click()
        mnu_File_Open_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             File ment�s�nek kezdem�nyez�se '
Private Sub mnu_File_Save_Click()
        frm_Turing_Start.File_Save_Reg
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             File ment�s�nek kezdem�nyez�se '
Private Sub mnu_File_Save2_Click()
        mnu_File_Save_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                              A kijel�lt szab�ly m�dos�t�sa '
Private Sub mnu_Mod_Click()
        cmd_Mod_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                              A kijel�lt szab�ly m�dos�t�sa '
Private Sub mnu_Mod2_Click()
        mnu_Mod_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         El�z� adatok r�gz�t�s ut�n kijel�ve maradjanak-e ? '
Private Sub mnu_Prev_Click()
        Dim bln_Prev As Boolean             ' Felt�tel vizsg�lathoz
            
        bln_Prev = mnu_Prev.Checked
        If bln_Prev Then
           mnu_Prev.Checked = False
           mnu_Prev2.Checked = False
           frm_Reg_Rec.lst_State1.ListIndex = -1
           frm_Reg_Rec.lst_Input.ListIndex = -1
           frm_Reg_Rec.lst_State2.ListIndex = -1
           frm_Reg_Rec.lst_Output.ListIndex = -1
           frm_Reg_Rec.lst_Head.ListIndex = -1
        Else
           mnu_Prev.Checked = True
           mnu_Prev2.Checked = True
        End If
End Sub
' ------------------------------------------------------------------------------------------ '
'                                         El�z� adatok r�gz�t�s ut�n kijel�ve maradjanak-e ? '
Private Sub mnu_Prev2_Click()
        mnu_Prev_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Szab�ly felv�tele a list�ba '
Private Sub mnu_Rec_Click()
        frm_Turing_Start.Reg_Record
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                Szab�ly felv�tele a list�ba '
Private Sub mnu_Rec2_Click()
        mnu_Rec_Click
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                  Az �sszes szab�ly t�rl�se '
Public Sub Reg_Del_All()
       Dim i As Integer                     ' index-v�ltoz�
       Dim j As Integer                     ' index-v�ltoz�

       For i = 1 To lst_Reg.ListCount
           lst_Reg.RemoveItem 0
       Next i
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                             Lehet-e a szab�lyt r�gz�teni ? '
Public Function Rec_Good()
       Dim i                As Integer      ' index-v�ltoz�
       Dim int_Good(1 To 5) As Integer      ' Szab�lyok egyes elemei adottak-e ?
       Dim int_OK           As Integer      ' Lehet-e a szab�lyt r�gz�teni ?

       int_OK = 1
       int_Good(1) = Len(lbl_State1)
       int_Good(2) = Len(lbl_Input)
       int_Good(3) = Len(lbl_State2)
       If g_str_Mode = "T" Then
          int_Good(4) = Len(lbl_Output)
          int_Good(5) = Len(lbl_Head)
       Else
          int_Good(4) = 1
          int_Good(5) = 1
       End If
       For i = 1 To 5
           int_OK = int_OK * int_Good(i)
       Next i
       Rec_Good = int_OK
End Function
' ------------------------------------------------------------------------------------------ '
