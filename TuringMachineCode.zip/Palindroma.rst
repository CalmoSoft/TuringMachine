

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Palindroma Turing-g�p m�k�d�s�nek list�ja.
                      ==========================================



 A megadott ABC     : *, >, 0, 1

 �tmeneti �llapotok : 0, 1, 2, 3, 4, i, n, s

 Kezd� �llapot      : s

 Kezd� sz�          : 101

 V�gs� �llapot      : 

 Output             : 

 Fej kezd�pozici�ja : 15


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , * -> 2 , * , B
                      0 , 0 -> 0 , 0 , J
                      0 , 1 -> 0 , 1 , J
                      1 , * -> 3 , * , B
                      1 , 0 -> 1 , 0 , J
                      1 , 1 -> 1 , 1 , J
                      2 , > -> i , > , J
                      2 , 0 -> 4 , * , B
                      2 , 1 -> n , 1 , M
                      3 , > -> i , > , J
                      3 , 0 -> n , 0 , M
                      3 , 1 -> 4 , * , B
                      4 , > -> s , > , J
                      4 , 0 -> 4 , 0 , B
                      4 , 1 -> 4 , 1 , B
                      s , * -> i , * , M
                      s , > -> s , > , J
                      s , 0 -> 0 , > , J
                      s , 1 -> 1 , > , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

         123456789012345678901234567890
 001. -> **************101*************   