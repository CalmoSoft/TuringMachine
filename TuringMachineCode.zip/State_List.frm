VERSION 5.00
Begin VB.Form frm_State_List 
   BackColor       =   &H00808000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "�llapotok lista"
   ClientHeight    =   5010
   ClientLeft      =   705
   ClientTop       =   2880
   ClientWidth     =   2265
   ControlBox      =   0   'False
   HelpContextID   =   17
   LinkTopic       =   "Form5"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   2265
   Begin VB.ListBox lst_State 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2595
      ItemData        =   "State_List.frx":0000
      Left            =   720
      List            =   "State_List.frx":0002
      Sorted          =   -1  'True
      TabIndex        =   1
      ToolTipText     =   "Az automata �llapotai"
      Top             =   1200
      Width           =   855
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   720
      TabIndex        =   0
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4335
      Width           =   855
   End
   Begin VB.Shape fra_State2 
      BorderWidth     =   2
      Height          =   4815
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   120
      Width           =   1575
   End
   Begin VB.Label lbl_State2 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "�llapot lista"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   615
      Left            =   720
      TabIndex        =   4
      Top             =   360
      Width           =   855
   End
   Begin VB.Label lbl_Nr 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Nr:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   720
      TabIndex        =   3
      Top             =   3960
      Width           =   375
   End
   Begin VB.Label lbl_Display 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   12
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   1200
      TabIndex        =   2
      ToolTipText     =   "Az �llapotok sz�ma"
      Top             =   3960
      Width           =   375
   End
End
Attribute VB_Name = "frm_State_List"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_State_List    :  Az automata �llapotainak list�ja
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        Unload frm_State_List
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                  �llapotok list�ja men�b�l '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�
        
        lst_State.Clear
        For i = 1 To frm_State_Rec.lst_State.ListCount
            lst_State.AddItem frm_State_Rec.lst_State.List(i - 1)
        Next i
        lbl_Display.Caption = lst_State.ListCount
End Sub
' ------------------------------------------------------------------------------------------ '
