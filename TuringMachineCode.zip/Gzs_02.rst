

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Gzs_02 Turing-g�p m�k�d�s�nek list�ja.
                      ======================================



 A megadott ABC     : *, 0, 1

 �tmeneti �llapotok : a, b, c, d

 Kezd� �llapot      : a

 Kezd� sz�          : 1110110110

 V�gs� �llapot      : d

 Output             : 1110110111


 Szab�lyok          : A1  BE   A2  KI  F

                      a , * -> a , * , J
                      a , 0 -> b , 0 , J
                      a , 1 -> b , 1 , J
                      b , * -> c , * , B
                      b , 0 -> b , 0 , J
                      b , 1 -> b , 1 , J
                      c , 0 -> d , 1 , J
                      c , 1 -> d , 0 , J


         Az automata konfigur�ci�i  :    A1  BE   A2  KI  F

 00. -> **************1110110110******   a , 1 -> b , 1 , J
 01. -> **************1110110110******   b , 1 -> b , 1 , J
 02. -> **************1110110110******   b , 1 -> b , 1 , J
 03. -> **************1110110110******   b , 0 -> b , 0 , J
 04. -> **************1110110110******   b , 1 -> b , 1 , J
 05. -> **************1110110110******   b , 1 -> b , 1 , J
 06. -> **************1110110110******   b , 0 -> b , 0 , J
 07. -> **************1110110110******   b , 1 -> b , 1 , J
 08. -> **************1110110110******   b , 1 -> b , 1 , J
 09. -> **************1110110110******   b , 0 -> b , 0 , J
 10. -> **************1110110110******   b , * -> c , * , B
 11. -> **************1110110110******   c , 0 -> d , 1 , J
 12. -> **************1110110111******         V�GE !