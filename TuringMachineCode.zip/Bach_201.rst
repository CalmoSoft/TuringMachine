

 SimTuring 1.0      - Turing-g�p �s felismer� automat�k
                      sz�m�t�g�pes szimul�ci�ja
                      Visual Basic 6.0-ban


                      'A sz�m�t�stechnikai Louvre-ban a Turing-g�p a Mona Lisa'
                                      (David Gelernter)


                      Bach_201 Turing-g�p m�k�d�s�nek list�ja.
                      ========================================



 A megadott ABC     : *, a, b, c, X

 �tmeneti �llapotok : 0, 3, 4, 5, 6, 7, A, a, B, b

 Kezd� �llapot      : 0

 Kezd� sz�          : babacbaba

 V�gs� �llapot      : 7

 Output             : XXXXcXXXX


 Szab�lyok          : A1  BE   A2  KI  M

                      0 , a -> a , X , J
                      0 , b -> b , X , J
                      3 , c -> 4 , c , B
                      3 , X -> 3 , X , B
                      4 , a -> 5 , a , B
                      4 , b -> 5 , b , B
                      4 , X -> 6 , X , J
                      5 , a -> 5 , a , B
                      5 , b -> 5 , b , B
                      5 , X -> 0 , X , J
                      6 , * -> 7 , * , J
                      6 , c -> 6 , c , J
                      6 , X -> 6 , X , J
                      A , a -> 3 , X , B
                      a , a -> a , a , J
                      a , b -> a , b , J
                      a , c -> A , c , J
                      A , X -> A , X , J
                      b , a -> b , a , J
                      B , b -> 3 , X , B
                      b , b -> b , b , J
                      b , c -> B , c , J
                      B , X -> B , X , J


         Az automata konfigur�ci�i  :     A1  BE   A2  KI  M   F

 001. -> **************babacbaba*******   0 , b -> b , X   J  15
 002. -> **************Xabacbaba*******   b , a -> b , a   J  16
 003. -> **************Xabacbaba*******   b , b -> b , b   J  17
 004. -> **************Xabacbaba*******   b , a -> b , a   J  18
 005. -> **************Xabacbaba*******   b , c -> B , c   J  19
 006. -> **************Xabacbaba*******   B , b -> 3 , X   B  20
 007. -> **************XabacXaba*******   3 , c -> 4 , c   B  19
 008. -> **************XabacXaba*******   4 , a -> 5 , a   B  18
 009. -> **************XabacXaba*******   5 , b -> 5 , b   B  17
 010. -> **************XabacXaba*******   5 , a -> 5 , a   B  16
 011. -> **************XabacXaba*******   5 , X -> 0 , X   J  15
 012. -> **************XabacXaba*******   0 , a -> a , X   J  16
 013. -> **************XXbacXaba*******   a , b -> a , b   J  17
 014. -> **************XXbacXaba*******   a , a -> a , a   J  18
 015. -> **************XXbacXaba*******   a , c -> A , c   J  19
 016. -> **************XXbacXaba*******   A , X -> A , X   J  20
 017. -> **************XXbacXaba*******   A , a -> 3 , X   B  21
 018. -> **************XXbacXXba*******   3 , X -> 3 , X   B  20
 019. -> **************XXbacXXba*******   3 , c -> 4 , c   B  19
 020. -> **************XXbacXXba*******   4 , a -> 5 , a   B  18
 021. -> **************XXbacXXba*******   5 , b -> 5 , b   B  17
 022. -> **************XXbacXXba*******   5 , X -> 0 , X   J  16
 023. -> **************XXbacXXba*******   0 , b -> b , X   J  17
 024. -> **************XXXacXXba*******   b , a -> b , a   J  18
 025. -> **************XXXacXXba*******   b , c -> B , c   J  19
 026. -> **************XXXacXXba*******   B , X -> B , X   J  20
 027. -> **************XXXacXXba*******   B , X -> B , X   J  21
 028. -> **************XXXacXXba*******   B , b -> 3 , X   B  22
 029. -> **************XXXacXXXa*******   3 , X -> 3 , X   B  21
 030. -> **************XXXacXXXa*******   3 , X -> 3 , X   B  20
 031. -> **************XXXacXXXa*******   3 , c -> 4 , c   B  19
 032. -> **************XXXacXXXa*******   4 , a -> 5 , a   B  18
 033. -> **************XXXacXXXa*******   5 , X -> 0 , X   J  17
 034. -> **************XXXacXXXa*******   0 , a -> a , X   J  18
 035. -> **************XXXXcXXXa*******   a , c -> A , c   J  19
 036. -> **************XXXXcXXXa*******   A , X -> A , X   J  20
 037. -> **************XXXXcXXXa*******   A , X -> A , X   J  21
 038. -> **************XXXXcXXXa*******   A , X -> A , X   J  22
 039. -> **************XXXXcXXXa*******   A , a -> 3 , X   B  23
 040. -> **************XXXXcXXXX*******   3 , X -> 3 , X   B  22
 041. -> **************XXXXcXXXX*******   3 , X -> 3 , X   B  21
 042. -> **************XXXXcXXXX*******   3 , X -> 3 , X   B  20
 043. -> **************XXXXcXXXX*******   3 , c -> 4 , c   B  19
 044. -> **************XXXXcXXXX*******   4 , X -> 6 , X   J  18
 045. -> **************XXXXcXXXX*******   6 , c -> 6 , c   J  19
 046. -> **************XXXXcXXXX*******   6 , X -> 6 , X   J  20
 047. -> **************XXXXcXXXX*******   6 , X -> 6 , X   J  21
 048. -> **************XXXXcXXXX*******   6 , X -> 6 , X   J  22
 049. -> **************XXXXcXXXX*******   6 , X -> 6 , X   J  23
 050. -> **************XXXXcXXXX*******   6 , * -> 7 , *   J  24
 END. -> **************XXXXcXXXX*******         V�GE !