VERSION 5.00
Begin VB.Form frm_Reg_List 
   BackColor       =   &H00808000&
   Caption         =   "Szab�lyok list�ja"
   ClientHeight    =   5010
   ClientLeft      =   720
   ClientTop       =   2895
   ClientWidth     =   3720
   ControlBox      =   0   'False
   HelpContextID   =   26
   LinkTopic       =   "Form12"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   ScaleHeight     =   5010
   ScaleWidth      =   3720
   Begin VB.ListBox lst_Reg_List 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2955
      ItemData        =   "Reg_List.frx":0000
      Left            =   735
      List            =   "Reg_List.frx":0002
      TabIndex        =   1
      ToolTipText     =   "Az automata szab�lyai"
      Top             =   1200
      Width           =   2295
   End
   Begin VB.CommandButton cmd_Close 
      BackColor       =   &H00C0C0C0&
      Caption         =   "Bez�r"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   360
      Left            =   1440
      TabIndex        =   0
      ToolTipText     =   "Kil�p�s a men�b�l"
      Top             =   4440
      Width           =   855
   End
   Begin VB.Label lbl_Reg_Nr 
      Alignment       =   1  'Right Justify
      BackColor       =   &H00808000&
      ForeColor       =   &H00000000&
      Height          =   300
      Left            =   2520
      TabIndex        =   6
      Top             =   4200
      Width           =   495
   End
   Begin VB.Label Label7 
      BackColor       =   &H00808000&
      Caption         =   "Nr :"
      Height          =   300
      Left            =   720
      TabIndex        =   5
      Top             =   4200
      Width           =   375
   End
   Begin VB.Label lbl_Reg_List_Turing 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2  KI  F"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   720
      TabIndex        =   4
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot, KI = Kimen� jel, F = Fejmozg�s(B=Balra, J=Jobbra, M=Marad)"
      Top             =   960
      Width           =   2295
   End
   Begin VB.Label lbl_Reg_List_Accept 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "A1  BE   A2"
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   9
         Charset         =   238
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   720
      TabIndex        =   3
      ToolTipText     =   "A1 = Bemen� �llapot, BE = Bemen� jel -> A2 = Kimen� �llapot"
      Top             =   960
      Width           =   2295
   End
   Begin VB.Shape fra_ABC2 
      BorderColor     =   &H80000007&
      BorderWidth     =   2
      Height          =   4815
      Left            =   360
      Shape           =   4  'Rounded Rectangle
      Top             =   120
      Width           =   3015
   End
   Begin VB.Label lbl_Szab_List 
      Alignment       =   2  'Center
      BackColor       =   &H00800080&
      Caption         =   "Szab�lyok list�ja"
      BeginProperty Font 
         Name            =   "Times New Roman"
         Size            =   11.25
         Charset         =   238
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   720
      TabIndex        =   2
      Top             =   360
      Width           =   2295
   End
End
Attribute VB_Name = "frm_Reg_List"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' ------------------------------------------------------------------------------------------ '
'
' frm_Reg_List     :  Az automata szab�lyainak list�ja
'
' ------------------------------------------------------------------------------------------ '
        Option Explicit
' ------------------------------------------------------------------------------------------ '
'                                                                                    Kil�p�s '
Private Sub cmd_Close_Click()
        Unload frm_Reg_List
End Sub
' ------------------------------------------------------------------------------------------ '
'                                                                  Szab�lyok list�ja men�b�l '
Private Sub Form_Activate()
        Dim i As Integer                    ' index-v�ltoz�
                
        lbl_Reg_List_Turing.Visible = (g_str_Mode = "T")
        lbl_Reg_List_Accept.Visible = (g_str_Mode = "F")
        lst_Reg_List.Clear
        For i = 1 To frm_Reg_Rec.lst_Reg.ListCount
            lst_Reg_List.AddItem _
            frm_Reg_Rec.lst_Reg.List(i - 1)
        Next i
        lbl_Reg_Nr = i - 1
End Sub
' ------------------------------------------------------------------------------------------ '
